﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using Microsoft.ServiceModel.Web;
using System.Linq;
using System.Net;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "$projectname$")]

namespace $projectname$
{
    // TODO: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true), AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed), ServiceContract]
    public partial class Service
    {
        /// <summary>
        /// Returns data in response to a HTTP GET request with URIs of the form http://<url-for-svc-file>/GetData?param1=1&param2=hello
        /// By default, the response is in XML. To return JSON, set ResponseFormat to WebMessageFormat.Json in the WebGetAttribute
        /// </summary>
        /// <param name="i">param1 in the UriTemplate</param>
        /// <param name="s">param2 in the UriTemplate</param>
        /// <returns></returns>
        [WebHelp(Comment="Sample description for GetData")]
        [WebGet(UriTemplate="GetData?param1={i}&param2={s}")]
        [OperationContract]
        public SampleResponseBody GetData(int i, string s)
        {
            // TODO: Change the sample implementation here
            if (i < 0) throw new WebProtocolException(HttpStatusCode.BadRequest, "param1 cannot be negative", null);
            return new SampleResponseBody()
            {
                Value = String.Format("Sample GetData response: '{0}', '{1}'", i, s)
            };
        }

        /// <summary>
        /// Returns data in response to a HTTP POST request with URIs of the form http://<url-for-svc-file>/DoWork/
        /// The body of the request must conform to the DataContract projection of SampleRequestBody.
        /// To customize the HTTP method to something other than POST, use the Method property of WebInvokeAttribute
        /// By default, the response is in XML. To return JSON, set ResponseFormat to WebMessageFormat.Json in the WebGetAttribute
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [WebHelp(Comment="Sample description for DoWork")]
        [WebInvoke(UriTemplate="DoWork")]
        [OperationContract]
        public SampleResponseBody DoWork(SampleRequestBody request)
        {
            //TODO: Change the sample implementation here
            return new SampleResponseBody()
            {
                Value = String.Format("Sample DoWork response: '{0}'", request.Data)
            };
        }
    }

    // TODO: Sample types for the request and response content. 
    // Use Visual Studio refactoring while modifying so that the references are updated.
    /// <summary>
    /// Example Request body structure. By default all public properties are DataContract serializable
    /// </summary>
    public class SampleRequestBody
    {
        public string Data { get; set; }
    }

    /// <summary>
    /// Example Response body structure. By default all public properties are DataContract serializable
    /// </summary>
    public class SampleResponseBody
    {
        public string Value { get; set; }
    }
}