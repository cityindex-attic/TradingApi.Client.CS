﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using Microsoft.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Net;
using Microsoft.ServiceModel.Web.SpecializedServices;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "$safeitemrootname$")]

namespace $safeitemrootname$
{
    // TODO: Modify the service behavior settings (instancing, concurrency etc) based on the service's requirements. Use ConcurrencyMode.Multiple if your service implementation
    //       is thread-safe.
    // TODO: NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service : CollectionServiceBase<SampleItem>, ICollectionService<SampleItem>
    {
        // TODO: These variables are used by the sample implementation. Remove if needed
        Dictionary<string, SampleItem> items = new Dictionary<string, SampleItem>();
        
        /// <returns>An enumeration of the (id, item) pairs. Returns null if no items are present</returns>
        protected override IEnumerable<KeyValuePair<string, SampleItem>> OnGetItems()
        {
            // TODO: Change the sample implementation here
            return this.items;
        }

        /// <summary>
        /// Gets the item with the specified id. A null return value will result in a response status code of NotFound (404), unless the method explicitly sets the status code to a different error
        /// </summary>
        /// <param name="id">identifier for the item</param>
        /// <returns>item corresponding to the given id. Null if the item does not exist</returns>
        protected override SampleItem OnGetItem(string id)
        {
            // TODO: Change the sample implementation here
            return this.items[id];
        }

        /// <summary>
        /// Adds the item to the enumeration. A null return value will result in a response status code of InternalServerError (500), unless the method explicitly sets the status code to a different error
        /// </summary>
        /// <param name="initialValue">The item to add</param>
        /// <param name="id">The id of the item to add</param>
        /// <returns>The item if adding it was successful. Returns null if adding the item failed</returns>
        protected override SampleItem OnAddItem(SampleItem initialValue, out string id)
        {
            // TODO: Change the sample implementation here
            id = Guid.NewGuid().ToString();
            this.items.Add(id, initialValue);
            return initialValue;
        }

        /// <summary>
        /// Updates the item with the id specified. Returns null if the item does not exist or if the item could not be updated
        /// If the item item does not already exist, throw a NotFound WebProtocolException.
        /// Unless the method explicitly sets the status code to a different error, a null return value will result in a response status code of NotFound (404) if the item does not exist; 
        /// if the item exists already, a null return value will result in a response status code of InternalServerError (500)
        /// </summary>
        /// <param name="id">The id of the item to update</param>
        /// <param name="newValue">The new value for the item</param>
        /// <returns>The updated item.</returns>
        protected override SampleItem OnUpdateItem(string id, SampleItem newValue)
        {
            // TODO: Change the sample implementation here
            SampleItem oldValue = OnGetItem(id);
            if (oldValue == null)
            {
              throw new WebProtocolException(HttpStatusCode.NotFound);
            }
            this.items[id] = newValue;
            return newValue;
        }

        /// <summary>
        /// Delete the item with the specified id, if it exists. Return false if the item does not exist.
        /// A return value of false will result in a response status code of NotFound (404) unless the method explicitly sets the status code to a different error.
        /// </summary>
        /// <param name="id">Item id to delete.</param>
        /// <returns>True if item was successfully removed, otherwise false.</returns>
        protected override bool OnDeleteItem(string id)
        {
            // TODO: Change the sample implementation here
            SampleItem item = OnGetItem(id);
            if (item == null) return false;
            this.items.Remove(id);
            return true;
        }

    }

    // TODO: Use Visual Studio refactoring while modifying so that the references are updated.
    /// <summary>
    /// This is the type used for items in the collection resource. 
    /// By default all public properties are DataContract serializable
    /// </summary>
    public class SampleItem
    {
        public string Value { get; set; }
    }

}