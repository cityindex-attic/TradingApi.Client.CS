This sample demonstrates how you can deal directly with XElement in a WCF REST service.
The sample exposes a heterogenous collection of pets using the WCF REST collection template.
Instead of relying on the framework to do serialization and deserialization, the service methods accept
and return XElement and use framework helper APIs to convert to/from XElement and CLR objects
in the service method implementation.