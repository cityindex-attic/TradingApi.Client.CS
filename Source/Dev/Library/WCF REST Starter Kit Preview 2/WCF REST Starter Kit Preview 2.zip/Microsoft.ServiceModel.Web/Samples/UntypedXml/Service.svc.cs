﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using Microsoft.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Net;
using System.Xml.Linq;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "UntypedXml")]

namespace UntypedXml
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service : CollectionServiceBase<XElement>, ICollectionService<XElement>
    {
        // TODO: These variables are used by the sample implementation. Remove if needed
        Dictionary<string, Pet> items = new Dictionary<string, Pet>();

        /// <returns>An enumeration of the (id, item) pairs. Returns null if no items are present</returns>
        protected override IEnumerable<KeyValuePair<string, XElement>> OnGetItems()
        {
            return (this.items).Select<KeyValuePair<string, Pet>, KeyValuePair<string, XElement>>((pair) => new KeyValuePair<string, XElement>(pair.Key, SerializationExtensions.ToXml<Pet>(pair.Value)));
        }

        /// <summary>
        /// Gets the item with the specified id. A null return value will result in a response status code of NotFound (404), unless the method explicitly sets the status code to a different error
        /// </summary>
        /// <param name="id">identifier for the item</param>
        /// <returns>item corresponding to the given id. Null if the item does not exist</returns>
        protected override XElement OnGetItem(string id)
        {
            return SerializationExtensions.ToXml<Pet>(this.items[id]);
        }

        /// <summary>
        /// Adds the item to the enumeration. A null return value will result in a response status code of InternalServerError (500), unless the method explicitly sets the status code to a different error
        /// </summary>
        /// <param name="initialValue">The item to add</param>
        /// <param name="id">The id of the item to add</param>
        /// <returns>The item if adding it was successful. Returns null if adding the item failed</returns>
        protected override XElement OnAddItem(XElement initialValue, out string id)
        {
            Pet pet = SerializationExtensions.ToObject<Pet>(initialValue);
            id = Guid.NewGuid().ToString();
            this.items.Add(id, pet);
            return initialValue;
        }

        /// <summary>
        /// Updates the item with the id specified. Returns null if the item does not exist or if the item could not be updated
        /// If the item item does not already exist, throw a NotFound WebProtocolException.
        /// Unless the method explicitly sets the status code to a different error, a null return value will result in a response status code of NotFound (404) if the item does not exist; 
        /// if the item exists already, a null return value will result in a response status code of InternalServerError (500)
        /// </summary>
        /// <param name="id">The id of the item to update</param>
        /// <param name="newValue">The new value for the item</param>
        /// <returns>The updated item.</returns>
        protected override XElement OnUpdateItem(string id, XElement newValue)
        {
            Pet oldPet;
            this.items.TryGetValue(id, out oldPet);
            if (oldPet == null)
            {
                throw new WebProtocolException(HttpStatusCode.NotFound);
            }
            Pet newPet = SerializationExtensions.ToObject<Pet>(newValue);
            this.items[id] = newPet;
            return newValue;
        }

        /// <summary>
        /// Delete the item with the specified id, if it exists. Return false if the item does not exist.
        /// A return value of false will result in a response status code of NotFound (404) unless the method explicitly sets the status code to a different error.
        /// </summary>
        /// <param name="id">Item id to delete.</param>
        /// <returns>True if item was successfully removed, otherwise false.</returns>
        protected override bool OnDeleteItem(string id)
        {
            // TODO: Change the sample implementation here
            Pet pet;
            this.items.TryGetValue(id, out pet);
            if (pet == null) return false;
            this.items.Remove(id);
            return true;
        }
    }

    [KnownType(typeof(Cat))]
    [KnownType(typeof(Dog))]
    public abstract class Pet
    {
        public string Name { get; set; }
        public abstract string Species { get; }
    }

    public class Dog : Pet
    {
        public override string Species
        {
            get { return "canis domestica"; }
        }
    }

    public class Cat : Pet
    {
        public override string Species
        {
            get { return "felis domestica"; }
        }
    }
}