﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml.Linq;
using Microsoft.ServiceModel.Web;
using System.Net;

namespace WebException2
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_EndRequest(object sender, EventArgs e)
        {
            if (HttpContext.Current.Error != null)
            {
                WebProtocolException webEx = HttpContext.Current.Error as WebProtocolException;
                if (webEx != null && webEx.StatusCode == HttpStatusCode.BadRequest)
                {
                    HttpContext.Current.ClearError();
                    HttpContext.Current.Response.Redirect("BadRequest.htm");
                }
            }
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}