﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using Microsoft.ServiceModel.Web;
using System.Net;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "WebException2")]

namespace WebException2
{
    // Modify the service behavior settings (instancing, concurrency etc) based on the service's requirements.
    // NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceContract]
    public partial class Service
    {
        [WebGet(UriTemplate = "GetData?param1={i}&param2={s}")]
        [OperationContract]
        SampleResponseBody GetData(int i, string s)
        {
            if (i <= 0)
            {
                throw new WebProtocolException(HttpStatusCode.BadRequest, "param1 must be positive", null);
            }
            return new SampleResponseBody()
            {
                Value = String.Format("Sample GetData response: '{0}', '{1}'", i, s)
            };
        }

        [WebInvoke(UriTemplate = "DoWork")]
        [OperationContract]
        SampleResponseBody DoWork(SampleRequestBody request)
        {
            throw new WebProtocolException(HttpStatusCode.Conflict, "Custom error data", new SampleErrorBody() { Error = "Sample error" }, null);
        }

        [WebInvoke(UriTemplate = "DoWork?json", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        SampleResponseBody DoWorkJson(SampleRequestBody request)
        {
            throw new WebProtocolException(HttpStatusCode.Conflict, "Custom error data in json", new SampleErrorBody() { Error = "Sample error in json" }, null);
        }
    }


    public class SampleRequestBody
    {
        public string Data { get; set; }
    }

    public class SampleResponseBody
    {
        public string Value { get; set; }
    }

    public class SampleErrorBody
    {
        public string Error { get; set; }
    }
}
