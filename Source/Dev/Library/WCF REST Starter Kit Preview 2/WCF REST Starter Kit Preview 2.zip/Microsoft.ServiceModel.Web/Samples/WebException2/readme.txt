This sample demonstrates integration of ASP.NET's custom error features with WCF's error handling support.
In this sample, code has been added in global.asax to display a custom error page for BadRequest HTTP status codes.

To run the sample:
=================
In the browser, type the <hostname>/service.svc/GetData?param1=-1. You will see the custom error page getting displayed
since the param1 is negative.