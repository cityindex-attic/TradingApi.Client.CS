﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Net;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "Counter")]

namespace Counter
{
    // NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    /// <summary>
    /// The Counter service maintains a single counter whose value can by obtained by GET. The counter value can be incremented with POST and can be replaced
    /// with PUT. The counter can be deleted when its use is over
    /// </summary>
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public partial class Service : SingletonServiceBase<Counter>, ISingletonService<Counter>
    {
        Counter item = new Counter() { Value = 0 };

        // This method is invoked for HTTP GET requests
        protected override Counter OnGetItem()
        {
            return this.item;
        }

        // This method is invoked for HTTP POST requests.
        // If the counter does not exist, create it.
        // Otherwise increment the value in the counter with the value POSTed
        protected override Counter OnAddItem(Counter newValue, out bool wasResourceCreated)
        {
            if (this.item == null)
            {
                this.item = newValue;
                wasResourceCreated = true;
            }
            else
            {
                wasResourceCreated = false;
                this.item.Value += newValue.Value;
            }
            return this.item;
        }

        // This method is invoked for HTTP PUT requests. This method should be idempotent.
        // If the counter does not exist, create it.
        // Otherwise replace the value in the counter with the value POSTed
        protected override Counter OnUpdateItem(Counter newValue, out bool wasResourceCreated)
        {
            wasResourceCreated = (this.item == null);
            this.item = newValue;
            return this.item;
        }

        // This method is called for HTTP DELETE requests
        protected override bool OnDeleteItem()
        {
            bool canItemBeDeleted = (this.item != null);
            this.item = null;
            return canItemBeDeleted;
        }
    }

    public class Counter
    {
        public int Value { get; set; }
    }
}
