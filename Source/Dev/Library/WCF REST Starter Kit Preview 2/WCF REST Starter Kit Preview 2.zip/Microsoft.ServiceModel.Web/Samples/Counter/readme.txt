Description
===========
This sample was created using the WCF Singleton Resource Visual Studio template.
It exposes an integer counter that can be created and manipulated using HTTP GET, PUT,
POST and DELETE. 

GET returns the value in the counter, PUT replaces the value in the counter
with value specified in the request, POST increments the value in the counter with the value
in the request, and DELETE deletes the counter.

To run the sample
=================
browse the svc file from the browser to get the value of the counter. Use Fiddler to manipulate
the counter using PUT, POST and DELETE.