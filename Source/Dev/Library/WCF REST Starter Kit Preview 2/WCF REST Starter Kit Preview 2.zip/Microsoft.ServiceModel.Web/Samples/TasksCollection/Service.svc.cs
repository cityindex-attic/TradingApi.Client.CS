﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Net;
using System.IO;
using Microsoft.ServiceModel.Web;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "TasksCollection")]

namespace TasksCollection
{
    // NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    /// <summary>
    /// This service exposes a collection of tasks, stored in a file. Tasks can be added, updated, deleted and queried by user.
    /// </summary>
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public partial class Service : CollectionServiceBase<Task>, ICollectionService<Task>
    {
        List<Task> tasks;
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFileDirectory = @"c:\";
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFile = "tasks.xml";

        public Service()
        {
            LoadTasks();
        }

        // Return an enumeration of the (id, item) pairs. Return null if no items are present
        protected override IEnumerable<KeyValuePair<string, Task>> OnGetItems()
        {
            // check if the query string specifies a user to filter the tasks
            string user = WebOperationContext.Current.IncomingRequest.UriTemplateMatch.QueryParameters["user"];
            IEnumerable<Task> filteredTasks = this.tasks.Where((task) => string.IsNullOrEmpty(user) || string.Equals(user, task.AssignedTo, StringComparison.OrdinalIgnoreCase));
            return filteredTasks.Select<Task, KeyValuePair<string, Task>>((item) => new KeyValuePair<string, Task>(item.Id, item));
        }

        // Get the item with the specified id. Return null if the item does not exist
        protected override Task OnGetItem(string id)
        {
            return this.tasks.Where((item) => (item.Id == id)).SingleOrDefault();
        }

        // Add the item to the enumeration and return its id. Return null if the item could not be added
        protected override Task OnAddItem(Task initialValue, out string id)
        {
            id = Guid.NewGuid().ToString();
            initialValue.Id = id;
            if (!TryAddTask(initialValue))
            {
                // if the saving of the tasks file fails, return null so that an InternalServerError gets sent back
                return null;
            }
            return initialValue;
        }

        // Update the item with the id specified. Return null if the item does not exist or if the item could not be updated
        protected override Task OnUpdateItem(string id, Task newValue)
        {
            Task oldValue = OnGetItem(id);
            if (oldValue == null)
            {
                throw new WebProtocolException(HttpStatusCode.NotFound);
            }
            if (!TryUpdateTask(oldValue, newValue))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError);
            }
            return newValue;
        }

        // Delete the item with the specified id, if it exists. Return false if the item does not exist.
        protected override bool OnDeleteItem(string id)
        {
            Task item = OnGetItem(id);
            if (item == null) return false;
            if (!TryRemoveTask(item))
            {
                // if the saving of the tasks file fails, return null and set the InternalServerError
                WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.InternalServerError;
                return false;
            }
            return true;
        }

        #region Loading, adding and removing tasks from the tasks file

        // method to load the tasks list from the tasks file
        void LoadTasks()
        {
            // if the file does not exist then return an empty list
            if (!File.Exists(tasksFileDirectory + tasksFile))
            {
                this.tasks = new List<Task>();
                return;
            }
            using (Stream fs = File.OpenRead(tasksFileDirectory + tasksFile))
            {
                try
                {
                    List<Task> newTasks = (List<Task>)new DataContractSerializer(typeof(List<Task>)).ReadObject(fs);
                    this.tasks = newTasks;
                }
                catch (IOException)
                {
                    // TODO: log the error
                    throw;
                }
            }
        }

        // method that saves the new list of tasks to the file and return false if it cannot save.
        // It saves to a temporary file first so that the original file is not corrupted if the save did not succeed
        bool TrySaveTasks(List<Task> tasks)
        {
            try
            {
                string tasksFilePath = tasksFileDirectory + tasksFile;
                // Save the updated copy to a temporary file
                string tmpFilePath = tasksFilePath + ".tmp";
                using (Stream fs = File.Open(tmpFilePath, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    new DataContractSerializer(typeof(List<Task>)).WriteObject(fs, tasks);
                }
                // delete the original file
                if (File.Exists(tasksFilePath))
                {
                    File.Delete(tasksFilePath);
                }
                // move the temporary file to the original tasks file
                File.Move(tmpFilePath, tasksFilePath);
                return true;
            }
            catch (SerializationException)
            {
                // TODO: log the error
                return false;
            }
            catch (IOException)
            {
                // TODO: log the error
                return false;
            }
            catch (UnauthorizedAccessException)
            {
                // TODO: log the error
                return false;
            }
        }

        bool TryAddTask(Task task)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Add(task);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        bool TryUpdateTask(Task oldValue, Task newValue)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Remove(oldValue);
            newTasks.Add(newValue);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        bool TryRemoveTask(Task task)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Remove(task);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }

    public class Task
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string AssignedTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Details { get; set; }
        public DateTime UpdatedTime { get; set; }
    }
}