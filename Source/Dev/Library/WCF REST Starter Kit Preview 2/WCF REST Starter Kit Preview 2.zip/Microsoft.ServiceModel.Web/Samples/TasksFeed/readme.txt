Description
===========
This sample was created using the WCF Feed Service Visual Studio template.
It exposes the list of task items, stored in an XML file, as an Atom feed. Clients
can get a feed of all the tasks or can get only the tasks for a particular user.

Whenever changes are made to the XML file, the service will reload the XML file and update the
tasks list.

To run the sample
=================
Move the XML file to a directory that you have access to and make sure the file is writeable.
Then update the sample code to include the correct path to the XML file (search for TODO in the
sample to update the code).

Then browse the svc file from the browser to get the task contents as a feed. Update the XML file
by adding or removing task items and verify that the feed is updated by hitting the svc file
from the browser.