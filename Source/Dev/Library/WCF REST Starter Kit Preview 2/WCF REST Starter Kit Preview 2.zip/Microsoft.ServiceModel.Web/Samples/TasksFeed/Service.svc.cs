﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.ServiceModel.Syndication;
using System.Globalization;
using System.IO;
using Microsoft.ServiceModel.Web;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "TasksFeed")]

namespace TasksFeed
{
    /// <summary>
    /// This sample implements a service that exposes a lists of tasks (stored in a local file) as an Atom feed.
    /// The tasks file is initially populated with some sample tasks
    /// Clients can either get a feed of tasks for a particular user or the tasks for all the users.
    /// The service also watches for updates to the tasks file and refreshes the feed accordingly.
    /// </summary>
    // NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceContract]
    public partial class TaskService
    {
        List<Task> tasks;
        FileSystemWatcher watcher;
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFileDirectory = @"C:\";
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFile = "tasks.xml";

        public TaskService()
        {
            LoadTasks();

            // listen for changes to the file and reload the tasks list accordingly
            this.watcher = new FileSystemWatcher(tasksFileDirectory, tasksFile);
            this.watcher.NotifyFilter = NotifyFilters.LastWrite;
            this.watcher.Changed += new FileSystemEventHandler(TasksChanged);
            watcher.EnableRaisingEvents = true;
        }

        // If no user is specified, then return tasks for all the users
        [WebHelp(Comment = "Returns the feed of tasks for the specified user. If user is not specified, all tasks are returned. Each item in the feed contains XML content such as <P>&lt;Task&gt;</P><P>&lt;AssignedTo&gt;user&lt;/AssignedTo&gt;</P><P>&lt;Deadline&gt;2008-07-01T00:00:00&lt;/Deadline&gt;</P><P>&lt;Details&gt;none&lt;/Details&gt;</P><P>&lt;Id&gt;some-id&lt;/Id&gt;</P><P>&lt;Title&gt;some-title&lt;/Title&gt;</P><P>&lt;UpdatedTime&gt;2008-06-30T00:00:00&lt;/UpdatedTime&gt;</P><P>&lt;/Task&gt;</P>")]
        [WebGet(UriTemplate = "?user={user}")]
        [OperationContract]
        public Atom10FeedFormatter GetFeed(string user)
        {
            SyndicationFeed feed;
            
            // filter the tasks by the user, if one is specified.
            IEnumerable<Task> filteredTasks = this.tasks.Where((task) => (string.IsNullOrEmpty(user) || string.Equals(task.AssignedTo, user, StringComparison.OrdinalIgnoreCase)));

            #region Maps Tasks list to a syndication feed
            // map the tasks to SyndicationItems
            IEnumerable<SyndicationItem> items = filteredTasks.Select<Task, SyndicationItem>((task) => new SyndicationItem()
            {
                Id = task.Id,
                Title = new TextSyndicationContent(String.Format("Due {0}: {1}", task.Deadline, task.Title)),
                LastUpdatedTime = task.UpdatedTime,
                // set the Author to the AssignedTo, so that users can sort by Assigned to in the browser
                Authors = 
                {
                    new SyndicationPerson()
                    {
                        Name = task.AssignedTo
                    }
                },
                Content = new TextSyndicationContent(task.Details)
            });

            // create the feed containing the syndication items.
            feed = new SyndicationFeed()
            {
                // The feed must have a unique stable URI id
                Id = "http://tmpuri.org/TasksFeed",
                Title = new TextSyndicationContent("Tasks List"),
                Items = items,
            };
            #endregion

            feed.AddSelfLink(WebOperationContext.Current.IncomingRequest.GetRequestUri());

            #region Sets response content-type for Atom feeds
            WebOperationContext.Current.OutgoingResponse.ContentType = ContentTypes.Atom;
            #endregion
            return feed.GetAtom10Formatter();
        }

        #region Tasks loading and refreshing from the file
        // method to load the tasks list from the tasks file
        void LoadTasks()
        {
            using (Stream fs = File.OpenRead(tasksFileDirectory + tasksFile))
            {
                try
                {
                    List<Task> newTasks = (List<Task>)new DataContractSerializer(typeof(List<Task>)).ReadObject(fs);
                    this.tasks = newTasks;
                }
                catch (IOException)
                {
                    // TODO: if the file could not be accessed then log the error and rethrow
                    throw;
                }
            }
        }

        // this method gets called every time the tasks file on disk gets updated.
        void TasksChanged(object sender, FileSystemEventArgs e)
        {
            LoadTasks();
        }
        #endregion
    }
    

    // The sample XML for this type is
    // <Task>
    //     <AssignedTo>user</AssignedTo>
    //     <Deadline>2008-07-01T00:00:00</Deadline>
    //     <Details>none</Details>
    //     <Id>some-id</Id>
    //     <Title>some-title</Title>
    //     <UpdatedTime>2008-06-30T00:00:00</UpdatedTime>
    // </Task>
    public class Task
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string AssignedTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Details { get; set; }
        public DateTime UpdatedTime { get; set; }
    }
}
