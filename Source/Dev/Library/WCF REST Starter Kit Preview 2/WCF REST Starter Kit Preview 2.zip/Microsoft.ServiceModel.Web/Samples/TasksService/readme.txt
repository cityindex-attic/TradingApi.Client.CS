Description
===========
This sample was created using the WCF HTTP Plain XML Service Visual Studio template.
It exposes the list of task items, stored in an XML file, and allows clients to add and remove
tasks from the list. Whenever a client tries to add or remove a task, the service will update
the XML file on disk accordingly.

In order to not corrupt the XML file when saving updates to it, the service saves the updated
task list in a temporary file and only when the file succeeds does it move the temporary
file to the original file.

To run the sample
=================
Move the XML file to a directory that you have access to and make sure the file is writeable.
Then update the sample code to include the correct path to the XML file (search for TODO in the
sample to update the code).

Then browse the svc file from the browser to get the task contents. In order to update or delete
tasks from the list, use Fiddler to send POST requests to the service.