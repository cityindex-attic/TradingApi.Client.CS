﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Net;
using System.IO;
using Microsoft.ServiceModel.Web;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "TasksService")]

namespace TasksService
{
    
    /// <summary>
    /// The TasksService exposes a collection of tasks to its clients. It allows the clients to get the list of tasks and to add to it.
    /// </summary>
    // NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceContract]
    public partial class Service
    {
        List<Task> tasks;
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFileDirectory = @"c:\";
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFile = "tasks.xml";

        public Service()
        {
            LoadTasks();
        }

        // returns data in response to a HTTP GET request with URIs of the form http://<url-for-svc-file>/GetTasks?user=user1
        [WebHelp(Comment="Returns the tasks for the user")]
        [WebGet(UriTemplate = "GetTasks?user={user}")]
        [OperationContract]
        List<Task> GetTasks(string user)
        {
            if (string.IsNullOrEmpty(user))
            {
                throw new WebProtocolException(HttpStatusCode.BadRequest);
            }
            // filter the tasks by the user, if one is specified.
            IEnumerable<Task> filteredTasks = this.tasks.Where((task) => (string.IsNullOrEmpty(user) || string.Equals(task.AssignedTo, user, StringComparison.OrdinalIgnoreCase)));
            return new List<Task>(filteredTasks);
        }

        // Allows clients to add tasks by doing a HTTP POST to http://<url-for-svc-file>/AddTask
        [WebHelp(Comment="Adds the specified task after assigning it an id")]
        [WebInvoke(UriTemplate = "AddTask")]
        [OperationContract]
        Task AddTask(Task task)
        {
            // the task must have a title, assigned-to and details
            if (string.IsNullOrEmpty(task.Title) || string.IsNullOrEmpty(task.AssignedTo) || string.IsNullOrEmpty(task.Details))
            {
                throw new WebProtocolException(HttpStatusCode.BadRequest);
            }
            
            // set the id and updated-time for the task
            task.Id = Guid.NewGuid().ToString();
            task.UpdatedTime = DateTime.UtcNow;

            // try to add the task to the list and save the changes to the file. If the changes cannot be saved, then return an internal server error
            if (!TryAddTask(task))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError);
            }
            // return the task so that the client can know its id
            return task;
        }

        // Allows clients to delete a particular task to http://<url-for-svc-file>/DeleteTask?id=<task-id>
        [WebHelp(Comment="Deletes the task with specified id")]
        [WebInvoke(UriTemplate = "DeleteTask?id={taskId}")]
        [OperationContract]
        void DeleteTask(string taskId)
        {
            // the taskId must be specified
            if (string.IsNullOrEmpty(taskId))
            {
                throw new WebProtocolException(HttpStatusCode.BadRequest);
            }

            Task taskToRemove = null;
            foreach (Task task in this.tasks)
            {
                if (task.Id == taskId)
                {
                    taskToRemove = task;
                    break;
                }
            }
            // try to remove the task to the list and save the changes to the file. If the changes cannot be saved, then return an internal server error
            if (taskToRemove != null && !TryRemoveTask(taskToRemove))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError);
            }
        }

        #region Loading, adding and removing tasks from the tasks file
        
        // method to load the tasks list from the tasks file
        void LoadTasks()
        {
            // if the file does not exist then return an empty list
            if (!File.Exists(tasksFileDirectory + tasksFile))
            {
                this.tasks = new List<Task>();
                return;
            }
            using (Stream fs = File.OpenRead(tasksFileDirectory + tasksFile))
            {
                try
                {
                    List<Task> newTasks = (List<Task>)new DataContractSerializer(typeof(List<Task>)).ReadObject(fs);
                    this.tasks = newTasks;
                }
                catch (IOException)
                {
                    // TODO: log the error
                    throw;
                }
            }
        }

        // method that saves the new list of tasks to the file and return false if it cannot save.
        // It saves to a temporary file first so that the original file is not corrupted if the save did not succeed
        bool TrySaveTasks(List<Task> tasks)
        {
            try
            {
                string tasksFilePath = tasksFileDirectory + tasksFile;
                // Save the updated copy to a temporary file
                string tmpFilePath = tasksFilePath + ".tmp";
                using (Stream fs = File.Open(tmpFilePath, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    new DataContractSerializer(typeof(List<Task>)).WriteObject(fs, tasks);
                }
                // delete the original file
                if (File.Exists(tasksFilePath))
                {
                    File.Delete(tasksFilePath);
                }
                // move the temporary file to the original tasks file
                File.Move(tmpFilePath, tasksFilePath);
                return true;
            }
            catch (SerializationException)
            {
                // TODO: log the error
                return false;
            }
            catch (IOException)
            {
                // TODO: log the error
                return false;
            }
            catch (UnauthorizedAccessException)
            {
                // TODO: log the error
                return false;
            }
        }

        bool TryAddTask(Task task)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Add(task);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        bool TryRemoveTask(Task task)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Remove(task);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }

    // The sample XML for this type is
    // <Task>
    //     <AssignedTo>user</AssignedTo>
    //     <Deadline>2008-07-01T00:00:00</Deadline>
    //     <Details>none</Details>
    //  <!-- Note that the id and updated-time are not required when adding a task -->
    //     <Id>some-id</Id>
    //     <Title>some-title</Title>
    //     <UpdatedTime>2008-06-30T00:00:00</UpdatedTime>
    // </Task>
    public class Task
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string AssignedTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Details { get; set; }
        public DateTime UpdatedTime { get; set; }
    }
}
