This sample illustrates how to use .NET APIs that do not return a stream (for example, bitmap and db APIs) 
with WCF's stream programming model.

To run the sample:
=================
Type <host,port>/service.svc/image?text=hello in the browser. A bitmap will be returned.