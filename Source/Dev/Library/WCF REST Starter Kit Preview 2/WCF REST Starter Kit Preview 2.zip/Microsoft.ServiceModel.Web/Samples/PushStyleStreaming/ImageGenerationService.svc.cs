﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using Microsoft.ServiceModel.Web;
using System.Linq;
using System.Net;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "PushStyleStreaming")]

namespace PushStyleStreaming
{
    // TODO: Modify the service behavior settings (instancing, concurrency etc) based on the service's requirements.
    // TODO: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceContract]
    public class Service
    {
        [WebHelp(Comment = "Returns a dynamically generated image based on input text")]
        [WebGet(UriTemplate = "image?text={text}")]
        [OperationContract]
        Stream GetImage(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                throw new WebProtocolException(HttpStatusCode.BadRequest, "text must be specified", null);
            }
            Bitmap theBitmap = GenerateImage(text);
            WebOperationContext.Current.OutgoingResponse.ContentType = "image/jpeg";
            return new AdapterStream((stream) => theBitmap.Save(stream, ImageFormat.Jpeg));
        }

        [WebHelp(Comment = "Generates response text dynamically based on input")]
        [WebGet(UriTemplate = "text?text={text}")]
        [OperationContract]
        Stream GetText(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                throw new WebProtocolException(HttpStatusCode.BadRequest, "text must be specified", null);
            }
            WebOperationContext.Current.OutgoingResponse.ContentType = "text/plain";
            return new AdapterStream((writer) =>
                {
                    writer.WriteLine("You said: ");
                    writer.WriteLine(text);
                    writer.WriteLine("Didn't you?");
                    writer.Flush();
                }, Encoding.UTF8);
        }

        Bitmap GenerateImage(string text)
        {
            Bitmap bitmap = new Bitmap(468, 60);
            Graphics g = Graphics.FromImage(bitmap);
            Brush brush = new SolidBrush(Color.Indigo);
            g.FillRectangle(brush, 0, 0, 468, 60);
            brush = new SolidBrush(Color.WhiteSmoke);
            g.DrawString(text, new Font("Consolas", 13), brush, new PointF(5, 5));
            return bitmap;
        }
    }
}