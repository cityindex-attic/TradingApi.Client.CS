This sample illustrates how to integrate posting Forms data with a WCF REST service.
The forms data can be read by having an operation which takes a NameValueCollection in the body.
The sample also illustrates how URI parameters compose with a Forms Post body.

To run the sample:
=================
Browse the forms.htm web page. It will prompt you to enter an integer in the text box.
Now try to get the singleton counter resource hosted by the .svc. The value of the counter will be the data entered in the text box.
