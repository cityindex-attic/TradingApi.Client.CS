﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Collections.Specialized;
using Microsoft.ServiceModel.Web;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "FormsPost")]

namespace FormsPost
{
    // Modify the service behavior settings (instancing, concurrency etc) based on the service's requirements.
    // NOTE: Please set IncludeExceptionDetailInFaults to false in production environments
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceContract]
    public partial class Service
    {
        int value;

        [WebGet(UriTemplate = "GetData")]
        [WebHelp(Comment="Returns the value of the counter")]
        [OperationContract]
        Counter GetData()
        {
            return new Counter() { Value = this.value };
        }

        [WebInvoke(UriTemplate = "SetData/{a}?x={b}")]
        [WebHelp(Comment="Sets the value of the counter based on the value of the counter key in the incoming forms post data. Parameters a and b are unused.")]
        [OperationContract]
        void SetData(string a, NameValueCollection formsData, int b)
        {
            this.value = Int32.Parse(formsData["counter"]);
        }
    }

    public class Counter
    {
        public int Value { get; set; }
    }
}
