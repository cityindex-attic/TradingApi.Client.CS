This sample demonstrates how to plug in the channel stack to process the HTTP request early on
to influence method dispatch etc.
In this method, a RequestInterceptor is plugged in that dispatches to the method specified in
the request's X-HTTP-Method-Override if present.

To run the sample:
=================
From Fiddler, send a HTTP POST request with X-HTTP-Method-Override header set to PUT or DELETE.
You will see that the resource has been updated (in case of PUT) or deleted (in case of DELETE).