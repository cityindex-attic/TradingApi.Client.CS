This sample demonstrates the exception programming model support for REST errors. The response gets returned
in the output format (Xml or Json) specified by the operation. The error message can be a simple string or a
serializable CLR type.