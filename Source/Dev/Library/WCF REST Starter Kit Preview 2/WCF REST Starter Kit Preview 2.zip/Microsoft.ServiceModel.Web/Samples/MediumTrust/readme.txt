Description
===========
This sample was created using the WCF Feed Service Visual Studio template.It demonstrates how a starter kit service can run
in medium trust.

Note that for the starter kit WCF service to run in partial trust, it must have the endpoint specified in configuration and
cannot have a zero configuration.

To run the sample
=================
Browse the svc file from the browser to get the feed. 