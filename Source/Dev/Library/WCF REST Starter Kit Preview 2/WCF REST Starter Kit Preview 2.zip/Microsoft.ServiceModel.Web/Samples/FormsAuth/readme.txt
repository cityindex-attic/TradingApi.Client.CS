This sample demonstrates how service access can be controlled using ASP.NET authentication (forms auth in this case) and ASP.NET role and membership providers.
The sample configures forms auth in config, along with a dummy role provider and dummy membership provider.
The role provider grants user joe admin role and everyone else guest role.
The membership provider expects the password to be reverse of the username.
The service method is setup to only allow callers in the admin role.

This can be used with other asp.net auth modes as well. Note - to use windows based authorization with windows auth mode,
you need to configure WebServiceHost2.PrincipalPermissionMode = PrincipalPermissionMode.Windows in the service.svc file.

To run the sample:
=================
Start the sample and browse the svc file. You should be able to browse the help page without credentials.
Now do a Get to the GetData url from the browser. You will be challenged with your username and password. You'll find that
user joe (with password eoj) is allowed access but noone else.

Note: The forms cookie gets cached by the browser. So after logging on as a particular user, you need to delete browser
cookies to be prompted again for login.