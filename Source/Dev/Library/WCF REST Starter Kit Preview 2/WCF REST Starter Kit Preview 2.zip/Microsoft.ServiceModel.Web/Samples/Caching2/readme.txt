This sample demonstrates how to cache a response from a REST service as long as there are no changes to
a table in a SQL database. This is valuable as the data returned by a service often depends on the values in
database tables and does not change as long as the underlying tables dont.

This sample requires the following additional steps:

1. Install SQLExpress on your machine with integrated windows auth support
2. Create a database called pubs 
3. Add a table called Authors to pubs.
4. Configure pubs for change notification - aspnet_regsql.exe -S ".\SQLExpress" -E -d "pubs" -ed
5. Configure Authors for change notification - aspnet_regsql.exe -S ".\SQLExpress" -E -d "pubs" -et -t "authors"
6. Start the service.
7. Hit the service in IE. You will notice that the number of invocations reported in the feed does not change unless
   the authors table get updated.