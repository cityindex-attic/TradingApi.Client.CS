This sample shows how to ensure idempotent and conflict-resistant PUTs and DELETEs by implementing
optimistic concurrency using Etags and If-Match headers.
The service returns the Etag for the resource in all responses. PUTs and DELETEs without an Etag or without the
latest Etag for the resource will get a HTTP error code in the response. 