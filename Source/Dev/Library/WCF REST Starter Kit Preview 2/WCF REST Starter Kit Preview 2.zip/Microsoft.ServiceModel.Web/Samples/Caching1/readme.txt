This sample demonstrates caching a response in the IIS cache for a fixed duration (60 secs in this case).
Also, the cache uses the value of the numItems parameter in the cache key.

In order to test the sample, start the sample and try hitting the service from IE. Successive requests for the same
URL (with < 1 min between them) will show no change in the number of invocations reported in the feed.