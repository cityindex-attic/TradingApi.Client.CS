﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.ServiceModel.Syndication;
using Microsoft.ServiceModel.Web;
using System.Globalization;
using System.Net;
using System.Web.UI;


namespace Caching1
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceContract]
    public partial class FeedService
    {
        int numInvokes = 0;

        /// <summary>
        /// Returns an Atom feed.
        /// </summary>
        /// <param name="i"></param>
        /// <returns>Atom feed in response to a HTTP GET request at URLs conforming to the URI template of the WebGetAttribute.</returns>
        [WebHelp(Comment = "Sample description for GetFeed.")]
        [WebCache(CacheProfileName="CacheFor1Min")]
        [WebGet(UriTemplate = "?numItems={i}")]
        [OperationContract]
        public Atom10FeedFormatter GetFeed(int i)
        {
            SyndicationFeed feed;

            if (i < 0) throw new WebProtocolException(HttpStatusCode.BadRequest, "numItems cannot be negative", null);
            
            ++numInvokes;
            if (i == 0) i = 1;
            // Create the list of syndication items. These correspond to Atom entries
            List<SyndicationItem> items = new List<SyndicationItem>();
            for (int j = 1; j <= i; ++j)
            {
                items.Add(new SyndicationItem()
                {
                    // Every entry must have a stable unique URI id
                    Id = String.Format(CultureInfo.InvariantCulture, "http://tmpuri.org/Id{0}", j),
                    Title = new TextSyndicationContent(String.Format("Sample item '{0}'", j)),
                    // Every entry should include the last time it was updated
                    LastUpdatedTime = new DateTime(2008, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                    // The Atom spec requires an author for every entry. If the entry has no author, use the empty string
                    Authors = 
                    { 
                        new SyndicationPerson() 
                        {
                            Name = "Sample Author"
                        }
                    },
                    // The content of an Atom entry can be text, xml, a link or arbitrary content. In this sample text content is used.
                    Content = new TextSyndicationContent("Number of service invocations: " + this.numInvokes.ToString()),
                });

            }
            // create the feed containing the syndication items.
            feed = new SyndicationFeed()
            {
                // The feed must have a unique stable URI id
                Id = "http://tmpuri.org/FeedId",
                Title = new TextSyndicationContent("Sample feed"),
                Items = items
            };
            feed.AddSelfLink(WebOperationContext.Current.IncomingRequest.GetRequestUri());
            #region Sets response content-type for Atom feeds
            WebOperationContext.Current.OutgoingResponse.ContentType = ContentTypes.Atom;
            #endregion
            return feed.GetAtom10Formatter();
        }

    }
}
