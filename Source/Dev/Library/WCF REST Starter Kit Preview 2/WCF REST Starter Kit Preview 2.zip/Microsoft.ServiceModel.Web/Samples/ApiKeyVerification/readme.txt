This sample demonstrates how a pipeline component can be plugged in - in this case to ensure that
the API key in the request is valid. REST services typically do this check along with others like throttling
usage per API key, verifying that the URL contains a signature based on the key etc.

The checking is done by plugging in a custom RequestInterceptor right above the HTTP channel. This interceptor
does blocking work like replying with a fault and hence sets IsSynchronous to false in the base.

In order to test this sample, browse the svc file in the browser. By default you will get an error message stating
that the apikey query string parameter must be included.

Now try browsing the service, after appending ?apikey=13579 to the URL. This should succeed.