﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Microsoft.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.Collections.Specialized;
using System.Net;
using System.ServiceModel;
using System.IO;

namespace ApiKeyVerification
{
    public class ApiKeyVerifyingRequestInterceptor : RequestInterceptor
    {
        // since this interceptor sends back a reply it passes IsSynchronous=false to base so as not to block the message pump
        public ApiKeyVerifyingRequestInterceptor()
            : base(false)
        {
        }

        public override void ProcessRequest(ref RequestContext requestContext)
        {
            if (requestContext == null || requestContext.RequestMessage == null)
            {
                return;
            }
            Message request = requestContext.RequestMessage;
            HttpRequestMessageProperty requestProp = (HttpRequestMessageProperty)request.Properties[HttpRequestMessageProperty.Name];
            NameValueCollection queryParams = HttpUtility.ParseQueryString(requestProp.QueryString);
            string key = queryParams["apikey"];
            if (!IsValidApiKey(key))
            {
                // The error message is padded so that IE shows the response by default
                XElement response = XElement.Load(new StringReader("<?xml version=\"1.0\" encoding=\"utf-8\"?><html xmlns=\"http://www.w3.org/1999/xhtml\" version=\"-//W3C//DTD XHTML 2.0//EN\" xml:lang=\"en\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.w3.org/1999/xhtml http://www.w3.org/MarkUp/SCHEMA/xhtml2.xsd\"><HEAD><TITLE>Request Error</TITLE></HEAD><BODY><DIV id=\"content\"><P class=\"heading1\"><B>A valid API key needs to be included using the apikey query string parameter</B></P></DIV></BODY></html>"));
                Message reply = Message.CreateMessage(MessageVersion.None, null, response);
                HttpResponseMessageProperty responseProp = new HttpResponseMessageProperty() { StatusCode = HttpStatusCode.Unauthorized, StatusDescription = String.Format("'{0}' is an invalid API key", key) };
                responseProp.Headers[HttpResponseHeader.ContentType] = "text/html";
                reply.Properties[HttpResponseMessageProperty.Name] = responseProp;
                requestContext.Reply(reply);
                // set the request context to null to terminate processing of this request
                requestContext = null;
            }
        }


        bool IsValidApiKey(string key)
        {
            return (key == "13579");
        }
    }
}
