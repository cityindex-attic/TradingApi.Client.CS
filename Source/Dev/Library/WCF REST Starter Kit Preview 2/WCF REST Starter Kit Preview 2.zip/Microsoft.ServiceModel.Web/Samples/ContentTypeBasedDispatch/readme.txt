This sample shows how content based dispatch (aka content negotiation) can be done using WCF.
The service is a singleton service that exposes a resource over XML and JSON. The JSON representation
can be got by appending a ?format=json to the URL or by appending an Accept header to the request
with value application/json.

This is accomplished by writing a RequestInterceptor that appends a format=json to the incoming URI if
the corresponding Accept header is present, thereby ensuring that the method that returns the json format
is executed.