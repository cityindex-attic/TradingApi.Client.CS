Description
===========
This sample was created using the WCF Atom Publishing Service Visual Studio template.
It exposes the list of task items, stored in an XML file, and allows clients to add, update and remove
tasks from the list using the Atom Publishing Protocol. Whenever a client tries to add, update or remove a task, the service will update
the XML file on disk accordingly.

In order to not corrupt the XML file when saving updates to it, the service saves the updated
task list in a temporary file and only when the file succeeds does it move the temporary
file to the original file.

To run the sample
=================
Move the XML file to a directory that you have access to and make sure the file is writeable.
Then update the sample code to include the correct path to the XML file (search for TODO in the
sample to update the code).

Then browse the svc file from the browser to get the task contents. In order to add, update or delete
tasks from the list, use Fiddler to send POST, PUT and DELETE requests to the service.

Note that this service does not allow users to create, update or delete Atom entries directly. Instead the
user is expected to create, update or delete the underlying tasks (media items referenced by the Atom feed). This in turn
updates the entries in the Atom feed.

Also note that in this example, the category field of the service document has been extended to include an example of the 
media items allowed to be posted to the collection 