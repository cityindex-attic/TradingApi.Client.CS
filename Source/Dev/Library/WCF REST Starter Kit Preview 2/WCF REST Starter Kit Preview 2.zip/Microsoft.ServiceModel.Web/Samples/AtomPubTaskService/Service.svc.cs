﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.ServiceModel.Syndication;
using Microsoft.ServiceModel.Web;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using System.Xml;
using System.IO;
using System.Globalization;
using System.ComponentModel;
using System.Collections.ObjectModel;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "AtomPubTaskService")]

namespace AtomPubTaskService
{
    /// <summary>
    /// This service exposes a collection of task objects (exposed as an XML infoset) using AtomPub. The tasks are stored locally in a file.
    /// The service allows adding, updating and deleting tasks by updating the corresponding task XML media item. Atom entries are not allowed to be updated
    /// directly since the Atom entry is generated from the corresponding task XML media item.
    /// </summary>
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service : AtomPublishingProtocolServiceBase, IAtomPublishingProtocolService
    {
        // This service exposes a single collection hanging off /tasks
        const string collectionName = "tasks";
        
        List<Task> tasks;

        // TODO: customize path according to where you have placed the tasks file
        const string tasksFileDirectory = @"c:\";
        // TODO: customize path according to where you have placed the tasks file
        const string tasksFile = "tasks.xml";


        public Service()
        {
            // Load the tasks from file
            LoadTasks();
        }

        /// <summary>
        /// Specifies the maximum number of entries that are returned in the feed at a single time. If this is less than int.MaxValue, then the feed can
        /// be a partial collection and will contain a link to the next set of entries.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override int GetMaximumEntriesInFeed(string collection)
        {
            // at most 15 tasks are returned at a time, with links to previous and next pages
            return 15;
        }

        /// <summary>
        /// Returns an enumeration of SyndicationItems representing the entries in the requested collection, sorted by last updated time (newest first).
        /// The entries will be returned as an Atom feed. Set hasMoreEntries to true if maxEntries is smaller than the rest of the collection
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="startIndex">0-based index for the first entry requested</param>
        /// <param name="maxEntries">the maximum number of entries to return</param>
        /// <param name="hasMoreEntries"></param>
        /// <returns></returns>
        protected override IEnumerable<SyndicationItem> GetEntries(string collection, int startIndex, int maxEntries, out bool hasMoreEntries)
        {
            hasMoreEntries = (startIndex + maxEntries) < this.tasks.Count;
            int count = (maxEntries > (this.tasks.Count - startIndex)) ? (this.tasks.Count - startIndex) : maxEntries;
            // return tasks in order of the most recently updated first
            IEnumerable<Task> tasks = new List<Task>(this.tasks.OrderByDescending<Task, long>(((item) => item.UpdatedTime.Ticks))).GetRange(startIndex, count);
            // map the tasks to syndication items using the CreateEntryFromTask method
            return tasks.Select<Task, SyndicationItem>((task) => this.CreateEntryFromTask(task));
        }


        /// <summary>
        /// Gets the SyndicationItem corresponding to the id. Return null if it does not exist
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <returns></returns>
        protected override SyndicationItem GetEntry(string collection, string id)
        {
            Task task = this.tasks.Where((item) => (item.Id == id)).SingleOrDefault();
            if (task == null) return null;
            return this.CreateEntryFromTask(task);
        }

        /// <summary>
        /// Add the Atom entry to the collection. Return its id and the actual entry that was added to the collection. 
        /// If the item could not be added return null.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="entry">entry to be added</param>
        /// <param name="location">URI for the added entry</param>
        /// <returns></returns>
        protected override SyndicationItem AddEntry(string collection, SyndicationItem entry, out Uri location)
        {
            // this service does not support adding atom entries directly, only by posting the task xml media item
            throw new WebProtocolException(HttpStatusCode.BadRequest, "The service does not support adding Atom entries. Only XML task media items can be added.", null);
        }

        /// <summary>
        /// Update the Atom entry specified by the id. If none exists, return null. Return the updated Atom entry. Return null if the entry does not exist.
        /// This method must be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <param name="entry">Entry to put</param>
        /// <returns></returns>
        protected override SyndicationItem PutEntry(string collection, string id, SyndicationItem entry)
        {
            // this service does not support updating atom entries directly, only by updating the task xml media item
            throw new WebProtocolException(HttpStatusCode.BadRequest, "The service does not support updating Atom entries. Only XML task media items can be updated", null); 
        }

        /// <summary>
        /// Delete the Atom entry with the specified id. Return false if no such entry exists.
        /// This method should be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <returns></returns>
        protected override bool DeleteEntry(string collection, string id)
        {
            // this service does not support deleting atom entries directly, only by deleting the task xml media item
            throw new WebProtocolException(HttpStatusCode.BadRequest, "The service does not support deleting Atom entries. Only XML media items can be deleted", null); 
        }

        /// <summary>
        /// Gets the SyndicationItem corresponding to the id. Return null if it does not exist.
        /// Set the contentType of the media item.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <param name="contentType">content type of the item</param>
        /// <returns></returns>
        protected override Stream GetMedia(string collection, string id, out string contentType)
        {
            Task task = this.tasks.Where((t) => (t.Id == id)).SingleOrDefault();
            if (task == null)
            {
                contentType = null;
                return null;
            }
            contentType = "application/xml";
            return new AdapterStream((stream) => new DataContractSerializer(typeof(Task)).WriteObject(stream, task));
        }

        /// <summary>
        /// Add the media item (represented by the stream, contentType and description) to the collection
        /// Return the id of the media item and the Atom entry representing it. If the item could not be added return null.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="stream">request entity body</param>
        /// <param name="contentType">content type of request</param>
        /// <param name="description">description, as provided in the Slug header</param>
        /// <param name="location">Uri for the media entry</param>
        /// <returns></returns>
        protected override SyndicationItem AddMedia(string collection, Stream stream, string contentType, string description, out Uri location)
        {
            string newId;
            SyndicationItem newEntry;
            // description parameter is not used here since the task itself has a details field that serves as the description
            Task newTask = (Task) new DataContractSerializer(typeof(Task)).ReadObject(stream);
            newId = Guid.NewGuid().ToString();
            newTask.Id = newId;
            newTask.UpdatedTime = DateTime.UtcNow;
            if (!TryAddTask(newTask))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError, "Saving the task failed", null);
            }
            newEntry = CreateEntryFromTask(newTask, out location);
            return newEntry;
        }

        /// <summary>
        /// Update the media item specified by the id. Return false if no such item exists.
        /// This method must be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the item</param>
        /// <param name="stream">new value for the media item</param>
        /// <param name="contentType">content type of the new value</param>
        /// <param name="description">description, as specifued in the Slug header</param>
        /// <returns></returns>
        protected override bool PutMedia(string collection, string id, Stream stream, string contentType, string description)
        {
            Task updatedTask = (Task) new DataContractSerializer(typeof(Task)).ReadObject(stream);
            Task oldTask = this.tasks.Where((task) => (task.Id == id)).SingleOrDefault();
            if (oldTask == null)
            {
                return false;
            }
            this.tasks.Remove(oldTask);
            // description parameter is not used here since the task itself has a details field that serves as the description
            updatedTask.Id = id;
            updatedTask.UpdatedTime = DateTime.UtcNow;
            if (!TryRemoveTask(oldTask))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError, "Removing the old task failed", null);
            }
            if (!TryAddTask(updatedTask))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError, "Adding the updated task failed", null);
            }
            return true;
        }

        /// <summary>
        /// Delete the media item with the specified id. Return false if no such item exists. Also delete the corresponding media entry
        /// This method should be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <returns></returns>
        protected override bool DeleteMedia(string collection, string id)
        {
            Task task = this.tasks.Where((t) => (t.Id == id)).SingleOrDefault();
            if (task == null)
            {
                return false;
            }
            if (!TryRemoveTask(task))
            {
                throw new WebProtocolException(HttpStatusCode.InternalServerError, "Removing the task failed", null);
            }
            return true;
        }

        /// <summary>
        /// Create a feed container object (containing no entries) for the input collection
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override SyndicationFeed CreateFeed(string collection)
        {
            return new SyndicationFeed()
            {
                Title = new TextSyndicationContent("Tasks feed"),
                Id = "http://tempuri.org/Tasks",
                Description = new TextSyndicationContent("A feed of tasks stored at the service")
            };
        }

        /// <summary>
        /// Return true if the collection name is a valid collection, false otherwise
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override bool IsValidCollection(string collection)
        {
            return (collection == collectionName);
        }

        /// <summary>
        /// Return the service document describing the collections hosted by the service
        /// </summary>
        /// <returns></returns>
        protected override ServiceDocument GetServiceDocument()
        {
            // In the service document, enhance the category element to include an example of the Task XML
            SyndicationCategory tasksCategory = new SyndicationCategory() { Name = "Tasks" };
            Task exampleTask = new Task() { AssignedTo = "user", Deadline = new DateTime(2008, 1, 1), Details="details", Id="id1", Title="title" };
            XElement taskXml = SerializationExtensions.ToXml<Task>(exampleTask);
            tasksCategory.ElementExtensions.Add("Example", "http://tempuri.org/examples", taskXml);
            return new ServiceDocument()
            {
                Workspaces = 
                {
                    new Workspace()
                    {
                        Title = new TextSyndicationContent("Workspace 1"),
                        Collections = 
                        {
                            new ResourceCollectionInfo(new TextSyndicationContent("Tasks"), GetAllEntriesUri(collectionName), null, GetAllowedContentTypes(collectionName))
                            {
                                Categories = 
                                {
                                    new InlineCategoriesDocument()
                                    {
                                        Categories = 
                                        {
                                            tasksCategory
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
        }

        /// <summary>
        /// Return the content types of items that can be added to the collection
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override IEnumerable<string> GetAllowedContentTypes(string collection)
        {
            // This service only allows uploading task XML media items
            return new string[] { "application/xml" };
        }

        #region methods that convert a Task CLR instance to an Atom entry
        SyndicationItem CreateEntryFromTask(Task task)
        {
            Uri dummy;
            return CreateEntryFromTask(task, out dummy);
        }

        SyndicationItem CreateEntryFromTask(Task task, out Uri location)
        {
            SyndicationItem entry = new SyndicationItem()
            {
                Id = "http://tempuri.org/" + task.Id,
                // Atom feed requires the author element but its not valid for this scenario
                Authors =  { new SyndicationPerson("") },
                LastUpdatedTime = task.UpdatedTime,
                Summary = new TextSyndicationContent(task.Details),
                Title = new TextSyndicationContent(task.Title),
            };

            ConfigureMediaEntry(collectionName, entry, task.Id, "application/xml", out location);
            return entry;
        }
        #endregion

        #region Loading, adding and removing tasks from the tasks file

        // method to load the tasks list from the tasks file
        void LoadTasks()
        {
            // if the file does not exist then return an empty list
            if (!File.Exists(tasksFileDirectory + tasksFile))
            {
                this.tasks = new List<Task>();
                return;
            }
            using (Stream fs = File.OpenRead(tasksFileDirectory + tasksFile))
            {
                try
                {
                    List<Task> newTasks = (List<Task>)new DataContractSerializer(typeof(List<Task>)).ReadObject(fs);
                    this.tasks = newTasks;
                }
                catch (IOException)
                {
                    // TODO: log the error
                    throw;
                }
            }
        }

        // method that saves the new list of tasks to the file and return false if it cannot save.
        // It saves to a temporary file first so that the original file is not corrupted if the save did not succeed
        bool TrySaveTasks(List<Task> tasks)
        {
            try
            {
                string tasksFilePath = tasksFileDirectory + tasksFile;
                // Save the updated copy to a temporary file
                string tmpFilePath = tasksFilePath + ".tmp";
                using (Stream fs = File.Open(tmpFilePath, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    new DataContractSerializer(typeof(List<Task>)).WriteObject(fs, tasks);
                }
                // delete the original file
                if (File.Exists(tasksFilePath))
                {
                    File.Delete(tasksFilePath);
                }
                // move the temporary file to the original tasks file
                File.Move(tmpFilePath, tasksFilePath);
                return true;
            }
            catch (SerializationException)
            {
                // TODO: log the error
                return false;
            }
            catch (IOException)
            {
                // TODO: log the error
                return false;
            }
            catch (UnauthorizedAccessException)
            {
                // TODO: log the error
                return false;
            }
        }

        bool TryAddTask(Task task)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Add(task);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        bool TryRemoveTask(Task task)
        {
            List<Task> newTasks = new List<Task>(this.tasks);
            newTasks.Remove(task);
            if (TrySaveTasks(newTasks))
            {
                // The new task list could be saved. Update the in-memory task list copy
                this.tasks = newTasks;
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }

    public class Task
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string AssignedTo { get; set; }
        public DateTime Deadline { get; set; }
        public string Details { get; set; }
        public DateTime UpdatedTime { get; set; }
    }
}