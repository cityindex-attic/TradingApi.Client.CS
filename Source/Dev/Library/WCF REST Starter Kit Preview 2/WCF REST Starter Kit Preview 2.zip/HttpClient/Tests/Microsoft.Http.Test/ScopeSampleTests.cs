//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

namespace Microsoft.Http.Test
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Diagnostics;


    [TestClass]
    public class ScopeClientTests
    {

        [TestMethod]
        public void TestAbsolute()
        {
            var client = new HttpClient("http://localhost/x");
            Assert.AreEqual("http://localhost/x", client.BaseAddress.ToString());
            Assert.IsTrue(client.BaseAddress.IsAbsoluteUri);
        }


        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestFragmentFails()
        {
            new HttpClient()
                {
                    Stages = { new UriScopeStage(new Uri("http://x/#fragment")) }
                };
        }
        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestGetWithNullUriFails()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage()
                {
                    Method = "GET",
                    Uri = null
                };
            using (var r = client.Send(request))
            {
                Console.WriteLine(r);
            }
        }

        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestGetWithRelativeUriFails()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage("GET", "/x/y");

            client.Send(request).Dispose();
        }
        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestQueryFails()
        {
            new HttpClient()
                {
                    Stages = { new UriScopeStage(new Uri("http://localhost/x?y=1")) }
                };
        }
        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestRelativeFails()
        {
            new HttpClient()
                {
                    Stages = { new UriScopeStage(new Uri("/x", UriKind.Relative)) }
                };
        }

        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestRelativeOrAbsFails()
        {
            new HttpClient()
                {
                    Stages = { new UriScopeStage(new Uri("/x", UriKind.RelativeOrAbsolute)) }
                };
        }


        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestUserInfoFails()
        {
            new HttpClient()
                {
                    Stages = { new UriScopeStage(new Uri("http://user:password@www.contoso.com/index.htm")) }
                };
        }


    }

    [TestClass]
    public class ScopeTests
    {

        protected bool ChangeUriToEither;

        static readonly List<string> messages = new List<string>();

        public TestContext TestContext
        {
            get;
            set;
        }
        public static Uri Absolute(string abs)
        {
            return new Uri(abs, UriKind.Absolute);
        }

        [ClassCleanup]
        public static void Cleanup()
        {
            foreach (var m in messages.OrderBy((x) => x))
            {
                Trace.WriteLine(m);
            }
        }
        public static Uri Either(string either)
        {
            return new Uri(either, UriKind.RelativeOrAbsolute);
        }

        public static Uri Relative(string relative)
        {
            return new Uri(relative, UriKind.Relative);
        }
        [TestMethod]
        public void Test10()
        {
            Check("http://x/y/", Absolute("http://x/a"), null);
        }
        [TestMethod]
        public void Test11()
        {
            Check("http://x/y", Relative("a"), null);
        }

        [TestMethod]
        public void Test12()
        {
            Check(null, Relative("#fragment"), null);
        }
        [TestMethod]
        public void Test13()
        {
            Check(null, Absolute("http://x/y/z"), "http://x/y/z");
        }
        [TestMethod]
        public void Test2()
        {
            Check("http://x", Relative("y"), "http://x/y");
        }
        [TestMethod]
        public void Test3()
        {
            Check("http://x/y/", Relative("#fragment"), "http://x/y/#fragment");
        }
        [TestMethod]
        public void Test4()
        {
            Check("http://x/y", Relative(""), "http://x/y");
        }
        [TestMethod]
        public void Test5()
        {
            Check("http://x/y", Relative("#fragment"), "http://x/y#fragment");
        }

        [TestMethod]
        public void Test6()
        {
            Check("http://x/y/", Relative("z"), "http://x/y/z");
        }

        [TestMethod]
        public void Test7()
        {
            Check("http://x", Absolute("http://x/y"), "http://x/y");
        }

        [TestMethod]
        public void Test8()
        {
            Check("http://x", Absolute("https://x/y"), null);
        }
        [TestMethod]
        public void Test9()
        {
            Check("http://x/y/", Relative("../../a"), null);
        }

        void Check(string baseAddress, Uri uri, string expected)
        {
            if (ChangeUriToEither)
            {
                Console.WriteLine("changed to either");
                uri = new Uri(uri.OriginalString, UriKind.RelativeOrAbsolute);
            }

            var client = new HttpClient();
            Uri scope = null;
            if (!string.IsNullOrEmpty(baseAddress))
            {
                scope = Absolute(baseAddress);
                client.Stages.Add(new UriScopeStage(scope));
            }
            Uri effective;
            string got;
            string message = "";
            try
            {
                effective = UriScopeStage.CalculateAndCheckAddress(scope, uri);
                message = string.Format("{0}, {1}, -> ,{2}", baseAddress, uri, effective);
                got = effective.ToString();
                Assert.IsTrue(effective.IsAbsoluteUri);
            }
            catch (Exception e)
            {
                message = string.Format("{0}, {1}, -> ,{2}", baseAddress, uri, e.GetType());
                got = null;
            }
            finally
            {
                Console.WriteLine(message);
                messages.Add(string.Format("{0,-100} {1}", message + ",", this.TestContext.TestName));
            }
            Assert.AreEqual(expected, got, message);
        }
    }

    [TestClass]
    public class ScopeWithEither : ScopeTests
    {
        [TestInitialize]
        public void Initialize()
        {
            this.ChangeUriToEither = true;
        }

        [TestMethod]
        public void TestEither1()
        {
            Assert.IsTrue(Either("http://localhost").IsAbsoluteUri);
            Assert.IsFalse(Either("x/z").IsAbsoluteUri);
        }
    }
}
