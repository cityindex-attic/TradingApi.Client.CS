//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------


namespace Microsoft.Http.Test
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Http;
    using System.Diagnostics;
    using System.Threading;
    using Microsoft.Http.Headers;

    public abstract class AddressTestsBase
    {

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestEmptyMethodSendFails()
        {
            Send(new HttpClient("http://localhost"), new HttpRequestMessage()
                {
                    Method = ""
                });

        }

        [TestMethod]
        public void TestHttpDefaultHeaders()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost");
            client.DefaultHeaders.Add("customheader", "default");
            client.DefaultHeaders.Add("multi", "x");
            client.DefaultHeaders.Add("multi", "y");
            client.DefaultHeaders.Add("onlyifnotthere", "default");
            client.DefaultHeaders.IfRange = new EntityTag("hello");
            var req = new HttpRequestMessage();
            req.Headers.Add("onlyifnotthere", "request");
            using (var response = Send(client, req))
            {
                var request = response.Request;
                Assert.AreEqual("GET", request.Method);
                Assert.AreEqual("http://localhost/", request.Uri.ToString());
                Assert.AreEqual("hello", request.Headers.IfRange.EntityTag.Tag);
                Assert.AreEqual("default", request.Headers["customheader"]);
                Assert.AreEqual("x, y", request.Headers["multi"]);
                CollectionAssert.AreEqual("x y".Split(), request.Headers.GetValues("multi").ToArray());
                Assert.AreEqual("request", request.Headers["onlyifnotthere"]);
            }
        }

        [TestMethod]
        public void TestHttpMethodIsGet()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost");
            using (var response = Send(client, new HttpRequestMessage()))
            {
                var request = response.Request;
                Assert.AreEqual("GET", request.Method);
                Assert.AreEqual("http://localhost/", request.Uri.ToString());
            }
        }
        [TestMethod]
        public void TestHttpRelative()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost");
            using (var response = Send(client, new HttpRequestMessage("GET", "/x/y")))
            {
                var request = response.Request;
                Assert.AreEqual("GET", request.Method);
                Assert.AreEqual("http://localhost/x/y", request.Uri.ToString());
            }
        }
        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestNull2Fails()
        {
            var client = new HttpClient();
            Send(client, new HttpRequestMessage("GET", (Uri) null));
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestNullFails()
        {
            var client = new HttpClient();
            Send(client, null);
        }
        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestNullMethodSendFails()
        {
            Send(new HttpClient("http://localhost"), new HttpRequestMessage()
                {
                    Method = null
                });

        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestNullRequestWithBaseAddressFails()
        {
            var client = new HttpClient("http://localhost");
            Send(client, null);
        }
        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestNullRequestWithoutBaseAddressFails()
        {
            var client = new HttpClient("http://localhost");
            Send(client, null);
        }
        protected HttpResponseMessage Send(HttpClient client, HttpRequestMessage request)
        {
            try
            {
                var response = SendCore(client, request);
                Console.WriteLine(response.Request + " -> " + response);
                return response;
            }
            catch (HttpStageProcessingException e)
            {
                Console.WriteLine(e);
                if (request != null)
                {
                    Assert.IsTrue(request.HasBeenSent);
                    request.Dispose();
                }
                throw;
            }
            catch (ArgumentException)
            {
                if (request != null)
                {
                    Assert.IsFalse(request.HasBeenSent);
                    request.Dispose();
                }
                throw;
            }
        }
        protected abstract HttpResponseMessage SendCore(HttpClient client, HttpRequestMessage request);
    }

    [TestClass]
    public class AddressTestsSendAsync : AddressTestsBase
    {
        protected override HttpResponseMessage SendCore(HttpClient client, HttpRequestMessage request)
        {
            var mre = new ManualResetEvent(false);
            HttpResponseMessage response = null;
            Exception ex = null;
            EventHandler<SendCompletedEventArgs> handler = (c, args) =>
            {
                if (args.Error != null)
                {
                    ex = args.Error;
                }
                else
                {
                    response = args.Response;
                }
                mre.Set();
            };
            client.SendCompleted += handler;
            client.SendAsync(request);
            mre.WaitOne();
            client.SendCompleted -= handler;
            if (ex != null)
            {
                throw ex;
            }
            return response;
        }
    }
    [TestClass]
    public class AddressTestsBeginEndSend : AddressTestsBase
    {
        protected override HttpResponseMessage SendCore(HttpClient client, HttpRequestMessage request)
        {
            var result = client.BeginSend(request, null, null);
            result.AsyncWaitHandle.WaitOne();
            return client.EndSend(result);
        }
    }
    [TestClass]
    public class AddressTestsSend : AddressTestsBase
    {
        protected override HttpResponseMessage SendCore(HttpClient client, HttpRequestMessage request)
        {
            return client.Send(request);
        }
    }

    [TestClass]
    public class BaseAddressTests
    {
        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestRelativeFails()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("/x/y", UriKind.Relative);
        }

        [TestMethod, ExpectedException(typeof(UriFormatException))]
        public void TestRelativeOrAbsFails()
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri("/x", UriKind.RelativeOrAbsolute);
        }


    }
}
