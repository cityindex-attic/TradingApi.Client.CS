//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Text;
    using System.Xml;
    using System.Xml.Linq;
    using Microsoft.Http;
    using Microsoft.Http.Headers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using HttpRequestHeader = System.Net.HttpRequestHeader;
    using HttpResponseHeader = System.Net.HttpResponseHeader;
    using WebHeaderCollection = System.Net.WebHeaderCollection;

    [TestClass]
    public class ParityTests
    {

        static HashSet<string> missed = new HashSet<string>();

        [ClassCleanup]
        public static void TestCleanup()
        {
            foreach (var x in missed.OrderBy((s) => s))
            {
                Console.WriteLine(x);
            }
        }
        [TestMethod, Ignore]
        // using same type for general + entity
        public void TestEntityParity()
        {
            var spec = ParseSpec(@"
Allow                
Content-Encoding     
Content-Language     
Content-Length       
Content-Location     
Content-MD5          
Content-Range        
Content-Type         
Expires              
Last-Modified     
");
            // var ent = GetHeaderProperties(typeof(EntityHeaders));
            var ent = GetHeaderProperties(typeof(HttpHeaders));
            Diff(spec, ent);
        }

        [TestMethod]
        public void TestEnum()
        {
            var h = new RequestHeaders();
            foreach (var k in h.Keys)
            {
                Console.WriteLine(k + " " + h.GetValues(k));
            }
        }

        [TestMethod, Ignore]
        // using same type for general + entity
        public void TestGeneralParity()
        {
            var spec = ParseSpec(@"
Cache-Control       
Connection          
Date                
Pragma              
Trailer             
Transfer-Encoding   
Upgrade             
Via                 
Warning");
            var req =
                GetHeaderProperties(typeof(HttpHeaders))
                // .Except(GetHeaderProperties(typeof(EntityHeaders)))
                .ToArray();
            Diff(spec, req);
            // Transfer-Encoding: deflate,chunked
        }

        [TestMethod]
        public void TestRequestParity()
        {
            var skip = "KeepAlive Translate".Split();
            var ncl = Enum.GetValues(typeof(HttpRequestHeader)).Cast<HttpRequestHeader>().Select((h) => h.ToString()).Except(skip).ToArray();
            var req = GetHeaderProperties(typeof(RequestHeaders));

            // Translate header: http://msdn.microsoft.com/en-us/library/cc214894(PROT.10).aspx
            Diff(ncl, req);
        }

        [TestMethod]
        public void TestResponseParity()
        {
            var skip = "KeepAlive".Split();
            var ncl = Enum.GetValues(typeof(HttpResponseHeader)).Cast<HttpResponseHeader>().Select((h) => h.ToString()).Except(skip).ToArray();
            var resp = GetHeaderProperties(typeof(ResponseHeaders));
            Diff(ncl, resp);
        }

        static void Diff(string[] ncl, string[] headerProperties)
        {
            Array.Sort(ncl);
            Array.Sort(headerProperties);

            foreach (var x in ncl.Intersect(headerProperties, StringComparer.OrdinalIgnoreCase))
            {
                Trace.WriteLine("done: " + x);
            }
            foreach (var x in ncl.Except(headerProperties, StringComparer.OrdinalIgnoreCase))
            {
                Console.WriteLine("miss: " + x);
                missed.Add(x);
            }
            foreach (var x in headerProperties.Except(ncl, StringComparer.OrdinalIgnoreCase))
            {
                Console.WriteLine("Extra: " + x);
            }
            CollectionAssert.AreEquivalent(ncl.Select((s) => s.ToLowerInvariant()).ToList(), headerProperties.Select((s) => s.ToLowerInvariant()).ToList());
        }
        static string[] ParseSpec(string spec)
        {
            return spec.Trim().Replace("-", "").Split().Select((s) => s.Trim()).Distinct().Where((s) => !string.IsNullOrEmpty(s)).ToArray();
        }

        string[] GetHeaderProperties(Type type)
        {
            return type.GetProperties().Select((p) => p.Name).Where((x) => x != "Item" && x != "Keys").ToArray();
        }
    }

    [TestClass]
    public class HeaderTests
    {

        public static string ToHttpDateTime(DateTime dateTime)
        {
            return Headers.HeaderFormatter.Default.ToString(dateTime);
        }

        [TestMethod]
        public void TestAccept()
        {
            // Accept: audio/*; q=0.2, audio/basic
            var req = new RequestHeaders();
            req.Accept.Add(CT("audio/*; q=0.2"));
            req.Accept.Add(CT("audio/basic"));

            var line = req.Accept.ToString();
            Assert.AreEqual("audio/*;q=0.2, audio/basic", line);
            Assert.AreEqual("audio/*;q=0.2, audio/basic", req["Accept"]);
            Assert.AreEqual("audio/*;q=0.2, audio/basic", req["accept"]);

            req.Accept = CT("audio/x");
            Console.WriteLine(req.Accept);
        }

        [TestMethod]
        public void TestAccept2()
        {
            var h = new RequestHeaders();
            Assert.AreEqual("", h.ToString());
            h.Accept.Add(CT("a/b"));
            Assert.AreEqual("Accept: a/b", h.ToString());
            h.Add("Accept", "b/c");
            Assert.AreEqual(2, h.Accept.Count);
            h.Accept.Add(CT("c/d"));
            Assert.AreEqual(3, h.Accept.Count);
            Assert.IsNull(h.ContentType);
            Assert.AreEqual("Accept: a/b, b/c, c/d", h.ToString());
            h.Accept.Last().Quality = 1.0;
            Assert.AreEqual("Accept: a/b, b/c, c/d;q=1.0", h.ToString());
            h.Accept[0] = CT("x/y");
            Assert.AreEqual("Accept: x/y, b/c, c/d;q=1.0", h.ToString());
            h.Accept[0].Quality = 0.0;
            Assert.AreEqual("Accept: x/y;q=0.0, b/c, c/d;q=1.0", h.ToString());
            var before = h.Accept;
            var newList = new HeaderValues<StringWithOptionalQuality>() { CT("m/n") };
            h.Accept = newList; // set to a list
            Assert.AreEqual("Accept: m/n", h.ToString());
            Assert.IsTrue(object.ReferenceEquals(newList, h.Accept));
            Assert.AreEqual(3, before.Count);
        }

        [TestMethod]
        public void TestAccept3()
        {
            var acceptHeader = "text/*, text/html, text/html;level=1, */*";
            var whc = new WebHeaderCollection();
            foreach (var s in acceptHeader.Split(','))
            {
                var h = s.Trim();
                Console.WriteLine(h + " " + CT(h));
                whc.Add("Accept", h);
            }
            Console.WriteLine(whc.ToString());
            Assert.AreEqual("Accept: " + acceptHeader.Replace(", ", ","), whc.ToString().Trim());
        }
        [TestMethod]
        public void TestAcceptCollectionToNewCollection()
        {
            var h = new RequestHeaders();
            h.Accept.Add(CT("a/b"));
            h.Add("Accept", "b/c");
            h.Add("Accept", "c/d");
            var before = h.Accept;
            Assert.AreEqual(3, h.Accept.Count);
            Assert.AreEqual(3, before.Count);
            var newList = new HeaderValues<StringWithOptionalQuality>() { CT("x/y") };
            h.Accept = newList;
            Assert.AreEqual("Accept: x/y", h.ToString());
            Assert.IsNotNull(h.Accept);
            Assert.AreEqual(3, before.Count);
            Assert.AreEqual(1, h.Accept.Count);
            Assert.AreEqual(1, newList.Count);

            newList.Add(CT("y/z"));
            Assert.AreEqual(2, h.Accept.Count);
            Assert.AreEqual(2, newList.Count);
        }

        [TestMethod]
        public void TestAcceptCollectionToNull()
        {
            var h = new RequestHeaders();
            h.Accept.Add(CT("a/b"));
            h.Add("Accept", "b/c");
            var before = h.Accept;
            Assert.AreEqual(2, h.Accept.Count);
            Assert.AreEqual(2, before.Count);
            h.Accept = null;
            Assert.AreEqual("", h.ToString());
            Assert.IsNotNull(h.Accept);
            Assert.AreEqual(0, h.Accept.Count);
            Assert.AreEqual(2, before.Count);
        }

        [TestMethod]
        public void TestAcceptPrecedence()
        {
            var whc = new WebHeaderCollection();
            var acceptHeader = "text/*;q=0.3, text/html;q=0.7, text/html;level=1, text/html;level=2;q=0.4, */*;q=0.5";
            foreach (var s in acceptHeader.Split(','))
            {
                var h = s.Trim();
                var t = CT(h);
                Console.WriteLine("{0} {1}", t, t.Quality);
                whc.Add("Accept", h);
            }
            Assert.AreEqual(5, whc.GetValues("Accept").Length);
            Console.WriteLine(whc.ToString());

            whc.Add("X", "Fri, 31 Dec 1999 23:59:59 GMT");
            Console.WriteLine(whc.GetValues("X").Length);
            Console.WriteLine(whc["X"]);
        }
        [TestMethod]
        public void TestAcceptPrecedence2()
        {
            var whc = new WebHeaderCollection();
            var acceptHeader = "text/*;q=0.3, text/html;q=0.7, text/html;level=1, text/html;level=2;q=0.4, */*;q=0.5";
            foreach (var s in acceptHeader.Split(','))
            {
                var h = s.Trim();
                var t = CT(h);
                Console.WriteLine("{0} {1}", t, t.Quality);
                whc.Add("Accept", h);
            }
            Assert.AreEqual(5, whc.GetValues("Accept").Length);
            Console.WriteLine(whc.ToString());
            whc.Add("Accept-Encoding", null);
            Console.WriteLine(whc.ToString());

            // Console.WriteLine(whc.GetValues("not-there").Length);

            // Retry-After: Fri, 31 Dec 1999 23:59:59 GMT
            // Retry-After: 120
        }

        [TestMethod]
        public void TestAddLine()
        {
            var h = new HeaderStore();
            h.Add("H: x, y");
            h.Add("H: z");
            Assert.AreEqual("H: x, y\r\nH: z", h.ToString());

            var hs = h.GetCollection<string>("H");
            Assert.AreEqual(2, hs.Count);
        }
        [TestMethod]
        public void TestAllow()
        {
            var h = new RequestHeaders();
            h.Allow.Add("GET");
            h.Allow.Add("POST");

            Assert.AreEqual("Allow: GET, POST", h.ToString());
            h.Allow.Clear();
            h.From = new System.Net.Mail.MailAddress("user@microsoft.com", "Display Name").ToString();
            Assert.AreEqual("From: \"Display Name\" <user@microsoft.com>", h.ToString());
        }

        [TestMethod]
        public void TestAuthentication()
        {
            var h = ResponseHeaders.Parse(@"WWW-Authenticate: Digest realm=""testrealm@host.com"",
                 qop=""auth,auth-int"",
                 nonce=""dcd98b7102dd2f0e8b11d0f600bfb0c093"",
                 opaque=""5ccc069c403ebaf9f0171e9517f40e41""");
            Assert.AreEqual(4, h.WwwAuthenticate.Parameters.Count);
            Assert.AreEqual("testrealm@host.com", h.WwwAuthenticate.GetParameter("realm"));
            Assert.AreEqual("auth,auth-int", h.WwwAuthenticate.GetParameter("qop"));
            Console.WriteLine(h.WwwAuthenticate);

            var req = RequestHeaders.Parse(@"Authorization: Digest username=""Mufasa"",
                 realm=""testrealm@host.com"",
                 nonce=""dcd98b7102dd2f0e8b11d0f600bfb0c093"",
                 uri=""/dir/index.html"",
                 qop=auth,
                 nc=00000001,
                 cnonce=""0a4f113b"",
                 response=""6629fae49393a05397450978507c4ef1"",
                 opaque=""5ccc069c403ebaf9f0171e9517f40e41""".Trim());
            Assert.AreEqual("Digest", req.Authorization.Scheme);
            Assert.AreEqual("Mufasa", req.Authorization.GetParameter("username"));
            Assert.AreEqual("testrealm@host.com", req.Authorization.GetParameter("realm"));
            Assert.AreEqual(9, req.Authorization.Parameters.Count);
            Assert.AreEqual(0, new Credential().Parameters.Count);
            Console.WriteLine(req.Authorization);
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestBadETagFails()
        {
            EntityTag.Parse("\"hello");
        }

        [TestMethod]
        public void TestCacheControl()
        {
            var cc = new CacheControl();
            Assert.AreEqual("", cc.ToString());
            cc.MaxAge = TimeSpan.FromSeconds(1);
            cc.MaxStale = true;
            cc.MaxStaleLimit = TimeSpan.FromSeconds(2);
            cc.MinFresh = TimeSpan.FromSeconds(3);
            cc.MustRevalidate = true;
            cc.NoCache = true;
            Assert.AreEqual("no-cache, max-age=1, max-stale=2, min-fresh=3, must-revalidate", cc.ToString());
            cc.NoCacheHeaders.Add("x");
            cc.NoCacheHeaders.Add("y");
            cc.NoStore = true;
            cc.NoTransform = true;
            cc.OnlyIfCached = true;
            cc.Private = true;
            cc.PrivateHeaders.Add("px");
            cc.PrivateHeaders.Add("py");
            cc.ProxyRevalidate = true;
            cc.Public = true;
            cc.SharedMaxAge = TimeSpan.FromSeconds(4);
            cc.Extensions.Add("ext1");
            Assert.AreEqual(@"no-cache=""x, y"", no-store, max-age=1, max-stale=2, min-fresh=3, must-revalidate, no-transform, only-if-cached, private=""px, py"", proxy-revalidate, public, s-maxage=4, ext1", cc.ToString());

            var h = new RequestHeaders();
            var s = cc.ToString();
            h.CacheControl = cc;
            // Console.WriteLine(h);
            h["Cache-Control"] = s;
            Console.WriteLine(s);
            Console.WriteLine(h.CacheControl);
            Console.WriteLine();
            Console.WriteLine(cc.ToString());
            Console.WriteLine(h.CacheControl.ToString());
            Assert.AreEqual(cc.ToString(), h.CacheControl.ToString());
        }

        [TestMethod]
        public void TestCacheControl2()
        {
            var cc = new CacheControl();
            Assert.AreEqual("", cc.ToString());
            cc.NoCache = true;
            Assert.AreEqual("no-cache", cc.ToString());
            cc.Extensions.Add("ext1");
            Assert.AreEqual(@"no-cache, ext1", cc.ToString());

            var h = new RequestHeaders();
            var s = cc.ToString();
            h.CacheControl = cc;
            // Console.WriteLine(h);
            h["Cache-Control"] = s;
            Console.WriteLine(s);
            Console.WriteLine(h.CacheControl);
            var ex = h.Expect;
            Assert.AreEqual(cc.ToString() + Environment.NewLine, h.CacheControl.ToString() + Environment.NewLine);
        }
        [TestMethod]
        public void TestCacheControl3()
        {
            var cc = new CacheControl();
            Assert.AreEqual("", cc.ToString());
            cc.MaxAge = TimeSpan.FromSeconds(1);
            cc.MaxStale = true;
            cc.MinFresh = TimeSpan.FromSeconds(3);
            cc.MustRevalidate = true;
            cc.NoCache = true;
            Assert.AreEqual("no-cache, max-age=1, max-stale, min-fresh=3, must-revalidate", cc.ToString());
            cc.NoCacheHeaders.Add("x");
            cc.NoCacheHeaders.Add("y");
            cc.NoStore = true;
            cc.NoTransform = true;
            cc.OnlyIfCached = true;
            cc.Private = true;
            cc.ProxyRevalidate = true;
            cc.Public = true;
            cc.SharedMaxAge = TimeSpan.FromSeconds(4);
            cc.Extensions.Add("ext1");
            Assert.AreEqual(@"no-cache=""x, y"", no-store, max-age=1, max-stale, min-fresh=3, must-revalidate, no-transform, only-if-cached, private, proxy-revalidate, public, s-maxage=4, ext1", cc.ToString());

            var h = new RequestHeaders();
            var s = cc.ToString();
            h.CacheControl = cc;
            // Console.WriteLine(h);
            h["Cache-Control"] = s;
            Console.WriteLine(s);
            Console.WriteLine(h.CacheControl);
            Console.WriteLine();
            Console.WriteLine(cc.ToString());
            Console.WriteLine(h.CacheControl.ToString());
            Assert.AreEqual(cc.ToString(), h.CacheControl.ToString());
        }

        [TestMethod]
        public void TestCharset()
        {
            var h = RequestHeaders.Parse(
                @"Accept-Charset: iso-8859-5, unicode-1-1;q=0.8
            Accept-Encoding: gzip;q=1.0, identity; q=0.5, *;q=0
            Accept-Language: da, en-gb;q=0.8, en;q=0.7");

            var acceptCharset = h.store.GetCollection<StringWithOptionalQuality>("Accept-Charset").ToArray();
            var acceptEnc = h.store.GetCollection<StringWithOptionalQuality>("Accept-Encoding").ToArray();
            var acceptLang = h.store.GetCollection<StringWithOptionalQuality>("Accept-Language").ToArray();
            Assert.AreEqual(3, acceptEnc.Length);
            Assert.AreEqual(3, h.AcceptEncoding.Count);
            Assert.AreEqual(3, h.AcceptEncoding.ToArray().Length);

            CollectionAssert.AreEqual(acceptLang, h.AcceptLanguage.ToArray());

            List<StringWithOptionalQuality> enc = new List<StringWithOptionalQuality>()
                {
                    new StringWithOptionalQuality("gzip", 1.0),
                    new StringWithOptionalQuality("identity", 0.5),
                    new StringWithOptionalQuality("*", 0)
                };
            CollectionAssert.AreEqual(enc, acceptEnc);

            List<StringWithOptionalQuality> ch = new List<StringWithOptionalQuality>()
                {
                    new StringWithOptionalQuality("iso-8859-5"),
                    new StringWithOptionalQuality("unicode-1-1", 0.8),
                };
            CollectionAssert.AreEqual(ch, acceptCharset);
            CollectionAssert.AreEqual(ch, h.AcceptCharset.ToArray());
        }

        [TestMethod]
        public void TestConnection()
        {
            var h = RequestHeaders.Parse(@"Connection: Upgrade".Trim());

            Assert.AreEqual("Upgrade", h.Connection.ToString());
            Assert.AreEqual("Upgrade", h.Connection.Headers.Single());

            h.Connection = new Connection()
                {
                    Close = true,
                };

            Assert.AreEqual("Connection: close", h.ToString());
            Assert.AreEqual(0, h.Connection.Headers.Count);
        }
        [TestMethod]
        public void TestConsistency()
        {
            CheckConsistency(new RequestHeaders());
            CheckConsistency(new ResponseHeaders());
        }

        [TestMethod]
        public void TestContentEncoding()
        {
            var h = new RequestHeaders();
            h.ContentEncoding.Add(ContentCoding.GZip);
            Assert.AreEqual("Content-Encoding: gzip", h.ToString());
        }
        [TestMethod]
        public void TestContentMD5()
        {
            var h = new RequestHeaders();
            h.ContentMD5 = Convert.FromBase64String("Q2hlY2sgSW50ZWdyaXR5IQ==");
            Assert.AreEqual("Content-MD5: Q2hlY2sgSW50ZWdyaXR5IQ==", h.ToString());
        }

        [TestMethod]
        public void TestContentRange()
        {
            Check("bytes 0-499/1234", 0, 499, 1234);
            Check("bytes */*", null, null, null);
            Check("bytes 1-12/*", 1, 12, null);
            Check("bytes */1234", null, null, 1234);
        }
        [TestMethod]
        public void TestContentType()
        {
            var h = new RequestHeaders();
            h.Add("Content-Type", "image/gif");
            Assert.AreEqual("Content-Type: image/gif", h.ToString());

            h.ContentType = "text/html"; // set == overwrite
            Assert.AreEqual("Content-Type: text/html", h.ToString());

            h.Add("Content-Type", "image/jpeg"); // the property is single but we can always "break" that at the string layer
            Assert.AreEqual("Content-Type: text/html, image/jpeg", h.ToString());

            try
            {
                Console.WriteLine(h.ContentType); // throws because multiple values are present
                Assert.Fail("should have thrown above");
            }
            catch (NotSupportedException nse)
            {
                Assert.AreEqual("2 values for Content-Type", nse.Message);
            }

            var multiple = h.store.GetCollection<StringWithOptionalQuality>("Content-Type"); // works
            Assert.AreEqual(2, multiple.Count);
        }

        [TestMethod, ExpectedException(typeof(FormatException))]
        public void TestContentTypeInvalidFails()
        {
            var h = new RequestHeaders();
            h["Accept"] = "x/y;q=12a";
            Console.WriteLine(h.Accept[0]);
        }

        [TestMethod]
        public void TestCookieHeader()
        {
            var resp = ResponseHeaders.Parse(
                @"
Set-Cookie: mkt1=norm=US; domain=.live.com; path=/
Set-Cookie: mkt2=ui=en-US; domain=www.live.com; path=/
Set-Cookie: AFORM=NOFORM; expires=Mon, 20-Jul-2015 23:59:59 GMT; path=/
Set-Cookie: MUID=BE17825CD48340ACBEC2DCBA69563883; expires=Mon, 20-Jul-2015 23:59:59 GMT; domain=.live.com; path=/
Set-Cookie: OrigMUID=BE17825CD48340ACBEC2DCBA69563883; expires=Mon, 20-Jul-2015 23:59:59 GMT; domain=.live.com; path=/
Set-Cookie: RMS=T=8; path=/
Set-Cookie: SRCHSESS=GUID=6EAE1C78204E4AEEB06D938555C26BC6&flt=0&PerfTracking=0&DomainVertical=0&TS=1229728308; expires=Fri, 19-Dec-2008 23:31:48 GMT; path=/
Set-Cookie: SRCHUID=V=2&GUID=104B29CA139C4945B530C816ABBA777F; expires=Mon, 20-Jul-2015 23:59:59 GMT; path=/
Set-Cookie: SRCHUSR=AUTOREDIR=0&GEOVAR=&DOB=20081219; expires=Sun, 19-Dec-2010 23:11:48 GMT; path=/
".Trim());
            Assert.AreEqual(9, resp.SetCookie.Count);
            Assert.AreEqual("norm=US", resp.SetCookie[0]["mkt1"]);
            Assert.AreEqual("/", resp.SetCookie[0].Path);
            Console.WriteLine(resp.SetCookie.ToString());
            foreach (var v in resp.SetCookie)
            {
                v.Add("flag");
                Console.WriteLine(v.Expires + " " + v.Path + " " + v.ToString().Length);
                if (v.Expires != null)
                {
                    v.Expires = v.Expires.Value.AddDays(1);
                }
                else
                {
                    v.Expires = null;
                }
            }
            Console.WriteLine(resp.SetCookie.ToString());
        }

        [TestMethod]
        public void TestDateOrEntityTag()
        {
            var h = new RequestHeaders();
            h.IfRange = new DateOrEntityTag();
            Assert.AreEqual("", h.ToString());
            h.IfRange = new DateOrEntityTag(DateTime.UtcNow);
            Console.WriteLine(h.ToString());
            h.IfRange = new DateOrEntityTag(EntityTag.Parse("W/\"test\""));
            h["If-Range"] = h.IfRange.ToString();
            Console.WriteLine(h.IfRange);
            Console.WriteLine(h.ToString());
            var d = DateTime.UtcNow;
            h.IfRange = d;
            Console.WriteLine(h);
            Console.WriteLine(d);
            Assert.AreEqual(d.ToString(), h.IfRange.Date.Value.ToString());
            Assert.AreEqual(d.Kind, h.IfRange.Date.Value.Kind);
        }

        [TestMethod]
        public void TestDateTime()
        {
            var req = new RequestHeaders();
            Assert.IsNull(req.IfModifiedSince);
            req.IfModifiedSince = DateTime.Now.Subtract(TimeSpan.FromDays(1));
            Assert.IsNotNull(req.IfModifiedSince);
            Console.WriteLine(req.ToString());
            req.IfModifiedSince = null;
            Assert.IsNull(req.IfModifiedSince);
            Assert.AreEqual("", req.ToString());
        }

        [TestMethod]
        public void TestDateTimeTyped()
        {
            var req = new RequestHeaders();
            Assert.IsNull(req.IfModifiedSince);
            req.Add("If-Modified-Since", DateTime.Now.Subtract(TimeSpan.FromSeconds(60)));
            Console.WriteLine("set via string: " + req.ToString());
            Assert.IsNotNull(req.IfModifiedSince);
            Console.WriteLine("touched property: " + req.ToString());
            req.IfModifiedSince = null;
            Assert.IsNull(req.IfModifiedSince);
            Assert.AreEqual("", req.ToString());
        }

        [TestMethod]
        public void TestDecimalAge()
        {
            var h = new ResponseHeaders();
            h["Age"] = "123.456";
            Console.WriteLine(h["Age"]);
            var before = h.ToString();
            Console.WriteLine(h);
            var t = h.Age;
            var after = h.ToString();
            Console.WriteLine(after);
            Assert.AreEqual(before, after);
        }

        [TestMethod]
        public void TestDirectAccess()
        {
            var h = new RequestHeaders();
            h.Add("Accept", CT("a/b").ToString());
            h.Add("Accept", CT("b/c").ToString());
            h.Add("Accept", CT("c/d").ToString());
            Assert.AreEqual(CT("a/b"), h.Accept[0]);
            Assert.AreEqual("Accept: a/b, b/c, c/d", h.ToString());
            h.Accept[1] = CT("e/f");
            Assert.AreEqual("Accept: a/b, e/f, c/d", h.ToString());
            Console.WriteLine(h);
        }

        [TestMethod]
        public void TestDisplayHeaderBlocks()
        {
            foreach (var x in Examples.HeaderBlocks)
            {
                Console.WriteLine();
                Console.WriteLine("@\"" + x.Replace("\"", "\"\"") + "\",");
                Console.WriteLine();
            }
        }

        [TestMethod]
        public void TestEnumeration()
        {
            foreach (var v in new RequestHeaders())
            {
                Console.WriteLine(v);
            }
            var h = new ResponseHeaders();
            h.Add("x", "y");
            h.Add("x", "z");
            foreach (var v in h)
            {
                Console.WriteLine(v);
            }
        }

        [TestMethod]
        public void TestETag()
        {
            var h = new RequestHeaders();
            h.Add("If-Match: \"xyzzy\", \"r2d2xxxx\", \"c3piozzzz\"");
            Assert.AreEqual(3, h.IfMatch.Count);
            h["If-Match"] = "*";
            Assert.AreEqual(1, h.IfMatch.Count);
            Assert.AreEqual("*", h.IfMatch[0].Tag);
            // is this correct? * isn't technically an EntityTag

        }
        [TestMethod]
        public void TestETags()
        {
            Action<string> check = (s) =>
            {
                Assert.AreEqual(s, EntityTag.Parse(s).ToString());

            };
            check("\"xyzzy\"");
            check("W/\"xyzzy\"");
            check("\"\"");

            Assert.AreEqual("hello", EntityTag.Parse("hello").Tag);
            Assert.AreEqual("\"hello\"", EntityTag.Parse("hello").ToString());
        }

        [TestMethod]
        public void TestExpect()
        {
            var h = new RequestHeaders();
            h.Expect = new Expect()
                {
                    Expect100Continue = true
                };
            Console.WriteLine(h);
            h.Connection = new Connection()
                {
                    Close = true
                };
            h.Connection.Close = true;
            Console.WriteLine(h);
            h.Connection.Close = false;
            Assert.AreEqual("Expect: 100-continue", h.ToString());
            h.Expect.Extensions.Add("extension");
            Assert.AreEqual("Expect: 100-continue, extension", h.ToString());
        }

        [TestMethod]
        public void TestHeaderBlocks()
        {
            foreach (var x in Examples.HeaderBlocks)
            {
                Console.WriteLine(x);
                Console.WriteLine();
                var basic = HeaderStore.Parse(x);
                var req = RequestHeaders.Parse(x);
                var resp = ResponseHeaders.Parse(x);
                Console.WriteLine(basic.GetType() + ": " + string.Join(",", basic.Keys.ToArray()));
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                DisplayProperties(req, seen);
                DisplayProperties(resp, seen);

                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
            }
        }

        [TestMethod]
        public void TestHeaders()
        {
            WebHeaderCollection w = new WebHeaderCollection();
            Console.WriteLine("Dictionary<HttpRequestHeader,string> requestHeaders = new Dictionary<HttpRequestHeader,string>() { ");
            Dictionary<string, int> count = new Dictionary<string, int>();
            foreach (HttpRequestHeader h in Enum.GetValues(typeof(HttpRequestHeader)))
            {
                w.Clear();
                w[h] = h.ToString();
                count.Add(h.ToString(), -1);
                Console.WriteLine("{" + h.GetType().Name + "." + h + ", \"" + w.AllKeys.Single() + "\"},");
            }
            Console.WriteLine("};");

            Console.WriteLine("Dictionary<HttpResponseHeader,string> responseHeaders = new Dictionary<HttpResponseHeader,string>() { ");
            w = new WebHeaderCollection();
            foreach (HttpResponseHeader h in Enum.GetValues(typeof(HttpResponseHeader)))
            {
                w.Clear();
                w[h] = h.ToString();
                var s = h.ToString();
                if (count.ContainsKey(s))
                {
                    count[s] = 2;
                }
                else
                {
                    count[s] = 1;
                }
                Console.WriteLine("{" + h.GetType().Name + "." + h + ", \"" + w.AllKeys.Single() + "\"},");
            }
            Console.WriteLine("};");

            foreach (var p in count)
            {
                Console.WriteLine(p.Key + "," + p.Value);
            }
        }

        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestInternalStringView1Fails()
        {
            Console.WriteLine(new HeaderString<int>().Value);
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestInternalStringView2Fails()
        {
            HeaderString sv = new HeaderString<int>();
            sv.Set("hello");
        }
        [TestMethod]
        public void TestLargeAge()
        {
            var h = new ResponseHeaders();
            var maxPerSpec = "2147483648";
            h["Age"] = maxPerSpec;
            Console.WriteLine(h["Age"]);
            Console.WriteLine(h);
            Console.WriteLine(h.Age);
        }
        [TestMethod]
        public void TestLargeAgeParses()
        {
            var h = new ResponseHeaders();
            var maxPerSpec = "2147483648";
            var larger = (long.Parse(maxPerSpec) + 11).ToString();
            h["Age"] = larger;
            Console.WriteLine(h["Age"]);
            Console.WriteLine(h);
            Console.WriteLine(h.Age);
        }

        [TestMethod]
        public void TestPragma()
        {
            var h = RequestHeaders.Parse("Pragma: LinkBW=2147483647, AccelBW=1048576, AccelDuration=5000");

            Assert.AreEqual(3, h.Pragma.Count);
            Assert.AreEqual("LinkBW=2147483647", h.Pragma[0]);
        }

        [TestMethod]
        public void TestPragma2()
        {
            var v = @"version-url=""http://codecs.microsoft.com/isapi/mpupgrade.dll"",features=""seekable, stridable""";
            var s = @"Pragma: " + v;

            var whc = new WebHeaderCollection();
            whc["Pragma"] = v;
            var q = whc.GetValues("Pragma");
            Assert.AreEqual(2, q.Length);
            foreach (var x in q)
            {
                Console.WriteLine("*" + x + "*");
            }
            var h = RequestHeaders.Parse(s);

            Assert.AreEqual(2, h.Pragma.Count);
            Console.WriteLine(h.Pragma.First());
        }
        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestQualityHighFails()
        {
            new StringWithOptionalQuality("s", 2);
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestQualityLowFails()
        {
            new StringWithOptionalQuality("s", -1);
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestQualitySemicolonInValueFails()
        {
            new StringWithOptionalQuality("gzip;q=1.0");
        }


        [TestMethod]
        public void TestRange()
        {
            var req = new RequestHeaders();
            req.Add("Content-Range: bytes 21010-47021/47022");
            req.Add("Range: bytes=0-0,-1");
            Console.WriteLine(req.Range);

            req.Range.Add(new ByteRange(-5));
            Console.WriteLine(req.Range);

            var ss = @"bytes=0-499
bytes=500-999
bytes=-500
bytes=9500-
bytes=0-0,-1
bytes=500-600,601-999
bytes=500-700,601-999
";
            Console.WriteLine(ss);
        }

        [TestMethod]
        public void TestRange1()
        {
            var h = new RequestHeaders();
            h.Range = new Range() { new ByteRange(1) };
            Console.WriteLine(h.ToString());
            h["Range"] = h.Range.ToString();
            Console.WriteLine(h.Range.ToArray().Length);
        }

        [TestMethodAttribute]
        public void TestRangeBind()
        {
            var h = new RequestHeaders();
            h.Range = new Range();
            h.Range.Add(new ByteRange(-1));
            Assert.AreEqual("Range: bytes=-1", h.ToString());
            h.Range.Add(new ByteRange(-2));
            Assert.AreEqual("Range: bytes=-1, -2", h.ToString());
            Assert.AreEqual("bytes=-1, -2", h.Range.ToString());
            Assert.AreEqual("bytes=-1, -2", h["Range"]);
            Console.WriteLine(h.Range);
            h.Range = null;
            Assert.AreEqual("", h.ToString());
            Console.WriteLine(h);
        }

        [TestMethod]
        public void TestRangeParse()
        {
            var h = new RequestHeaders();
            h.Add("Range", "bytes=0-0,-1");
            var r = h.Range;
            Console.WriteLine(h.Range.Count);
            var r2 = h.Range;
            Assert.AreSame(r, r2);
        }

        [TestMethod]
        public void TestReferer()
        {
            var req = new RequestHeaders();
            req.Add("Referer", "/xyz");
            Console.WriteLine(req.ToString());
            Console.WriteLine(req.Referer.ToString());
            req.Clear();

            req.Referer = new Uri("http://localhost");
            Console.WriteLine(req.ToString());
        }

        [TestMethod]
        public void TestRemoveContains()
        {
            var whc = new WebHeaderCollection();
            whc["Test"] = "123";
            Assert.IsTrue(whc.AllKeys.Contains("Test"));
            whc["Test"] = null;
            Assert.IsTrue(whc.AllKeys.Contains("Test"));
            whc.Remove("Test");
            Assert.IsFalse(whc.AllKeys.Contains("Test"));

            Console.WriteLine(whc.ToString());
            var h = new RequestHeaders();
            h["Test"] = "123";
            Assert.IsTrue(h.ContainsKey("Test"));
            Assert.IsTrue(h.ContainsKey("test"));
            h["Test"] = null;
            Assert.IsFalse(h.ContainsKey("test"));
            Assert.AreEqual("", h["Test"]);
            h.Remove("Test");
            Assert.IsFalse(h.ContainsKey("test"));

            Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            d["Test"] = "123";
            d["Test"] = null;
            Assert.IsTrue(d.ContainsKey("Test"));
        }

        [TestMethod]
        public void TestRemoveCount()
        {
            var h = new RequestHeaders();
            h["test"] = "1";
            Assert.AreEqual(1, h.Keys.Count());
            h["test"] = null;
            Assert.AreEqual("", h.ToString());
            Assert.AreEqual(0, h.Keys.Count());

        }

        [TestMethod]
        public void TestRetryAfter()
        {
            var h = new ResponseHeaders();
            h["Age"] = "123";
            Console.WriteLine(h.Age);
            h.Add("Retry-After: Fri, 31 Dec 1999 23:59:59 GMT");
            Assert.IsNotNull(h.RetryAfter.Date);
            Assert.IsNull(h.RetryAfter.Delta);
            Assert.IsFalse(h.RetryAfter.IsDelta);
            Console.WriteLine(h.RetryAfter.Date);

            h["Retry-After"] = "120";
            Assert.IsNull(h.RetryAfter.Date);
            Assert.IsNotNull(h.RetryAfter.Delta);
            Assert.IsTrue(h.RetryAfter.IsDelta);
            Assert.AreEqual(120, h.RetryAfter.Delta.Value.TotalSeconds);
            Assert.AreEqual("120", h.RetryAfter.ToString());
            Console.WriteLine(h);
        }
        [TestMethod]
        public void TestServer()
        {
            var s = "Apache/2.2.9 (Debian) DAV/2 SVN/1.5.1 mod_python/3.3.1 Python/2.5.2 mod_ssl/2.2.9 OpenSSL/0.9.8g mod_perl/2.0.4 Perl/v5.10.0";
            var h = new ResponseHeaders();
            h["Server"] = s;
            Assert.IsFalse(h.Server[0].IsComment);
            Assert.IsTrue(h.Server[1].IsComment);
            Assert.AreEqual("Apache/2.2.9", h.Server[0].ToString());
            Assert.AreEqual("2.2.9", h.Server[0].Product.Version);
            Assert.AreEqual("Debian", h.Server[1].Comment);
            Assert.AreEqual("(Debian)", h.Server[1].ToString());

            h.Server = new HeaderValues<ProductOrComment>()
                {
                    new ProductOrComment(Product.Parse("Apache/2.2.9")),
                    new ProductOrComment("Comment"),
                };

            Console.WriteLine(h.Server);
        }
        [TestMethod]
        public void TestSetThenType()
        {
            var req = new RequestHeaders();
            req["Accept"] = "audio/1, audio/2";
            var list = req.Accept;
            Assert.AreEqual(2, list.Count());
            req.Accept.Add(CT("audio/3"));
            Assert.AreEqual(3, req.Accept.Count());
            Assert.AreEqual(3, list.Count());
            Assert.AreEqual("audio/1, audio/2, audio/3", req.Accept.ToString());
            req.Accept.Clear();
            Assert.AreEqual(0, req.Accept.Count());
            Assert.AreEqual("", req.Accept.ToString());
            Assert.AreEqual("", req.ToString());
        }

        [TestMethod]
        public void TestStore()
        {
            var h = new HeaderStore();
            h.Add("test", "a");
            h.Add("test", "b");

            Assert.AreEqual("a, b", h["test"]);

            h.Add("xyz", 123);
            h.Add("xyza", new DateTime(2008, 1, 1));
            h.Add("abc", "\"b\"");

            Console.WriteLine(h.ToString());

            Assert.AreEqual(@"
test: a, b
xyz: 123
xyza: Tue, 01 Jan 2008 08:00:00 GMT
abc: ""b""".Trim(), h.ToString());
        }

        [TestMethod]
        public void TestStringWithQuality()
        {
            // A weight is normalized to a real number in the range 0 through 1, where 0 is the minimum and 1 the maximum value.
            // If a parameter has a quality value of 0, then content with this parameter is `not acceptable' for the client.
            // HTTP/1.1 applications MUST NOT generate more than three digits after the decimal point. 

            Assert.AreEqual("s;q=0.123", new StringWithOptionalQuality("s", 0.123456).ToString());
            Assert.AreEqual("s;q=0.0", new StringWithOptionalQuality("s", 0).ToString());
            Assert.AreEqual("s;q=0.5", new StringWithOptionalQuality("s", 0.5).ToString());
            Assert.AreEqual("s;q=1.0", new StringWithOptionalQuality("s", 1).ToString());
            Assert.AreEqual("s", new StringWithOptionalQuality("s", null).ToString());
            Assert.AreEqual("s", new StringWithOptionalQuality("s").ToString());
            Assert.AreEqual("s;q=0.0", new StringWithOptionalQuality("s", 0.0).ToString());

            // should be able to parse more than 3 digits, and only emit 3
            var x = StringWithOptionalQuality.Parse("s;q=0.123456");
            Assert.AreEqual(0.123456, x.Quality);
            Assert.AreEqual("s;q=0.123", x.ToString());

            Assert.AreEqual(StringWithOptionalQuality.Parse("s;q=0.123"), new StringWithOptionalQuality("s", 0.123456));
            Assert.AreEqual(StringWithOptionalQuality.Parse("s;q=0.0"), new StringWithOptionalQuality("s", 0));
            Assert.AreEqual(StringWithOptionalQuality.Parse("s;q=0.5"), new StringWithOptionalQuality("s", 0.5));
            Assert.AreEqual(StringWithOptionalQuality.Parse("s;q=1.0"), new StringWithOptionalQuality("s", 1));
            Assert.AreEqual(StringWithOptionalQuality.Parse("s"), new StringWithOptionalQuality("s", null));
            Assert.AreEqual(StringWithOptionalQuality.Parse("s"), new StringWithOptionalQuality("s"));
            Assert.AreEqual(StringWithOptionalQuality.Parse("s;q=0"), new StringWithOptionalQuality("s", 0.0));
        }

        [TestMethod]
        public void TestStringWithQualityHashing()
        {
            HashSet<StringWithOptionalQuality> h = new HashSet<StringWithOptionalQuality>();
            h.Add("test");
            h.Add(new StringWithOptionalQuality("test"));
            Assert.AreEqual(1, h.Count);
        }

        [TestMethod]
        public void TestTypedAndString()
        {
            var req = new RequestHeaders()
                {
                    Accept = { CT("audio/1"), CT("audio/2") }
                };

            req.Add("Accept", "audio/3");

            Console.WriteLine(req.ToString());
            Assert.AreEqual("Accept: audio/1, audio/2, audio/3", req.ToString());
            Assert.AreEqual("audio/1, audio/2, audio/3", req.Accept.ToString());
            Assert.AreEqual(CT("audio/3"), req.Accept.Last());
        }
        [TestMethod]
        public void TestTypedThenSet()
        {
            var req = new RequestHeaders();
            req.Accept.Add(CT("x/y"));
            var before = req.Accept;
            Assert.AreEqual(1, req.Accept.Count);
            req["Accept"] = "audio/1, audio/2";
            Assert.AreEqual(1, before.Count);
            var list = req.Accept;
            Assert.AreEqual(2, list.Count());
            req.Accept.Add(CT("audio/3"));
        }

        [TestMethod]
        public void TestUpgrade()
        {
            var h = new RequestHeaders();
            h["Upgrade"] = "HTTP/2.0, SHTTP/1.3, IRC/6.9, RTA/x11";

            Assert.AreEqual(4, h.Upgrade.Count);
            Assert.AreEqual("HTTP", h.Upgrade[0].Name);
            Assert.AreEqual("2.0", h.Upgrade[0].Version);

            h.Upgrade.Clear();
            h.Upgrade.Add(new Product()
                {
                    Name = "Xyz"
                });
            Assert.AreEqual("Upgrade: Xyz", h.ToString());
        }

        [TestMethod]
        public void TestUserAgent()
        {
            var s = @"Mozilla/5.0 (X11; U; Linux ppc; rv:1.7.3) Gecko/20041004 Firefox/0.10.1";
            var values = HeaderStore.ParseMultiValue(s, ' ', '(', ')');

            Assert.AreEqual(4, values.Count);
            Assert.AreEqual("(X11; U; Linux ppc; rv:1.7.3)", values[1]);
            var h = new RequestHeaders();
            h["User-Agent"] = s;
            Assert.AreEqual(4, h.UserAgent.Count);
        }

        [TestMethod]
        public void TestVia()
        {
            var x = Via.Parse("1.1 nowhere.com (Apache/1.1)");
            Assert.AreEqual("1.1", x.ProtocolVersion);
            Assert.AreEqual("HTTP", x.ProtocolName);
            Assert.AreEqual("nowhere.com", x.ReceivedBy.HostName);
            Assert.IsNull(x.ReceivedBy.Port);
            Assert.AreEqual("Apache/1.1", x.Comment);
            Assert.AreEqual("1.1 nowhere.com (Apache/1.1)", x.ToString());

            x = Via.Parse("HTTP/1.1 nowhere.com (Apache/1.1)");
            Assert.AreEqual("1.1", x.ProtocolVersion);
            Assert.AreEqual("HTTP", x.ProtocolName);
            Assert.AreEqual("nowhere.com", x.ReceivedBy.HostName);
            Assert.AreEqual("Apache/1.1", x.Comment);
            Assert.AreEqual("HTTP/1.1 nowhere.com (Apache/1.1)", x.ToString());

            x = Via.Parse("XYZ/ABC fred");
            Assert.AreEqual("XYZ", x.ProtocolName);
            Assert.AreEqual("ABC", x.ProtocolVersion);
            Assert.AreEqual("fred", x.ReceivedBy.HostName);
            Assert.AreEqual("XYZ/ABC fred", x.ToString());

            x = Via.Parse("XYZ/ABC fred:81 ( comment )");
            Assert.AreEqual("XYZ", x.ProtocolName);
            Assert.AreEqual("ABC", x.ProtocolVersion);
            Assert.AreEqual("comment", x.Comment);
            Assert.AreEqual("fred", x.ReceivedBy.HostName);
            Assert.AreEqual(81, x.ReceivedBy.Port);
            Assert.AreEqual("XYZ/ABC fred:81 (comment)", x.ToString());
        }

        [TestMethod]
        public void TestVia2()
        {
            var h = RequestHeaders.Parse("Via: 1.0 sq36.domain.org:3128 (squid/2.6.STABLE21), 1.0 sq32.domain.org:80 (squid/2.6.STABLE21), 1.0 MY-PRXY-03");

            foreach (var v in h.Via)
            {
                Console.WriteLine(v);
            }

            var a = h.Via[0];
            var b = h.Via[1];
            var c = h.Via[2];
            Assert.AreEqual(3, h.Via.Count);

            Assert.AreEqual("squid/2.6.STABLE21", a.Comment);
            Assert.AreEqual("1.0", a.ProtocolVersion);
            Assert.AreEqual("HTTP", a.ProtocolName);
        }

        [TestMethod, ExpectedException(typeof(FormatException))]
        public void TestViaNoVersionFails()
        {
            var h = new ResponseHeaders();
            h.Add("Via", "HTTPS");
            Console.WriteLine(h.Via);
        }

        [TestMethod]
        public void TestVias()
        {
            var headers = new string[] {
                    "HTTP/1.1 WMCacheProxy (WMCacheProxy/9.0.0.3177)",
                    "1.0 fred, 1.1 nowhere.com (Apache/1.1)",
                    "1.0 ricky, 1.1 mertz, 1.0 lucy",
                    "1.0 ricky, 1.1 ethel, 1.1 fred, 1.0 lucy",
                };
            foreach (var v in headers)
            {
                var h = new RequestHeaders();
                h["Via"] = v;

                foreach (var x in h.Via)
                {
                    Console.WriteLine(x);
                }

                Console.WriteLine();
            }
        }

        [TestMethod]
        public void TestWarning()
        {
            // warn-code SP warn-agent SP warn-text [SP warn-date]
            // Warning: 110 Response is stale, 111 Revalidation failed, 112 Disconnected operation,113 Heuristic expiration
            var wx = "110 singularity:8123 Object is stale";
            var w = Warning.Parse(wx);
            Assert.AreEqual(110, w.Code);
            Assert.AreEqual("singularity", w.Agent.HostName);
            Assert.AreEqual(8123, w.Agent.Port);
            Assert.AreEqual("Object is stale", w.Text);
            Assert.AreEqual(wx, w.ToString());
            var h = new RequestHeaders();
            h["Warning"] = "110 Response is stale, 111 Revalidation failed, 112 Disconnected operation,113 Heuristic expiration";

            Assert.AreEqual(4, h.Warning.Count);
            Assert.AreEqual(110, h.Warning[0].Code);
            Assert.AreEqual("110 Response is stale, 111 Revalidation failed, 112 Disconnected operation, 113 Heuristic expiration", h.Warning.ToString());
        }

        static void Check(string s, int? first, int? last, int? length)
        {
            var r = ContentRange.Parse(s);
            if (first != null)
            {
                Assert.AreEqual(first, r.FirstBytePosition);
                Assert.AreEqual(last, r.LastBytePosition);
            }
            else
            {
                Assert.IsTrue(r.RangeIsStar);
            }

            if (length != null)
            {
                Assert.AreEqual(length, r.Length);
            }
            else
            {
                Assert.IsTrue(r.LengthIsStar);
            }
            Assert.AreEqual(s, r.ToString());

            var h = new RequestHeaders();
            h.ContentRange = r;
            Assert.AreEqual("Content-Range: " + s, h.ToString());
        }

        static void CheckConsistency(object h)
        {
            foreach (var p in h.GetType().GetProperties().Where((p) => p.Name != "Item" && p.Name != "Keys").OrderBy((p) => p.Name))
            {
                var v = p.GetValue(h, null);
                Trace.WriteLine(p.PropertyType + " " + p.Name + " " + (v ?? (object) "null"));
                if (p.PropertyType.IsValueType)
                {
                    Assert.IsNull(v, p.Name);
                }
                var t = p.PropertyType;
                if (p.PropertyType.ToString().Contains(typeof(HeaderValues < > ).Name))
                {
                    Assert.IsNotNull(v, p.Name);
                    t = p.PropertyType.GetGenericArguments().Single();
                }
                else if (!p.PropertyType.IsArray && p.PropertyType != typeof(string) && typeof(System.Collections.IEnumerable).IsAssignableFrom(p.PropertyType))
                {
                    Console.WriteLine(p + "");
                }
                else
                {
                    // any other reference type should be null
                    Assert.IsNull(v, p.Name);
                }

                // any the string rep should be empty by default
                if (t.Assembly == typeof(Microsoft.Http.Headers.Cookie).Assembly)
                {
                    Assert.IsFalse(t.Name.EndsWith("Header"), p.ToString());
                    Assert.IsFalse(t.Name.StartsWith("Http"), p.ToString());
                    object def = null;
                    try
                    {
                        def = Activator.CreateInstance(t);
                    }
                    catch (Exception e)
                    {
                        Assert.Fail(p.PropertyType.ToString() + ": " + e);
                    }
                    if (!t.IsEnum)
                    {
                        Assert.AreEqual("", def.ToString(), p.PropertyType.ToString());
                    }
                }
                Assert.IsTrue(p.CanRead);
                Assert.IsTrue(p.CanWrite);

                p.SetValue(h, null, null);
            }
        }

        static StringWithOptionalQuality CT(string s)
        {
            return StringWithOptionalQuality.Parse(s);
        }

        private static void DisplayProperties(HttpHeaders h, HashSet<string> seen)
        {
            HashSet<string> empty = new HashSet<string>();
            foreach (var p in h.GetType().GetProperties().OrderBy((x) => x.Name))
            {
                if (p.Name == "Keys" || p.GetIndexParameters().Length != 0)
                {
                    continue;
                }
                var v = p.GetValue(h, null);
                if (v == null || string.IsNullOrEmpty(v.ToString()))
                {
                    empty.Add(p.Name);
                    continue;
                }
                if (seen.Contains(p.Name))
                {
                    continue;
                }

                if (v.GetType().IsGenericType && v.GetType().GetGenericTypeDefinition() == typeof(HeaderValues < > ))
                {
                    var e = (System.Collections.IEnumerable) v;
                    Assert.IsTrue(e.Cast<object>().Any());
                }

                seen.Add(p.Name);
                Console.WriteLine("{0,-10} {1,-15} {2}", p.DeclaringType.Name.Replace("Http", "").Replace("Headers", ""), p.Name, v);
            }
        }
    }

    class Examples
    {

        public static ReadOnlyCollection<string> HeaderBlocks = new string[] {
                @"Accept: */* 
User-Agent: NSPlayer/10.0.0.3802 
Host: SampleServer 
X-Accept-Authentication: Negotiate, MS-NLMP, Digest, Basic 
Pragma: no-cache,rate=1.000,stream-time=0,stream-offset=0:0,
packet-num=4294967295,max-duration=0 
Pragma: packet-pair-experiment=1 
Supported: com.microsoft.wm.srvppair, com.microsoft.wm.sswitch, 
com.microsoft.wm.predstrm, com.microsoft.wm.startupprofile",

                @"Accept: */*
User-Agent: NSServer/9.0.0.3171
Host: MyServer
Max-Forwards: 9
X-Accept-Authentication: Negotiate, MS-NLMP, Digest
Pragma: no-cache,rate=1.000,stream-time=0,stream-offset=0:0,
        packet-num=4294967295,max-duration=0
Supported: com.microsoft.wm.srvppair, com.microsoft.wm.sswitch, 
           com.microsoft.wm.predstrm
Pragma: xClientGUID={00000000-0000-0000-0000-000000000000}
Accept-Language: *",


                @"Accept: */*
User-Agent: NSServer/9.0.0.3171
Host: SampleServer
Max-Forwards: 9
Expect: 100-continue
X-Accept-Authentication: Negotiate, MS-NLMP, Digest
Pragma: no-cache,rate=1.000,stream-time=0,
        stream-offset=4294967295:4294967295,
        packet-num=4294967295,max-duration=0
Pragma: xPlayStrm=1
Pragma: client-id=1543854732
Pragma: LinkBW=2147483647, BurstBW=3500000, BurstDuration=5000
Supported: com.microsoft.wm.srvppair, com.microsoft.wm.sswitch, 
           com.microsoft.wm.predstrm
Pragma: xClientGUID={00000000-0000-0000-0000-000000000000}
Pragma: stream-switch-count=2
Pragma: stream-switch-entry=ffff:1:0 ffff:2:0 
Accept-Language: *",


                @"Connection: close
Date: Wed, 27 Jun 2007 02:54:23 GMT
Server: Microsoft-IIS/6.0
Content-Type: text/html",


                @"Content-Length: 5227 
Content-Type: application/vnd.ms.wms-hdr.asfv1 
Server: Cougar/9.01.01.3814 
Pragma: packet-pair-experiment=1, no-cache, client-id=2064325698, xResetStrm=1, 
features=""seekable,stridable"", timeout=60000 
Cache-Control: no-cache, x-wms-content-size=638066, x-wms-event-subscription=""remote-log"" 
Supported: com.microsoft.wm.srvppair, com.microsoft.wm.sswitch, 
com.microsoft.wm.predstrm, com.microsoft.wm.fastcache, 
com.microsoft.wm.startupprofile",

                @"Accept: */*
User-Agent: NSPlayer/9.0.0.2833
Host: SampleServer
X-Accept-Authentication: Negotiate, MS-NLMP, Digest
Pragma: no-cache, pl-offset=1,rate=1.000,stream-time=0,
        stream-offset=4294967295:4294967295,packet-num=4294967295,
        max-duration=0
Pragma: xPlayStrm=1
Pragma: client-id=3342451229
Pragma: LinkBW=2147483647, AccelBW=2147483647, AccelDuration=10000
Supported: com.microsoft.wm.srvppair, com.microsoft.wm.sswitch, 
           com.microsoft.wm.predstrm
Pragma: playlist-seek-id=115
Pragma: stream-switch-count=4
Pragma: stream-switch-entry=ffff:1:0 ffff:2:2 ffff:4:2 ffff:5:0
Accept-Language: en-us, *;q=0.1",
                @"Accept: */*
User-Agent: NSPlayer/9.0.0.2833
Host: SampleServer
X-Accept-Authentication: Negotiate, MS-NLMP, Digest
Pragma: client-id=2754698341
Pragma: xStopStrm=1
Content-Length: 0",

                @"Content-Length: 5227 
Content-Type: application/vnd.ms.wms-hdr.asfv1 
Server: Cougar/9.01.01.3814 
Pragma: packet-pair-experiment=1, no-cache, client-id=2064325698, xResetStrm=1, features=""seekable,stridable"", timeout=60000 
Cache-Control: no-cache, x-wms-content-size=638066, x-wms-event-subscription=""remote-log"" 
Supported: com.microsoft.wm.srvppair, com.microsoft.wm.sswitch, com.microsoft.wm.predstrm, com.microsoft.wm.fastcache, com.microsoft.wm.startupprofile",


                @"Content-Type: text/plain;charset=UTF-8
User-Agent: NSPlayer
Host: WebServer:8080
Content-Length: 424
Connection: Keep-Alive
Cache-Control: no-cache",


                @"Date: Thu, 16 Oct 2008 07:08:29 GMT
Server: Server
Warning: 110 Response is stale,112 Disconnected operation,113 Heuristic expiration
Age: 1620092",


                @"Proxy-Connection: Keep-Alive
Accept-Ranges: bytes
Content-Length: 126444
Cache-Control: max-age=21600
Content-Type: text/html; charset=iso-8859-1
Date: Mon, 03 Nov 2008 23:52:05 GMT
Expires: Tue, 04 Nov 2008 05:52:05 GMT
ETag: ""1edec-3e3073913b100""
Last-Modified: Wed, 01 Sep 2004 13:24:52 GMT
P3P: policyref=""http://www.w3.org/2001/05/P3P/p3p.xml""
Server: Apache/2
Via: 1.1 RED-PRXY-23
Age: 4791",


                @"Proxy-Connection: Keep-Alive
Connection: Keep-Alive
Transfer-Encoding: chunked
Vary: Accept-Encoding,User-Agent
nnCoection: close
Content-Type: text/xml;charset=UTF-8
Date: Tue, 04 Nov 2008 01:19:56 GMT
Server: Server
Via: 1.1 RED-PRXY-23",


                @"Server: Microsoft-IIS/6.0
Date: Wed, 27 Jun 2007 02:54:23 GMT
Connection: close",


                @"Server: Rex/9.0.0.2837
Cache-Control: no-cache
Pragma: no-cache
Pragma: client-id=1543854732
Pragma: features=""broadcast,playlist""
Content-Type: application/vnd.ms.wms-hdr.asfv1
Content-Length: 2680
Connection: Keep-Alive",


                @"Upgrade: HTTP/2.0, SHTTP/1.3, IRC/6.9, RTA/x11
Transfer-Encoding: chunked
User-Agent: CERN-LineMode/2.15 libwww/2.17b3",


                @"User-Agent: NSPlayer
Host: WebServer:8080
Connection: Keep-Alive
Cache-Control: no-cache",


                @"User-Agent: WMCacheProxy/9.0.0.3177
Via: HTTP/1.1 WMCacheProxy (WMCacheProxy/9.0.0.3177)
Max-Forwards: 9
Accept-Charset: UTF-8, *;q=0.1
Pragma: xClientGUID={00000000-0000-0000-0000-000000000000}
X-Accept-Authentication: Negotiate, MS-NLMP, Digest
Content-Type: application/x-wms-getcontentinfo
Host: myhost:87
Content-Length: 1
Connection: Keep-Alive",

                @"Date:  Thu, 13 May 2004 10:17:12 GMT
Server:  Apache
Last-Modified:  Tue, 20 Apr 2004 13:17:00 GMT
ETag:  ""9a01a-4696-7e354b00""
Accept-Ranges:  bytes
Content-Length:  18070
Keep-Alive:  timeout=15, max=100
Connection:  Keep-Alive
Content-Type:  text/html; charset=ISO-8859-1
",
                @"
Host:  cerberus
User-Agent:  Mozilla/5.0 (X11; U; Linux ppc; rv:1.7.3) Gecko/20041004 Firefox/0.10.1
Accept:  text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5
Accept-Language:  en-us,en;q=0.5
Accept-Encoding:  gzip,deflate
Accept-Charset:  ISO-8859-1,utf-8;q=0.7,*;q=0.7
Keep-Alive:  300
Connection:  keep-alive
Cookie:  FGNCLIID=05c04axp1yaqynldtcdiwis0ag1
"
            }.Select((s) => s.Trim()).Distinct().OrderBy((s) => s).ToList().AsReadOnly();
        public static string Headers = @"
Accept-Encoding: gzip, deflate
Accept-Language: en-us
Accept-Ranges: bytes
Accept: */*
Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-ms-application, application/vnd.ms-xpsdocument, application/xaml+xml, application/x-ms-xbap, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, application/x-shockwave-flash, application/x-silverlight-2-b2, application/x-silverlight, */*
Cache-Control: max-age=0
Cache-Control: max-age=900
Cache-Control: no-cache
Connection: keep-alive
Connection: Keep-Alive
Connection: keep-alive
Connection: Keep-Alive
Connection: keep-alive
Connection: Keep-Alive
Connection: keep-alive
Connection: Keep-Alive
Connection: keep-alive
Connection: Keep-Alive
Connection: keep-alive
Connection: Keep-Alive
Connection: keep-alive
Connection: Keep-Alive
Content-Language: en
Content-Length: 180
Content-Length: 489
Content-Length: 740
Content-Md5: 0TMnkhCZtrIjdTtJk6x3+Q==
Content-Type: application/pkix-crl
Content-Type: text/html
Content-Type: text/html; charset=ISO-8859-1
Content-Type: text/plain
Date: Thu, 18 Dec 2008 08:04:35 GMT
Date: Thu, 18 Dec 2008 08:04:52 GMT
Date: Thu, 18 Dec 2008 08:04:53 GMT
Date: Thu, 18 Dec 2008 08:04:56 GMT
Date: Thu, 18 Dec 2008 08:05:00 GMT
Date: Thu, 18 Dec 2008 08:05:03 GMT
Date: Thu, 18 Dec 2008 08:05:11 GMT
ETag: ""0b586d73618c91:0""
Etag: ""1j3k6u8:tikt981g""
Etag: ""1jca8jc:q61in3to""
ETag: ""ea8009-bc-433e3024c7300""
ETag: ""ea8039-18b3-3f05894d669c0""
ETag: ""eac006-2f3-3ffb6bbcc6f80""
ETag: ""eac00b-316-3d76e22e5ec80""
ETag: ""fecdb0-1b3e-44b72e7505880""
Expires: Thu, 18 Dec 2008 08:05:02 GMT
Host: crl.microsoft.com
Host: jigsaw.w3.org
Host: tools.ietf.org
If-Modified-Since: Fri, 18 Feb 2005 00:56:15 GMT
If-Modified-Since: Thu, 01 Sep 2005 14:33:50 GMT
If-Modified-Since: Tue, 06 Apr 2004 23:09:22 GMT
If-Modified-Since: Tue, 22 Apr 2008 09:33:06 GMT
If-Modified-Since: Wed, 27 Jun 2007 13:13:16 GMT
If-None-Match: ""ea8009-bc-433e3024c7300""
If-None-Match: ""ea8039-18b3-3f05894d669c0""
If-None-Match: ""eac006-2f3-3ffb6bbcc6f80""
If-None-Match: ""eac00b-316-3d76e22e5ec80""
If-None-Match: ""fecdb0-1b3e-44b72e7505880""
Keep-Alive: timeout=15, max=100
Keep-Alive: timeout=15, max=97
Keep-Alive: timeout=15, max=98
Keep-Alive: timeout=15, max=99
Last-Modified: Mon, 18 Mar 2002 14:28:02 GMT
Last-Modified: Tue, 16 Sep 2008 20:00:18 GMT
Last-Modified: Tue, 20 Jun 2000 22:48:51 GMT
Location: http://jigsaw.w3.org/HTTP/
P3P: CP=""ALL IND DSP COR ADM CONo CUR CUSo IVAo IVDo PSA PSD TAI TELo OUR SAMo CNT COM INT NAV ONL PHY PRE PUR UNI""
Pragma: no-cache
Referer: http://jigsaw.w3.org/HTTP/
Referer: http://tools.ietf.org/wg/httpbis/
Referer: http://tools.ietf.org/wg/httpbis/draft-ietf-httpbis-p2-semantics/
Server: Apache/2.2.9 (Debian) DAV/2 SVN/1.5.1 mod_python/3.3.1 Python/2.5.2 mod_ssl/2.2.9 OpenSSL/0.9.8g mod_perl/2.0.4 Perl/v5.10.0
Server: Jigsaw/2.3.0-beta1
Server: Microsoft-IIS/7.0
Transfer-Encoding: chunked
UA-CPU: x86
User-Agent: Microsoft-CryptoAPI/6.0
User-Agent: Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; Tablet PC 2.0; .NET CLR 1.1.4322; InfoPath.2; MS-RTC LM 8; .NET CLR 4.0.11014; .NET CLR 3.5.30729)
X-Powered-By: ASP.NET

Via: HTTP/1.1 WMCacheProxy (WMCacheProxy/9.0.0.3177)
Via: 1.0 fred, 1.1 nowhere.com (Apache/1.1)
Via: 1.0 ricky, 1.1 ethel, 1.1 fred, 1.0 lucy
Via: 1.0 ricky, 1.1 mertz, 1.0 lucy
Accept: text/*;q=0.3, text/html;q=0.7, text/html;level=1,text/html;level=2;q=0.4, */*;q=0.5
Accept: text/*, text/html, text/html;level=1, */*
Accept: audio/*; q=0.2, audio/basic
Accept: text/plain; q=0.5, text/html, text/x-dvi; q=0.8, text/x-c
Accept-Charset: iso-8859-5, unicode-1-1;q=0.8
Accept-Encoding: compress, gzip
Accept-Encoding:
Accept-Encoding: *
Accept-Encoding: compress;q=0.5, gzip;q=1.0
Accept-Encoding: gzip;q=1.0, identity; q=0.5, *;q=0
Accept-Language: da, en-gb;q=0.8, en;q=0.7
Accept-Ranges: bytes
Accept-Ranges: none
Connection: close
Content-Encoding: gzip
Cache-Control: private, community=""UCI""
Content-Language: da
Content-Language: mi, en
Content-Length: 3495
Date: Wed, 15 Nov 1995 06:25:24 GMT
Last-Modified: Wed, 15 Nov 1995 04:58:08 GMT
Content-Range: bytes 21010-47021/47022
Content-Length: 26012
Content-Type: image/gif
Content-Type: text/html; charset=ISO-8859-4
ETag: ""xyzzy""
ETag: W/""xyzzy""
ETag: """"
Expires: Thu, 01 Dec 1994 16:00:00 GMT
From: webmaster@w3.org
If-Match: ""xyzzy""
If-Match: ""xyzzy"", ""r2d2xxxx"", ""c3piozzzz""
If-Match: *
If-Modified-Since: Sat, 29 Oct 1994 19:43:31 GMT
If-None-Match: ""xyzzy""
If-None-Match: W/""xyzzy""
If-None-Match: ""xyzzy"", ""r2d2xxxx"", ""c3piozzzz""
If-None-Match: W/""xyzzy"", W/""r2d2xxxx"", W/""c3piozzzz""
If-None-Match: *
If-Unmodified-Since: Sat, 29 Oct 1994 19:43:31 GMT
Last-Modified: Tue, 15 Nov 1994 12:45:26 GMT
Location: http://www.w3.org/pub/WWW/People.html

- The first 500 bytes (byte offsets 0-499, inclusive):  
Range: bytes=0-499
- The second 500 bytes (byte offsets 500-999, inclusive):
Range: bytes=500-999
- The final 500 bytes (byte offsets 9500-9999, inclusive):
Range: bytes=-500
- Or 
Range: bytes=9500-
- The first and last bytes only (bytes 0 and 9999):  
Range: bytes=0-0,-1
- Several legal but not canonical specifications of the second 500 bytes (byte offsets 500-999, inclusive):
Range: bytes=500-600,601-999
Range: bytes=500-700,601-999

Referer: http://www.w3.org/hypertext/DataSources/Overview.html
Retry-After: Fri, 31 Dec 1999 23:59:59 GMT
Retry-After: 120
Server: CERN/3.0 libwww/2.17

TE: deflate
TE:
TE: trailers, deflate;q=0.5

";
    }

    [TestClass]
    public class ExampleHeaders
    {

        [TestMethod]
        public void TestCacheControl()
        {
            var whc = new WebHeaderCollection();
            whc["Cache-Control"] = "max-age=600";
            whc["Age"] = "330";
            var h = new ResponseHeaders();
            HttpWebRequestTransportStage.CopyHeadersFromHttpWebResponse(whc, h);

            Assert.AreEqual(600, h.CacheControl.MaxAge.Value.TotalSeconds);

            var v = h.CacheControl;

            var xe = GetDataContractXElement(v);
            Console.WriteLine(xe);
            var rt = ReadDataContract(xe, v);

            Assert.AreEqual(v.MaxAge, rt.MaxAge);
            Assert.AreEqual(v.ToString(), rt.ToString());

            whc.Clear();
            whc.Add("Cache-Control: private, max-age=3600, must-revalidate");

            h = new ResponseHeaders();
            HttpWebRequestTransportStage.CopyHeadersFromHttpWebResponse(whc, h);

            Console.WriteLine(h.CacheControl.ToString());

        }

        [TestMethod]
        public void TestExpires()
        {
            var h = ResponseHeaders.Parse(@"Date: Thu, 05 Feb 2009 07:14:13 GMT
Expires: -1");

            Console.WriteLine(h.Expires);
            Console.WriteLine(h.Date);
            Assert.AreEqual("-1", h["Expires"]);

            h["Expires"] = h["Date"];
            Console.WriteLine(h.Expires);
            h.Expires = h.Expires;
            Console.WriteLine(h.Expires);
            Console.WriteLine(h["Expires"]);
            Assert.AreEqual(h["Date"], h["Expires"]);

            h = new ResponseHeaders();
            var ts = "{ts '1985-01-00 12:00:00'}";
            h["Expires"] = ts;
            Console.WriteLine(h.Expires.Value);
            Assert.IsTrue(h.Expires.Value < DateTime.UtcNow);
            Assert.AreEqual(ts, h["Expires"]);
        }
        [TestMethod]
        public void TestServer()
        {
            var s = "Apache/1.3.27 (Unix) mru_xml/0.471 gorgona/2.1 mod_jk/1.2.4 mod_ruby/1.0.7 Ruby/1.6.8 mod_mrim/0.17";
            var h = new ResponseHeaders();
            h["Server"] = s;

            Console.WriteLine(h.Server);
            Assert.AreEqual(s, h.Server.ToString());
            Assert.AreEqual(8, h.Server.Count);

            h = new ResponseHeaders();
            h.Add("Server", s);

            Console.WriteLine(h.Server);
            Assert.AreEqual(s, h.Server.ToString());
            Assert.AreEqual(8, h.Server.Count);
        }

        [TestMethod]
        public void TestSetCookie()
        {
            var lines = new string[] { "Server: Apache-Coyote/1.1",
                    "Set-Cookie: hostid=152350996; Expires=Mon, 04-Feb-2019 11:13:07 GMT; Path=/",
                    "Set-Cookie: JSESSIONID=8FA273DB5E13677B3604D443AAE93F83.dc90; Path=/",
                    "Content-Type: text/html;charset=UTF-8",
                    "Date: Fri, 06 Feb 2009 11:13:06 GMT",
                    "Connection: close"};
            var orig = string.Join(Environment.NewLine, lines);
            var h = ResponseHeaders.Parse(orig);
            for (int i = 0; i < h.SetCookie.Count; ++i)
            {
                var c = h.SetCookie[i];
                h.SetCookie[i] = c;
                Console.WriteLine(GetDataContractXElement(c));
            }

            Console.WriteLine(h);
            var s = h.ToString();
            Assert.AreEqual(orig.ToCharArray().Count((x) => x == ':'), s.ToCharArray().Count((x) => x == ':'));

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(orig);
            Console.WriteLine();
            Console.WriteLine(h.ToString());
            Console.WriteLine();
            Assert.AreEqual(orig, h.ToString());
        }

        [TestMethod]
        public void TestSetCookie2()
        {
            var h = ResponseHeaders.Parse(@"Proxy-Connection: Keep-Alive
Connection: Keep-Alive
Content-Length: 24887
Via: 1.1 RED-PRXY-29
Date: Sat, 07 Feb 2009 01:52:32 GMT
Content-Type: text/html; charset=utf-8
X-Powered-By: ASP.NET
P3P: CP=""NON UNI COM NAV STA LOC CURa DEVa PSAa PSDa OUR IND"", policyref=""http://privacy.msn.com/w3c/p3p.xml""
Cache-Control: private, max-age=0
Set-Cookie: mkt1=norm=US; domain=.live.com; path=/
Set-Cookie: mkt2=ui=en-US; domain=www.live.com; path=/
Set-Cookie: AFORM=NOFORM; expires=Mon, 20-Jul-2015 23:59:59 GMT; path=/
Set-Cookie: MUID=03E99531594F480086D6187456832359; expires=Mon, 20-Jul-2015 23:59:59 GMT; domain=.live.com; path=/
Set-Cookie: OrigMUID=03E99531594F480086D6187456832359; expires=Mon, 20-Jul-2015 23:59:59 GMT; domain=.live.com; path=/
Set-Cookie: OVR=flt=0&PerfTracking=0&DomainVertical=0; domain=.live.com; path=/
Set-Cookie: RMS=T=8; path=/
Set-Cookie: SRCHD=D=580432&AF=NOFORM; expires=Mon, 20-Jul-2015 23:59:59 GMT; domain=.live.com; path=/
Set-Cookie: SRCHSESS=GUID=3804564013AF49C09EFEC34835E09904&TS=1233971552; expires=Sat, 07-Feb-2009 02:12:32 GMT; path=/
Set-Cookie: SRCHUID=V=2&GUID=877DF232579843E7B89787D411B6F6CF; expires=Mon, 20-Jul-2015 23:59:59 GMT; path=/
Set-Cookie: SRCHUSR=AUTOREDIR=0&GEOVAR=&DOB=20090207; expires=Mon, 07-Feb-2011 01:52:32 GMT; path=/
            ".Trim());

            Assert.AreEqual(11, h.GetValues("Set-Cookie").Count());
            Assert.AreEqual(11, h.SetCookie.ToArray().Length);
        }

        static XElement GetDataContractXElement<T>(T v)
        {
            var ser = Serializer<T>.Instance;
            var output = new StringBuilder();
            using (var w = XmlWriter.Create(output, new XmlWriterSettings()
                {
                    Indent = true,
                    OmitXmlDeclaration = true
                }))
            {
                ser.WriteObject(w, v);
                w.Flush();
            }
            var xe = XElement.Parse(output.ToString());
            return xe;
        }

        static T ReadDataContract<T>(XElement element, T original)
        {
            var ser = Serializer<T>.Instance;
            var loaded = (T) ser.ReadObject(element.CreateReader());
            return loaded;
        }

        static class Serializer<T>
        {
            public static readonly DataContractSerializer Instance = new DataContractSerializer(typeof(T));
        }
    }
}
