//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Http;
    using System.Threading;

    public class ThrowOnRequestStage : HttpProcessingStage
    {
        public override void ProcessRequest(HttpRequestMessage request)
        {
            throw new ApplicationException(this.ToString());
        }
        public override void ProcessResponse(HttpResponseMessage response)
        {
        }
    }
}
