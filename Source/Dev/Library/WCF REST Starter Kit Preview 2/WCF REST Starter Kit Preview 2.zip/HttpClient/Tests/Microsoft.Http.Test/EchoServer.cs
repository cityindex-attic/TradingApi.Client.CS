//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.Server
{
    using System;
    using System.Net;
    using Microsoft.Http;

    public class EchoServer : HttpServerBase
    {
        public EchoServer(string address)
            : base(address)
        {
        }
        public override HttpResponseMessage Process(HttpRequestMessage request)
        {
            var u = request.Uri.ToString();
            if (u.Contains("/404/"))
            {
                return request.CreateResponse(HttpStatusCode.NotFound);
            }

            foreach (HttpStatusCode x in Enum.GetValues(typeof(HttpStatusCode)))
            {
                if (u.Contains("/" + ((int) x).ToString() + "/"))
                {
                    return request.CreateResponse(x);
                }

                if (u.IndexOf("/" + x.ToString() + "/", StringComparison.OrdinalIgnoreCase) != -1)
                {
                    return request.CreateResponse(x);
                }
            }

            var response = request.CreateResponse(HttpStatusCode.OK);
            bool isDrain = request.Uri.ToString().Contains("/drain/");
            bool isHtml = request.Uri.ToString().Contains("/html/");
            if (isDrain || isHtml)
            {
                string s, c;
                try
                {
                    if (isDrain)
                    {
                        var drained = request.Content.ReadAsByteArray();
                        s = "drained " + drained.Length;
                        c = "text/plain";
                    }
                    else
                    {
                        s = "echo: " + request.Content.ReadAsString() + "<hr><pre>" + request.Headers.ToString() + "</pre><hr>" + request.ToString();
                        c = "text/html";
                    }
                }
                catch (Exception e)
                {
                    s = e.ToString();
                    c = "text/exception";
                    System.Diagnostics.Trace.WriteLine(e);
                }
                response.Content = HttpContent.Create(s, c);
            }
            else
            {
                response.Content = request.Content;
            }

            return response;
        }
    }
}
