//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using Microsoft.Http.Test.Server;

    partial class ServerHelper
    {
        static readonly Uri charGenAddress = new Uri(ServerHelper.ServerBaseAddress, "CharGen/");
        static CharGenServer charGenServer;

        public static Uri CharGenAddress
        {
            get
            {
                if (charGenServer == null)
                {
                    charGenServer = new CharGenServer(charGenAddress.ToString());
                    charGenServer.Start();

                    Register(charGenServer);
                }
                return charGenAddress;
            }
        }
    }

}
