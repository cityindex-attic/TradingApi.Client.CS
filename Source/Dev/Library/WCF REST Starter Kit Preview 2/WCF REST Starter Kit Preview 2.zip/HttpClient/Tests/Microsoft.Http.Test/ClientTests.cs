//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Threading;
    using System.Xml.Linq;
    using Microsoft.Http;
    using Microsoft.Http.Headers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ClientTests
    {

        [TestMethod]
        public void Test404()
        {
            var client = new HttpClient();
            using (var response = client.Get("http://localhost/" + Guid.NewGuid() + ".txt"))
            {
                response.EnsureStatusIs(HttpStatusCode.NotFound);
                response.EnsureStatusIs(404);
                Assert.AreEqual(response.StatusCode, HttpStatusCode.NotFound);
                Assert.AreEqual((int)response.StatusCode, 404);
            }
        }
        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void Test404ExceptionWithThrowIfStatusIsNot2xxSetFails()
        {
            var client = new HttpClient();
            using (var response = client.Get(new Uri(ServerHelper.EchoAddress, "404/" + Guid.NewGuid() + ".txt")))
            {
                response.EnsureStatusIs(200);
                Console.WriteLine(response.ToHttpResponseString());
            }
        }

        [TestMethod]
        public void TestCharGen()
        {
            var client = new HttpClient(ServerHelper.CharGenAddress);
            var head = client.Head("lines/10");

            List<HttpResponseMessage> responses = new List<HttpResponseMessage>();
            Func<HttpResponseMessage, HttpResponseMessage> add = (r) =>
            {
                Console.WriteLine(r.Request + " " + r);
                Console.WriteLine(r.Headers);
                Console.WriteLine();
                responses.Add(r);
                r.EnsureStatusIs(HttpStatusCode.OK);
                return r;
            };
            try
            {
                var ss = add(client.Get("lines/10")).Content.ReadAsString();
                Console.WriteLine("*" + ss + "*");
                Assert.AreEqual(10, ss.ToCharArray().Count((c) => c == '\n'), ss);


                add(head);
                Console.WriteLine(head.ToHttpResponseString());
                Assert.AreEqual("730", head.Headers["Content-Length"]);

                Assert.AreEqual(10, add(client.Get("chars/10")).Content.ReadAsString().Length);
                Assert.AreEqual(10, add(client.Get("10")).Content.ReadAsString().Length);
                add(client.EndSend(client.BeginSend(new HttpRequestMessage("GET", "lines/10"), null, null)));
            }
            finally
            {
                foreach (var response in responses)
                {
                    response.Dispose();
                }
            }
        }
        [TestCleanup]
        public void TestCleanup()
        {
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        [TestMethod]
        public void TestCookies()
        {
            var u = "http://www.live.com";
            HttpClient client = new HttpClient();
            client.TransportSettings.Cookies = new CookieContainer();
            int before = client.TransportSettings.Cookies.Count;
            Console.WriteLine("container " + before);
            var response = client.Get(u);
            Console.WriteLine(response.StatusCode + " " + response.Uri + " " + response.Headers.ToString());

            int after = client.TransportSettings.Cookies.Count;
            Console.WriteLine("container " + after);
            Console.WriteLine(response.Headers.SetCookie.Count);
            Assert.IsTrue(after > before);
            Console.WriteLine();

            var net = client.TransportSettings.Cookies.GetCookies(response.Uri).Cast<System.Net.Cookie>().Select((x) => x.ToString()).ToList();
            var http = response.Headers.SetCookie.Select((c) => c.ToString()).ToList();
            http.Sort();
            net.Sort();
            foreach (var c in net)
            {
                Console.WriteLine(c);
            }

            Console.WriteLine();
            foreach (var h in http)
            {
                Console.WriteLine(h);
            }

            Console.WriteLine();
            Assert.AreEqual(net.Count, http.Count);
            response.Dispose();
        }
        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestCustomClientWithoutTransportFails()
        {
            using (var c = new CustomClient())
            {
                c.Stages.Add(null);
                c.Send(new HttpRequestMessage("GET", "http://localhost"));
            }
        }

        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestDisposeSendFails()
        {
            var client = new HttpClient();
            client.Dispose();
            client.Get("http://localhost");
        }

        [TestMethod]
        public void TestDisposeStage()
        {
            var client = new HttpClient();
            var stage = new DisposeStage();
            client.Stages.Add(stage);
            client.Dispose();
            Assert.IsFalse(stage.WasDisposed);
        }

        [TestMethod]
        public void TestEnsure()
        {
            using (var response = new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK
                }.EnsureStatusIs(HttpStatusCode.OK))
            {
            }
        }
        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestEnsureFails()
        {
            new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.Unauthorized
                }.EnsureStatusIs(HttpStatusCode.OK);
        }
        [TestMethod]
        public void TestEnsureMessage()
        {
            bool ok = true;
            var response = new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.Unauthorized
                };
            using (response)
            {
                try
                {
                    response.EnsureStatusIs(HttpStatusCode.OK);
                    ok = false;
                }
                catch (ArgumentOutOfRangeException e)
                {
                    ok = e.Message.Contains("Unauthorized");
                    Console.WriteLine(e.Message);
                }

                Assert.IsTrue(ok);
            }
        }

        [TestMethod]
        public void TestHeaders()
        {
            var h = new RequestHeaders();
            h.Add("x", "y");
            h.Add("x", "z");
            h.Add("a", "z");

            foreach (var pair in h)
            {
                Console.WriteLine(pair.Key + " " + pair.Value.Length);
            }

            var e = h as System.Collections.IEnumerable;

            foreach (var pair in e)
            {
                Console.WriteLine(pair);
            }
        }

        [TestMethod]
        public void TestLargeDownload()
        {
            var started = DateTime.UtcNow;
            Func<int, Uri> source = (x) => new Uri(ServerHelper.CharGenAddress, (x * 1024).ToString());
            AutoResetEvent updated = new AutoResetEvent(false);
            var client = new HttpClient();
            client.TransportSettings.ReadWriteTimeout = TimeSpan.FromSeconds(0.2);
            int count = 0;
            int echo = 0;
            client.SendCompleted += (x, y) =>
            {
                Console.WriteLine(y);
                if (y.Error != null)
                {
                    Console.WriteLine(y.Error);
                    count = echo = int.MaxValue;
                    updated.Set();
                    return;
                }

                if (y.Request.ToString().IndexOf("Echo", StringComparison.OrdinalIgnoreCase) == -1)
                {
                    ++count;
                    var content = y.Response.Content;
                    content.LoadIntoBuffer();
                    y.Response.Content = null;
                    var echoRequest = new HttpRequestMessage("ECHO",
                        ServerHelper.EchoAddress,
                        content);
                    // for debugging purposes, not needed
                    if (echoRequest.Content.HasLength())
                    {
                        echoRequest.Headers.ContentLength = echoRequest.Content.GetLength();
                    }
                    if (!string.IsNullOrEmpty(echoRequest.Content.ContentType))
                    {
                        echoRequest.Headers.ContentType = echoRequest.Content.ContentType;
                    }
                    // content.LoadIntoBuffer();
                    try
                    {
                        var resp = client.Send(echoRequest);
                        var echoed = resp.Content.ReadAsByteArray();
                        Console.WriteLine(echoed.Length);
                        ++echo;
                        resp.Dispose();
                        updated.Set();

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
            };

            client.Stages.Add(new HeaderTraceStage());

            int total = 1;
            foreach (int x in Enumerable.Range(0, total))
            {
                client.SendAsync(new HttpRequestMessage("GET", source(x)));
            }
            bool gotIt = true;
            do
            {
                gotIt = gotIt && updated.WaitOne(TimeSpan.FromMilliseconds(600));
                Console.WriteLine("count: " + count + ", echo = " + echo);
            }
            while (count < total || echo < total);

            var elapsed = DateTime.UtcNow - started;
            Console.WriteLine(elapsed.ToString());
            Assert.IsTrue(gotIt);
        }

        [TestMethod]
        public void TestLargeEcho()
        {
            var rand = new Random();
            var bytes = new byte[6543210];
            for (int x = 0; x < bytes.Length; ++x)
            {
                bytes[x] = (byte)x;
            }

            var client = new HttpClient();
            client.Stages.Add(new HeaderTraceStage());
            Console.WriteLine(bytes.Length);
            var response = client.Put(ServerHelper.EchoAddress, HttpContent.Create(bytes));
            Console.WriteLine(response.Headers);
            var echoed = response.Content.ReadAsByteArray();
            Console.WriteLine(echoed.Length + " " + bytes.Length);
            response.Dispose();
        }

        [TestMethod]
        public void TestRedirects()
        {
            var client = new HttpClient("http://www.microsoft.com");
            var response = client.Get("");
            Console.WriteLine(response.Request.Uri);
            Console.WriteLine(response.Uri);
            Assert.AreEqual("http://www.microsoft.com/en/us/default.aspx", response.Uri.ToString());
            response.EnsureStatusIs(200);
            response.Dispose();

            client.TransportSettings.MaximumAutomaticRedirections = 0;
            response = client.Get("");
            response.EnsureStatusIs(302);
            Console.WriteLine(response);
            response.Dispose();
        }

        [TestMethod]
        public void TestRequestAccessibleFromResponse()
        {
            var client = new HttpClient(ServerHelper.CharGenAddress);
            var request = new HttpRequestMessage("GET", "lines/10");
            request.Headers["xyz"] = "abc";
            var response = client.Send(request);
            Assert.AreEqual("abc", response.Request.Headers["xyz"]);
            response.Dispose();
        }

        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestSendingTwiceFails()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage("GET", ServerHelper.EchoAddress);
            client.Send(request).Dispose();
            client.Send(request).Dispose();
        }

        static void Close(HttpResponseMessage response)
        {
            response.Content.ReadAsByteArray();
            response.Dispose();
        }

        class CustomClient : HttpClient
        {
            protected override HttpStage CreateTransportStage()
            {
                return null;
            }
        }

        class DisposeStage : HttpProcessingStage, IDisposable
        {
            public bool WasDisposed
            {
                get;
                private set;
            }

            public void Dispose()
            {
                this.WasDisposed = true;
            }
            public override void ProcessRequest(HttpRequestMessage request)
            {
            }

            public override void ProcessResponse(HttpResponseMessage response)
            {
            }
        }

        class HeaderTraceStage : HttpProcessingStage
        {
            public override void ProcessRequest(HttpRequestMessage request)
            {
                Console.WriteLine(new XElement("PreSendHeaders", new XAttribute("Uri", request.Uri.ToString()),
                    new XElement("Request", new XCData(Environment.NewLine + request.Headers.ToString() + Environment.NewLine))));
            }

            public override void ProcessResponse(HttpResponseMessage response)
            {
                var req = response.Request;
                Console.WriteLine(new XElement("Headers", new XAttribute("Uri", response.Uri.ToString()),
                    new XElement("Request", new XCData(Environment.NewLine + req.Headers.ToString() + Environment.NewLine)),
                    new XElement("Response", new XCData(Environment.NewLine + response.Headers.ToString() + Environment.NewLine))));
            }
        }
    }

}
