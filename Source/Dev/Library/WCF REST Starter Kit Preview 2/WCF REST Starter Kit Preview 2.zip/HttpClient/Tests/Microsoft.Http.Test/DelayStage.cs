//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Http;
    using System.Threading;
    using System.Diagnostics;


    public class DelayStage : HttpProcessingStage
    {
        readonly string name;
        readonly TimeSpan req;
        readonly TimeSpan resp;
        public DelayStage(string name, int milliseconds)
            : this(name, TimeSpan.FromMilliseconds(milliseconds))
        {
        }
        public DelayStage(string name, TimeSpan delay)
            : this(name, delay, delay)
        {
        }
        public DelayStage(string name, TimeSpan request, TimeSpan response)
        {
            this.name = name;
            this.req = request;
            this.resp = response;
        }

        public override void ProcessRequest(HttpRequestMessage request)
        {
            Trace.WriteLine("\t\trequest delay:  " + name + " " + req);
            Thread.Sleep(req);
        }

        public override void ProcessResponse(HttpResponseMessage response)
        {
            Trace.WriteLine("\t\tresponse delay: " + name + " " + resp);
            Thread.Sleep(resp);
        }
        public override string ToString()
        {
            return this.GetType().Name + "(\"" + name + "\", " + this.req + ", " + this.resp + ")";
        }
    }
}
