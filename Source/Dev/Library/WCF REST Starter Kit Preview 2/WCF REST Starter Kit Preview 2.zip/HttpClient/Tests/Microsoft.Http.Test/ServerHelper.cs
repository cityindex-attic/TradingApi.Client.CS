//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Http.Test.Server;
    [TestClass]
    partial class ServerHelper
    {
        public static Uri ServerBaseAddress
        {
            get
            {
                return new Uri("http://localhost:8731/Design_Time_Addresses/");
            }
        }

        static readonly List<HttpServerBase> servers = new List<HttpServerBase>();

        [AssemblyCleanup]
        public static void StopServers()
        {
            foreach (var server in servers)
            {
                System.Diagnostics.Trace.WriteLine(server.Address + " handled " + server.RequestsProcessed + " requests");
                server.Stop();
            }
            System.GC.WaitForPendingFinalizers();
        }

        static void Register(HttpServerBase server)
        {
            servers.Add(server);
        }
    }
}
