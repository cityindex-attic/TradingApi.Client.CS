//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Http;

    public class FixedTransport : HttpGetUrlCacheStage
    {
        readonly Func<Uri, HttpResponseMessage> responseFunction;
        public FixedTransport()
        {
            this.responseFunction = (u) => new HttpResponseMessage()
            {
                Method = "GET",
                Uri = u,
                StatusCode = System.Net.HttpStatusCode.OK
            };
        }
        public FixedTransport(Func<Uri, HttpResponseMessage> response)
        {
            responseFunction = response;
        }
        public override void RememberResponse(Uri key, HttpResponseMessage response)
        {
        }
        public override bool TryGetResponse(Uri key, out HttpResponseMessage response)
        {
            response = this.responseFunction(key);
            return true;
        }
    }

}
