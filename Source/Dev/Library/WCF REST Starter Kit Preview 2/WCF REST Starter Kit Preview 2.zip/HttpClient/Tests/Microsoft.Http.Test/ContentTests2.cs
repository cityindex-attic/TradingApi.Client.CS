//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using Microsoft.Http;
    using Microsoft.VisualStudio.TestTools.UnitTesting;


    class NoSeekStream : DelegatingStream
    {
        public NoSeekStream(byte[] buffer)
            : base(new MemoryStream(buffer))
        {
        }

        public override bool CanSeek
        {
            get
            {
                return false;
            }
        }
    }

    // http://tools.ietf.org/html/rfc2388
    // http://tools.ietf.org/html/rfc2387

    [TestClass]
    public class ContentTests2
    {
        [TestMethod]
        public void TestBytes()
        {
            var buffer = new byte[256];
            new Random().NextBytes(buffer);
            var a = HttpContent.Create(buffer, "text/plain");
            Assert.AreEqual("text/plain", a.ContentType);
            Assert.AreEqual(buffer.Length, a.GetLength());
            a.LoadIntoBuffer();
            Assert.AreEqual(buffer.Length, a.GetLength());
        }
        [TestMethod]
        public void TestNoSeek()
        {
            var buffer = new byte[256];
            new Random().NextBytes(buffer);
            var a = HttpContent.Create(new NoSeekStream(buffer));
            Assert.IsNull(a.ContentType);
            Assert.IsFalse(a.HasLength());
            Console.WriteLine(a);
            a.LoadIntoBuffer();
            Assert.IsTrue(a.HasLength());
            Assert.AreEqual(buffer.Length, a.GetLength());
            Console.WriteLine(a);
        }
        [TestMethod]
        public void TestNoSeekFunc()
        {
            var buffer = new byte[256];
            new Random().NextBytes(buffer);
            var a = HttpContent.Create(() => new NoSeekStream(buffer));
            Assert.IsNull(a.ContentType);
            Assert.IsFalse(a.HasLength());
            Console.WriteLine(a);
            a.LoadIntoBuffer();
            Assert.IsTrue(a.HasLength());
            Assert.AreEqual(buffer.Length, a.GetLength());
            Console.WriteLine(a);
        }

        [TestMethod]
        public void TestRandomWithWriteTo()
        {
            Random rand = new Random();
            int bufferSize = 256;
            int count = 1024;
            Action<Stream> randomByteWriter = (stream) =>
            {
                var buffer = new byte[bufferSize];
                for (int i = 0; i < count; ++i)
                {
                    rand.NextBytes(buffer);
                    stream.Write(buffer, 0, buffer.Length);
                }
            };

            var c = HttpContent.Create(randomByteWriter);

            var gen = c.ReadAsByteArray();
            Console.WriteLine(c + " " + gen.Length);
            Assert.AreEqual(count * bufferSize, gen.Length);
        }

        [TestMethod]
        public void TestRead()
        {
            var c = HttpContent.Create("this is my test");
            var s = c.ReadAsStream();
            Assert.IsTrue(s.CanSeek);
            Assert.AreEqual(s.Length, c.GetLength());
            c.Dispose();
        }

        [TestMethod]
        public void TestSeekable()
        {
            var buffer = new byte[256];
            new Random().NextBytes(buffer);
            var a = HttpContent.Create(new MemoryStream(buffer));
            Assert.AreEqual(buffer.Length, a.GetLength());
            a.LoadIntoBuffer();
            Assert.AreEqual(buffer.Length, a.GetLength());
        }

        [TestMethod]
        public void TestStringAsBytes()
        {
            var c = HttpContent.Create("test");
            var bytes = c.ReadAsByteArray();
        }

        [TestMethod]
        public void TestStrings()
        {
            var s = "this is a test";
            var contents = new HttpContent[] {
                    HttpContent.Create(s, "text/html; charset=unicode"), // uses unicode
                    HttpContent.Create(s, "text/html"), // default http (or error?)
                    HttpContent.Create(s, Encoding.Unicode), // uses unicode
                    HttpContent.Create(s, Encoding.GetEncoding("GBK"), "text/html"), // weird but okay
                    HttpContent.Create(s, Encoding.GetEncoding("GBK"), "text/html; charset=gbk")}; // weird but okay
            Console.WriteLine(Encoding.GetEncoding("GBK").WebName);
            foreach (var content in contents)
            {
                Console.WriteLine(content);
                Assert.IsNotNull(content.GetLength());
                Console.WriteLine(content.GetLength());
            }

            foreach (var cult in CultureInfo.GetCultures(CultureTypes.AllCultures))
            {
                var enc = Encoding.GetEncoding(cult.TextInfo.ANSICodePage);

                var c = HttpContent.Create(cult.NativeName, enc);
                var sample = cult.NativeName;
                if (sample.Length != c.GetLength())
                {
                    Console.WriteLine("{0,5} {1,5} {2,8} {3} {4} {5}", sample.Length, c.GetLength(), enc.EncodingName, sample, cult.EnglishName, c);
                }
                Assert.IsTrue(c.ToString().Contains(sample), c.ToString() + " didn't contain " + sample);
                var d = HttpContent.Create(sample);
            }
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestStringWithMismatchedCharsetFails()
        {
            var s = "this is a test";
            try
            {
                HttpContent.Create(s, Encoding.GetEncoding("GBK"), "text/html; charset=unicode"); // error
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }

}
