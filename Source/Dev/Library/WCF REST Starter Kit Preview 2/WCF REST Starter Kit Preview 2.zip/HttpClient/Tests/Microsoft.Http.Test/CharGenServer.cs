//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.Server
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using Microsoft.Http;

    public class CharGenServer : HttpServerBase
    {
        public CharGenServer(string address)
            : base(address)
        {
        }
        public override HttpResponseMessage Process(HttpRequestMessage request)
        {
            Trace.WriteLine(request.Uri);
            try
            {
                if (request.Method != "GET" && request.Method != "HEAD")
                {
                    return request.CreateResponse(HttpStatusCode.MethodNotAllowed);
                }

                if (!string.IsNullOrEmpty(request.Uri.Query))
                {
                    throw new NotSupportedException(request.Uri.Query);
                }
                var response = request.CreateResponse(HttpStatusCode.OK);
                var countUri = new Uri(Address.Replace("+", "localhost")).MakeRelativeUri(request.Uri);
                int count;
                bool lines;
                if (countUri.ToString().StartsWith("lines/"))
                {
                    int lineCount = int.Parse(countUri.ToString().Substring(6));
                    count = 72 * lineCount;
                    lines = true;
                    response.Headers["X-CharGen-Units"] = "lines";
                    response.Headers["X-CharGen-Count"] = lineCount + "";
                }
                else
                {
                    var s = countUri.ToString();
                    if (s.StartsWith("chars/"))
                    {
                        s = s.Substring(6);
                    }
                    if (s.EndsWith("/"))
                    {
                        s = s.Substring(0, s.Length - 1);
                    }
                    if (!int.TryParse(s, out count))
                    {
                        count = 65536 * 3 + 29;
                    }
                    lines = false;
                    response.Headers["X-CharGen-Units"] = "chars";
                    response.Headers["X-CharGen-Count"] = count + "";
                }
                long? len = lines ? null : (long?) count;

                HttpContent content = HttpContent.Create(new CharGenContent(count, lines).WriteTo, "text/plain", len);
                // content.LoadIntoBuffer();
                if (request.Method == "HEAD")
                {
                    using (content)
                    {
                        var got = content.ReadAsByteArray().Length;
                        response.Headers.ContentLength = got;
                        response.Content = HttpContent.CreateEmpty();
                    }
                }
                else
                {
                    response.Content = content;
                }

                return response;
            }
            catch (Exception e)
            {
                HttpResponseMessage error = request.CreateResponse(HttpStatusCode.InternalServerError);
                error.Headers["X-CharGen-Uri"] = request.Uri.ToString().Replace(base.Address, "");
                error.Headers["X-CharGen-ExceptionType"] = e.GetType().ToString();
                error.Headers["X-CharGen-ExceptionMessage"] = e.Message;
                System.Diagnostics.Trace.WriteLine(e);
                return error;
            }
        }
        static string GetCharGenString()
        {
            List<char> list = new List<char>();
            for (int i = 0; i < 129; ++i)
            {
                char c = (char) i;
                if (char.IsLetterOrDigit(c) || char.IsPunctuation(c) || char.IsSymbol(c))
                {
                    list.Add(c);
                }
            }
            list.Sort();
            list.Add(' ');
            return new String(list.ToArray());
        }

        class CharGenContent
        {

            public const int LineLength = 72;
            static readonly string s = GetCharGenString() + GetCharGenString();
            readonly int count;
            readonly bool lines;
            public CharGenContent(int c, bool lines)
            {
                this.count = c;
                this.lines = lines;
            }
            public void WriteTo(Stream stream)
            {
                var buffered = new BufferedStream(stream, 1024);
                int line = 0;
                int slen = (s.Length / 2);
                for (int x = 0; x < this.count; ++x)
                {
                    char c = s[(x % LineLength) + (line % slen)];
                    buffered.WriteByte((byte) c);
                    if (lines && ((x + 1) % LineLength == 0))
                    {
                        buffered.WriteByte((byte) '\n');
                        ++line;
                    }
                }
                buffered.Flush();
                stream.Flush();
                stream.Close();
            }
        }
    }
}
