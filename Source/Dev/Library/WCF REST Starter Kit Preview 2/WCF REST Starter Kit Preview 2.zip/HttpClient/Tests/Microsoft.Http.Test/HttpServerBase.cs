//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.Server
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.Linq.Expressions;
    using System.Net;
    using System.Threading;

    public abstract class HttpServerBase : IDisposable
    {
        static readonly AsyncCallback OnContextAvailableCallback = OnContextAvailable;
        readonly string address;
        readonly HttpListener http = new HttpListener();

        HttpClient pipe;
        int requestsProcessed;

        Collection<HttpStage> stages;
        public HttpServerBase(string address)
        {
            var prefix = address.Replace(new Uri(address).Host, "+");
            http.Prefixes.Add(prefix);
            this.address = address;
            Trace.WriteLine(address + " " + prefix);
        }
        public string Address
        {
            get
            {
                return this.address;
            }
        }
        public int RequestsProcessed
        {
            get
            {
                return this.requestsProcessed;
            }
        }
        public Collection<HttpStage> Stages
        {
            get
            {
                if (this.stages == null)
                {
                    this.stages = new Collection<HttpStage>();
                }
                return this.stages;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value");
                }
                this.stages = value;
            }
        }

        public bool TraceRequests
        {
            get;
            set;
        }

        public static void TraceRequest(string name, HttpListenerRequest request)
        {
            TraceRequest(name, request, (r) => r.AcceptTypes);
            TraceRequest(name, request, (r) => r.ContentEncoding);
            TraceRequest(name, request, (r) => r.ContentLength64);
            TraceRequest(name, request, (r) => r.ContentType);
            TraceRequest(name, request, (r) => r.Cookies);
            TraceRequest(name, request, (r) => r.GetClientCertificate());
            TraceRequest(name, request, (r) => r.ClientCertificateError);
            TraceRequest(name, request, (r) => r.HasEntityBody);
            TraceRequest(name, request, (r) => r.Headers);
            TraceRequest(name, request, (r) => r.HttpMethod);
            TraceRequest(name, request, (r) => r.InputStream);
            TraceRequest(name, request, (r) => r.IsAuthenticated);
            TraceRequest(name, request, (r) => r.IsLocal);
            TraceRequest(name, request, (r) => r.IsSecureConnection);
            TraceRequest(name, request, (r) => r.KeepAlive);
            TraceRequest(name, request, (r) => r.LocalEndPoint);
            TraceRequest(name, request, (r) => r.ProtocolVersion);
            TraceRequest(name, request, (r) => r.QueryString);
            TraceRequest(name, request, (r) => r.RawUrl);
            TraceRequest(name, request, (r) => r.RemoteEndPoint);
            TraceRequest(name, request, (r) => r.RequestTraceIdentifier);
            TraceRequest(name, request, (r) => r.Url);
            TraceRequest(name, request, (r) => r.UrlReferrer);
            TraceRequest(name, request, (r) => r.UserAgent);
            TraceRequest(name, request, (r) => r.UserHostAddress);
            TraceRequest(name, request, (r) => r.UserHostName);
            TraceRequest(name, request, (r) => r.UserLanguages);
        }

        public void Dispose()
        {
            this.Stop();
        }

        public abstract HttpResponseMessage Process(HttpRequestMessage request);
        public HttpServerBase Start()
        {
            var temp = new List<HttpStage>(this.Stages);
            temp.Add(new ServerProcessingStage(this));
            temp.Add(new ThrowOnRequestStage());

            this.pipe = new HttpClient()
                {
                    Stages = temp
                };

            http.Start();
            http.BeginGetContext(OnContextAvailableCallback, this);

            if (!http.IsListening)
            {
                throw new InvalidOperationException("not listening");
            }
            return this;
        }
        public void Stop()
        {
            if (http.IsListening)
            {
                http.Close();
            }
        }
        static void OnContextAvailable(IAsyncResult result)
        {
            HttpRequestMessage request = null;
            HttpResponseMessage response = null;
            HttpListenerRequest listenerRequest = null;
            HttpListenerResponse listenerResponse = null;
            try
            {
                var self = (HttpServerBase) result.AsyncState;
                HttpListenerContext context;
                try
                {
                    result.AsyncWaitHandle.WaitOne();
                    if (!self.http.IsListening)
                    {
                        return;
                    }
                    context = self.http.EndGetContext(result);
                }
                catch (ObjectDisposedException ode)
                {
                    System.Diagnostics.Trace.WriteLine(ode.Message);
                    return;
                }
                catch (Exception e)
                {
                    System.Diagnostics.Trace.WriteLine(e);
                    // we're done
                    return;
                }
                Interlocked.Increment(ref self.requestsProcessed);
                self.http.BeginGetContext(OnContextAvailableCallback, self);
                listenerRequest = context.Request;
                if (self.TraceRequests)
                {
                    TraceRequest(self.GetType().Name, listenerRequest);
                }
                request = new HttpRequestMessage();
                request.Method = listenerRequest.HttpMethod;
                request.Uri = listenerRequest.Url;
                if (listenerRequest.HasEntityBody)
                {
                    request.Content = HttpContent.Create(listenerRequest.InputStream, listenerRequest.ContentType, listenerRequest.ContentLength64);
                }
                else
                {
                    request.Content = HttpContent.CreateEmpty();
                }
                foreach (var h in listenerRequest.Headers.AllKeys)
                {
                    foreach (var v in listenerRequest.Headers.GetValues(h))
                    {
                        request.Headers.Add(h, v);
                    }
                }
                // System.Diagnostics.Trace.WriteLine("SERVER: " + request.ToString());
                try
                {
                    response = self.pipe.Send(request);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
                listenerResponse = context.Response;
                listenerResponse.StatusCode = (int) response.StatusCode;

                if (!HttpContent.IsNullOrEmpty(response.Content) && response.Content.HasLength())
                {
                    listenerResponse.ContentLength64 = response.Content.GetLength();
                }

                foreach (var k in response.Headers.Keys)
                {
                    if (StringComparer.OrdinalIgnoreCase.Equals(k, "Content-Length"))
                    {
                        listenerResponse.ContentLength64 = response.Headers.ContentLength.Value;
                    }
                    else
                    {
                        foreach (var v in response.Headers.GetValues(k))
                        {
                            listenerResponse.Headers.Add(k, v);
                        }
                    }
                }

                if (!string.IsNullOrEmpty(response.Headers.ContentType))
                {
                    listenerResponse.ContentType = response.Headers.ContentType;
                }
                else if (!HttpContent.IsNullOrEmpty(response.Content) && !string.IsNullOrEmpty(response.Content.ContentType))
                {
                    listenerResponse.ContentType = response.Content.ContentType;
                }

                if (response.Method == "HEAD" && !HttpContent.IsNullOrEmpty(response.Content))
                {
                    Console.WriteLine("error: HEAD has content");
                }
                if (!HttpContent.IsNullOrEmpty(response.Content))
                {
                    var output = listenerResponse.OutputStream;
                    Trace.WriteLine(self + ": start writeto");
                    response.Content.WriteTo(output);
                    Trace.WriteLine(self + ": end writeto");
                    output.Flush();
                    Trace.WriteLine(self + ": flush");
                    output.Close();
                    Trace.WriteLine(self + ": close");
                }
                response.Dispose();
            }
            catch (Exception e)
            {
                Trace.WriteLine(e);
            }
            finally
            {
                if (listenerResponse != null)
                {
                    try
                    {
                        listenerResponse.Close();
                    }
                    catch (Exception e)
                    {
                        Trace.WriteLine("on closing response: " + e);
                    }
                }
                if (listenerRequest != null)
                {
                    try
                    {
                        listenerRequest.InputStream.Close();
                    }
                    catch (Exception e)
                    {
                        Trace.WriteLine("on closing request: " + e);
                    }
                }

                if (response != null)
                {
                    response.Dispose();
                }
                if (request != null)
                {
                    request.Dispose();
                }
            }
        }

        static void TraceRequest<T>(string name, HttpListenerRequest request, Expression<Func<HttpListenerRequest, T>> expr)
        {
            var f = expr.Compile();
            var val = f(request);
            string str;
            if (val == null)
            {
                str = "(null)";
            }
            else if (val is string[])
            {
                str = string.Join(", ", (string[])(object) val);
            }
            else if (val is NameValueCollection)
            {
                NameValueCollection nvc = (NameValueCollection)(object) val;
                str = "";
                foreach (var k in nvc.AllKeys)
                {
                    if (str.Length != 0)
                    {
                        str += ", ";
                    }
                    str += string.Format("{0} = \"{1}\"", k, nvc[k]);
                }
            }
            else
            {
                str = val.ToString();
            }
            System.Diagnostics.Trace.WriteLine(string.Format("{0,-30} {2,-20} {1}", expr.Body, str, typeof(T).Name), name);
        }

        class ServerProcessingStage : HttpStage
        {
            readonly HttpServerBase server;
            public ServerProcessingStage(HttpServerBase server)
            {
                this.server = server;
            }

            protected internal override void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
            {
                response = this.server.Process(request);
                state = null;
            }
            protected internal override void ProcessResponse(HttpResponseMessage response, object state)
            {
            }
        }

        class ThrowOnRequestStage : HttpProcessingStage
        {
            public override void ProcessRequest(HttpRequestMessage request)
            {
                throw new NotSupportedException();
            }

            public override void ProcessResponse(HttpResponseMessage response)
            {
            }
        }
    }
}
