﻿//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Diagnostics;

    public class UriScopeStage : HttpProcessingStage
    {
        public UriScopeStage(Uri baseAddress)
        {
            this.Scope = baseAddress;
        }
        public override void ProcessRequest(HttpRequestMessage request)
        {
            if (this.scope != null)
            {
                var calc = CalculateAndCheckAddress(this.scope, request.Uri);
                if (calc != request.Uri)
                {
                    Trace.WriteLine("Changed \"" + request.Uri + "\" to " + calc);
                    request.Uri = calc;
                }
            }
        }

        public override void ProcessResponse(HttpResponseMessage response)
        {
        }

        Uri scope;
        public Uri Scope
        {
            get
            {
                return scope;
            }
            set
            {
                if (value != null)
                {
                    if (!value.IsAbsoluteUri)
                    {
                        throw new UriFormatException(value + " is not an absolute Uri");
                    }
                    if (!string.IsNullOrEmpty(value.Query))
                    {
                        throw new UriFormatException(value + " has a query");
                    }
                    if (!string.IsNullOrEmpty(value.Fragment))
                    {
                        throw new UriFormatException(value + " has a fragment");
                    }
                    if (!string.IsNullOrEmpty(value.UserInfo))
                    {
                        throw new UriFormatException(value + " has a userinfo");
                    }
                }

                this.scope = value;
            }
        }

        public static Uri CalculateAndCheckAddress(Uri baseAddress, Uri uri)
        {
            Uri absolute;
            if (baseAddress == null)
            {
                if (!uri.IsAbsoluteUri)
                {
                    throw new ArgumentOutOfRangeException("uri", uri + " is not absolute");
                }
                absolute = uri;
            }
            else if (!uri.IsAbsoluteUri)
            {
                absolute = new Uri(baseAddress, uri);
            }
            else if (baseAddress.IsBaseOf(uri))
            {
                absolute = uri;
            }
            else
            {
                throw new ArgumentOutOfRangeException("uri", uri + " does not start with " + baseAddress);
            }

            if (baseAddress != null && !baseAddress.IsBaseOf(absolute))
            {
                throw new ArgumentOutOfRangeException("uri", uri + " does not start with " + baseAddress);
            }

            if (baseAddress != null && !absolute.AbsolutePath.StartsWith(baseAddress.AbsolutePath, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentOutOfRangeException("uri", uri + " does not start with " + baseAddress.AbsolutePath);
            }

            return absolute;
        }
    }
}