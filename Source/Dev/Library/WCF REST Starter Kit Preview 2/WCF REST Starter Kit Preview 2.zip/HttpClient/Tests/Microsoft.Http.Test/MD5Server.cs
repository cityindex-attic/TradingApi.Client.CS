//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.Server
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Http;
    using System.IO;
    using System.Security.Cryptography;
    using System.Net;

    public class MD5SignResponse : HttpStage
    {
        protected internal override void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            response = null;
            state = null;
        }

        protected internal override void ProcessResponse(HttpResponseMessage response, object state)
        {
            response.Content.LoadIntoBuffer();
            using (var alg = new MD5CryptoServiceProvider())
            {
                using (var stream = response.Content.ReadAsStream())
                {
                    var hash = alg.ComputeHash(stream);
                    response.Headers.ContentMD5 = hash;
                }
            }
        }

    }

}
