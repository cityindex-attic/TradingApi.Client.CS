//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.WcfProxy
{
    using System.ServiceModel;

    [ServiceContract(Namespace = "http://www.microsoft.com/")]
    public interface IWcfHttpProxy
    {
        [OperationContract]
        ProxiedHttpResponseMessage Send(ProxiedHttpMessage message);
    }

    public class ProxiedHttpMessage
    {

        public string Address
        {
            get;
            set;
        }

        // fully-buffered for now
        public byte[] Body
        {
            get;
            set;
        }
        public string HeaderBlock
        {
            get;
            set;
        }

        public string Method
        {
            get;
            set;
        }
    }
    public class ProxiedHttpResponseMessage : ProxiedHttpMessage
    {
        public string OriginalHeaders
        {
            get;
            set;
        }
        public int StatusCode
        {
            get;
            set;
        }
    }
}
