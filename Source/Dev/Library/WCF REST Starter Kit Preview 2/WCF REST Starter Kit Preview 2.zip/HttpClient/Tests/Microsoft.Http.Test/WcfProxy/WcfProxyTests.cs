//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.ServiceModel;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class WcfProxyTests
    {
        static ServiceHost host;
        static readonly Uri baseAddress = ServerHelper.ServerBaseAddress;
        static readonly string proxyAddress = baseAddress + "proxy.svc";

        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            if (host != null)
            {
                host.Close();
            }
        }
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            host = new ServiceHost(typeof(WcfProxy.WcfHttpProxyService), baseAddress);
            host.AddServiceEndpoint(typeof(WcfProxy.IWcfHttpProxy), new BasicHttpBinding(BasicHttpSecurityMode.None), proxyAddress);
            host.Open();
        }

        [TestMethod]
        public void TestWcfProxyTransportStage()
        {
            var direct = new HttpClient();
            using (var dr = direct.Send(new HttpRequestMessage("GET", ServerHelper.CharGenAddress + "1024/")))
            {
                Console.WriteLine(dr);
                Console.WriteLine(dr.ToHttpResponseString());
                dr.EnsureStatusIs(200);
            }
            var client = new HttpClient();

            client.Stages.Add(new WcfProxy.WcfProxyTransportStage(proxyAddress));
            client.Stages.Add(new ThrowOnRequestStage());

            using (var response = client.Send(new HttpRequestMessage("PUT", new Uri(ServerHelper.EchoAddress + "404/"), HttpContent.Create("hello", "text/html"))))
            {
                Console.WriteLine(response);
                Console.WriteLine(response.Request.Headers);
                Assert.AreEqual(5, response.Request.Headers.ContentLength);
                response.EnsureStatusIs(404);
                response.Dispose();
            }

            using (var response = client.Send(new HttpRequestMessage("GET", ServerHelper.CharGenAddress + "10")))
            {
                Console.WriteLine();
                Console.WriteLine(response.Request.ToHttpRequestString());
                Console.WriteLine();
                Console.WriteLine(response.ToHttpResponseString());
                response.EnsureStatusIs(200);
                Console.WriteLine(response);
                var bytes = response.Content.ReadAsByteArray();
                Console.WriteLine(bytes.Length);
                response.Dispose();
            }
        }
    }
}
