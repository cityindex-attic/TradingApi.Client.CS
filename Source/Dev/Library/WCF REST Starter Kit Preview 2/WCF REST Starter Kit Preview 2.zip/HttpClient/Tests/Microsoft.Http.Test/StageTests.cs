//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Text;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Http;
    using System.Threading;

    [TestClass]
    public class StageTests
    {
        [TestMethod]
        public void TestDelay()
        {
            var client = new HttpClient();
            client.Stages.Add(new AsyncDelayStage("delay", TimeSpan.Zero, TimeSpan.Zero));
            client.Send(new HttpRequestMessage("GET", ServerHelper.EchoAddress)).Dispose();
            client.EndSend(client.BeginSend(new HttpRequestMessage("GET", ServerHelper.EchoAddress), null, null)).Dispose();
        }

        [TestMethod]
        public void TestXyz()
        {
            var client = new HttpClient();
            client.Stages.Add(new ThrowOnRequestStage());
        }

    }

    public class AsyncDelayStage : HttpAsyncStage
    {

        string name;
        public AsyncDelayStage(string name)
            : this(name, TimeSpan.Zero, TimeSpan.Zero)
        {
        }
        public AsyncDelayStage(string name, TimeSpan request, TimeSpan response)
        {
            this.name = name;
            this.RequestDelay = request;
            this.ResponseDelay = response;
        }

        public TimeSpan RequestDelay
        {
            get;
            private set;
        }
        public TimeSpan ResponseDelay
        {
            get;
            private set;
        }
        public override string ToString()
        {
            return "AsyncDelayStage";
        }

        protected override internal IAsyncResult BeginProcessRequestAndTryGetResponse(HttpRequestMessage request, AsyncCallback callback, object state)
        {
            return new DelayRequestResult(name, request, this.RequestDelay, callback, state);
        }

        protected override internal IAsyncResult BeginProcessResponse(HttpResponseMessage response, object state, AsyncCallback callback, object callbackState)
        {
            return new DelayResponseResult(this.name, response, this.ResponseDelay, callback, callbackState);
        }
        protected override internal void EndProcessRequestAndTryGetResponse(IAsyncResult result, out HttpResponseMessage response, out object state)
        {
            AsyncStageAsyncResult.End(result, out response, out state);
        }
        protected override internal void EndProcessResponse(IAsyncResult result)
        {
            AsyncStageAsyncResult.End(result);
        }

        protected override internal void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            response = null;
            state = null;
            Console.WriteLine("request: sync version inside async stage");
            Thread.Sleep(this.RequestDelay);
        }

        protected override internal void ProcessResponse(HttpResponseMessage response, object state)
        {
            Console.WriteLine("response: sync version inside async stage");
            Thread.Sleep(this.ResponseDelay);
        }
        class DelayRequestResult : AsyncStageAsyncResult
        {
            readonly TimeSpan delay;
            readonly string name;
            public DelayRequestResult(string name, HttpRequestMessage request, TimeSpan delay, AsyncCallback callback, object state)
                : base(request, callback, state)
            {
                this.name = name;
                this.delay = delay;
                Console.WriteLine(this.Location() + " on main thread");
                ThreadPool.QueueUserWorkItem(Sleep, this);
                Console.WriteLine(this.Location() + " back from QueueUserWorkItem");
            }

            static void Sleep(object o)
            {
                DelayRequestResult result = (DelayRequestResult) o;
                Console.WriteLine(result.Location() + " blocking on threadpool thread for " + result.delay + " " + result.response);
                Thread.Sleep(result.delay);
                Console.WriteLine(result.Location() + " done blocking on threadpool thread");
                result.Complete(false, null, null);
            }
            string Location()
            {
                return "\t" + name + "\t" + "0x" + Thread.CurrentThread.ManagedThreadId.ToString("x4");
            }
        }
        class DelayResponseResult : AsyncStageAsyncResult
        {
            readonly TimeSpan delay;
            readonly string name;
            public DelayResponseResult(string name, HttpResponseMessage response, TimeSpan delay, AsyncCallback callback, object state)
                : base(response, callback, state)
            {
                this.delay = delay;
                this.name = name;
                Console.WriteLine(Location() + " on main thread");
                ThreadPool.QueueUserWorkItem(Sleep, this);
                Console.WriteLine(Location() + " back from QueueUserWorkItem");
            }

            static void Sleep(object o)
            {
                DelayResponseResult result = (DelayResponseResult) o;
                var delay = result.delay;
                Console.WriteLine(result.Location() + " blocking on threadpool thread for " + delay + " " + result.response);
                Thread.Sleep(delay);
                Console.WriteLine(result.Location() + " done blocking on threadpool thread");
                result.Complete(false);
            }
            string Location()
            {
                return "\t" + name + "\t" + "0x" + Thread.CurrentThread.ManagedThreadId.ToString("x4");
            }
        }
    }

}
