//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Http.Test.Server;
    using System.Diagnostics;

    static partial class ServerHelper
    {
        static readonly Uri echoAddress = new Uri(ServerHelper.ServerBaseAddress, "echo/");
        static Uri drain;
        static EchoServer echoServer;
        static int offset;
        public static Uri DrainAddress
        {
            get
            {
                if (drain == null)
                {
                    drain = new Uri(ServerHelper.EchoAddress, "drain/");
                }
                return drain;
            }
        }

        public static Uri EchoAddress
        {
            get
            {
                if (echoServer == null)
                {
                    echoServer = new EchoServer(echoAddress.ToString());
                    echoServer.Start();
                    Register(echoServer);
                }
                return echoAddress;
            }
        }
        public static int EchoRequests
        {
            get
            {
                if (echoServer == null)
                {
                    return 0;
                }
                return echoServer.RequestsProcessed - offset;
            }
        }
        public static void ResetEchoRequests()
        {
            if (echoServer != null)
            {
                offset = echoServer.RequestsProcessed;
            }
        }
    }


    [TestClass]
    class CheckNaming
    {
        [AssemblyInitialize]
        public static void CheckTestNaming(TestContext context)
        {
            HashSet<string> issues = new HashSet<string>();
            foreach (var type in typeof(ServerHelper).Assembly.GetTypes().Where((t) => t.Has<TestClassAttribute>()))
            {
                // TestMethodAttribute must be on a public class
                foreach (var m in type.GetMethods().Where((m) => m.Has<TestMethodAttribute>()))
                {
                    if (m.Has<ExpectedExceptionAttribute>() && !m.Name.EndsWith("Fails"))
                    {
                        issues.Add(m.DeclaringType + " " + m);
                    }

                    if (m.Name.EndsWith("Fails") && !m.Has<ExpectedExceptionAttribute>())
                    {
                        issues.Add(m.DeclaringType + " " + m);
                    }
                }
            }
            foreach (var s in issues.OrderBy((x) => x))
            {
                Console.WriteLine(s);
            }
            if (issues.Any())
            {
                Assert.Fail("one of the test names that has an ExpectedException doesn't include Fails; see warning log");
            }
        }
    }

    static class ReflectionExtensions
    {
        public static bool Has<TAttribute>(this System.Reflection.ICustomAttributeProvider provider) where TAttribute : Attribute
        {
            return provider.GetCustomAttributes(true).OfType<TAttribute>().Any();
        }
    }
}
