//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Threading;
    using System.Windows;
    using System.Windows.Controls;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Net;

    class NotReachableException : SystemException
    {
        public NotReachableException()
            : base("shouldn't have been reached")
        {
        }
    }
    class ThrowNotReachableOnRequestStage : HttpProcessingStage
    {
        public override void ProcessRequest(HttpRequestMessage request)
        {
            throw new NotReachableException();
        }
        public override void ProcessResponse(HttpResponseMessage response)
        {
        }
    }
    class ThrowNotReachableOnResponseStage : HttpProcessingStage
    {
        public override void ProcessRequest(HttpRequestMessage request)
        {
        }
        public override void ProcessResponse(HttpResponseMessage response)
        {
            throw new NotReachableException();
        }
    }

    // NOTE: this always completes synchronously 
    class ThrowAsyncCompleteSynchronouslyStage : HttpAsyncStage
    {
        readonly bool begin;
        readonly bool request;
        public ThrowAsyncCompleteSynchronouslyStage(bool begin, bool request)
        {
            this.request = request;
            this.begin = begin;
        }

        protected override internal IAsyncResult BeginProcessRequestAndTryGetResponse(HttpRequestMessage r, AsyncCallback callback, object state)
        {
            if (request && begin)
            {
                throw new ApplicationException();
            }
            return new CompletedAsyncResult(callback, state);
        }

        protected override internal IAsyncResult BeginProcessResponse(HttpResponseMessage response, object state, AsyncCallback callback, object callbackState)
        {
            if (!request && begin)
            {
                throw new ApplicationException();
            }
            return new CompletedAsyncResult(callback, callbackState);
        }

        protected override internal void EndProcessRequestAndTryGetResponse(IAsyncResult result, out HttpResponseMessage response, out object state)
        {
            if (request && !begin)
            {
                throw new ApplicationException();
            }
            CompletedAsyncResult.End(result);
            response = null;
            state = null;
        }

        protected override internal void EndProcessResponse(IAsyncResult result)
        {
            if (!request && !begin)
            {
                throw new ApplicationException();
            }
        }

        protected override internal void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            response = null;
            state = null;
        }
        protected override internal void ProcessResponse(HttpResponseMessage response, object state)
        {
        }
    }

    class EmptySyncStage : HttpStage
    {
        protected override internal void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            response = null;
            state = null;
        }

        protected override internal void ProcessResponse(HttpResponseMessage response, object state)
        {
        }
    }

    static class ThrowOnWriteContent
    {
        public static void WriteTo(System.IO.Stream stream)
        {
            Trace.WriteLine("throwing at " + Environment.StackTrace);
            throw new ApplicationException("write");
        }
    }

    class EmptyAsyncStage : HttpAsyncStage
    {

        readonly string name;
        public EmptyAsyncStage(string name)
        {
            this.name = name;
        }
        public bool ThrowOnEndReponse
        {
            get;
            set;
        }
        public override string ToString()
        {
            return base.ToString() + " " + name;
        }
        protected override internal IAsyncResult BeginProcessRequestAndTryGetResponse(HttpRequestMessage request, AsyncCallback callback, object state)
        {
            var my = new MyCompletedAsyncResult(callback, state);
            ThreadPool.QueueUserWorkItem(my.CompleteWaitCallback, name);
            return my;
        }

        protected override internal IAsyncResult BeginProcessResponse(HttpResponseMessage response, object state, AsyncCallback callback, object callbackState)
        {
            Debug.Assert(object.Equals(state, name));
            var my = new MyCompletedAsyncResult(callback, callbackState);
            my.CompleteWithException = this.ThrowOnEndReponse;
            ThreadPool.QueueUserWorkItem(my.CompleteWaitCallback, name);
            return my;
        }

        protected override internal void EndProcessRequestAndTryGetResponse(IAsyncResult result, out HttpResponseMessage response, out object state)
        {
            response = null;
            state = name;
            MyCompletedAsyncResult.End(result);
        }
        protected override internal void EndProcessResponse(IAsyncResult result)
        {
            MyCompletedAsyncResult.End(result);
        }

        protected override internal void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            response = null;
            state = "sync " + name;
        }

        protected override internal void ProcessResponse(HttpResponseMessage response, object state)
        {
            Debug.Assert(object.Equals(state, "sync " + name));
        }
        class MyCompletedAsyncResult : AsyncResult
        {
            public MyCompletedAsyncResult(AsyncCallback callback, object state)
                : base(callback, state)
            {
            }
            public bool CompleteWithException
            {
                get;
                set;
            }

            public static void End(IAsyncResult result)
            {
                AsyncResult.End<MyCompletedAsyncResult>(result);
            }
            public void CompleteWaitCallback(object x)
            {
                Trace.WriteLine("in complete waitcallback for " + x);
                Thread.Sleep(100);
                if (CompleteWithException)
                {
                    this.Complete(false, new ApplicationException("in waitcallback for " + x));
                }
                else
                {
                    this.Complete(false);
                }
            }
        }
    }

    enum ThrowLocation
    {
        None,
        BeginRequest,
        EndRequest,
        BeginResponse,
        EndResponse,
        Request,
        Response,
    }

    [TestClass]
    public sealed class AsyncTests
    {

        ManualResetEvent done;
        bool gotException;
        enum B
        {
            Begin,
            End
        }
        enum ExpectExceptionAt
        {
            Begin,
            Callback,
            None
        }
        enum T
        {
            Request,
            Response
        }
        public TestContext TestContext
        {
            get;
            set;
        }

        [TestInitialize]
        public void Init()
        {
            done = new ManualResetEvent(false);
            gotException = false;
        }

        [TestMethod]
        public void TestAsync1()
        {
            TestAsync(ExpectExceptionAt.None,
                new EmptySyncStage(),
                new EmptyAsyncStage("1"),
                new EmptyAsyncStage("2"),
                new FixedTransport((u) => new HttpResponseMessage()
                {
                    Uri = u,
                    StatusCode = System.Net.HttpStatusCode.OK
                }));
        }

        [TestMethod]
        public void TestAsync2()
        {
            HttpStage[] stages = new HttpStage[1000];
            for (int i = 0; i < stages.Length; ++i)
            {
                stages[i] = new EmptySyncStage();
            }
            stages[stages.Length - 1] = new FixedTransport((u) => new HttpResponseMessage());
            TestAsync(ExpectExceptionAt.None, stages);
        }

        [TestMethod]
        public void TestAsyncCancelOnRequest()
        {
            var stages = new HttpStage[] {
                    new EmptySyncStage(),
                    new EmptyAsyncStage("1"),
                    new AsyncDelayStage("delay", TimeSpan.FromSeconds(1), TimeSpan.Zero),
                    new ThrowOnRequestStage(),
                };
            TestCancel(stages);
        }
        [TestMethod]
        public void TestAsyncCancelOnResponse()
        {
            var stages = new HttpStage[] {
                    new EmptySyncStage(),
                    new ThrowOnResponseStage(),
                    new AsyncDelayStage("delay", TimeSpan.Zero, TimeSpan.FromSeconds(2)),
                    new FixedTransport(),
                };

            TestCancel(stages);
        }

        [TestMethod]
        public void TestAsyncThrowsAtCallback()
        {
            TestAsync(ExpectExceptionAt.Callback, new EmptySyncStage(),
                new EmptyAsyncStage("1"),
                new EmptyAsyncStage("2"),
                new ThrowOnRequestStage()
                );
        }

        [TestMethod]
        public void TestAsyncThrowsAtCallbackBecauseEndResponseThrows()
        {
            TestAsync(ExpectExceptionAt.Callback,
                new EmptySyncStage(),
                new ThrowNotReachableOnResponseStage(),
                new EmptyAsyncStage("0")
                {
                    ThrowOnEndReponse = true
                },
                new FixedTransport()
                );
        }
        [TestMethod]
        public void TestAsyncThrowsAtCallbackBecauseOneCompletedAsync()
        {
            TestAsync(ExpectExceptionAt.Callback,
                new EmptyAsyncStage("0"),
                new EmptySyncStage(),
                new ThrowOnRequestStage()
                );
        }
        [TestMethod]
        public void TestAsyncThrowsAtCallbackBecauseOneCompletedAsync2()
        {
            TestAsync(ExpectExceptionAt.Callback,
                new EmptySyncStage(),
                new EmptyAsyncStage("0"),
                new ThrowOnRequestStage()
                );
        }
        [TestMethod]
        public void TestAsyncThrowsAtCallbackWhenCompleteSync()
        {
            TestAsync(ExpectExceptionAt.Callback,
                new EmptySyncStage(),
                new EmptySyncStage(),
                new ThrowOnRequestStage()
                );
        }

        [TestMethod]
        public void TestBadHostName()
        {
            var client = new HttpClient();
            client.TransportSettings.ConnectionTimeout = TimeSpan.FromMilliseconds(100);
            Exception exception = null;
            HttpStatusCode responseCode = HttpStatusCode.OK;
            client.SendCompleted += (x, y) =>
            {
                Console.WriteLine(y);
                Console.WriteLine(y.Error);
                if (y != null && y.Response != null)
                {
                    responseCode = y.Response.StatusCode;
                }
                exception = y.Error;
                done.Set();
            };
            client.SendAsync(new HttpRequestMessage("GET", new Uri("http://www.microsoft" + Environment.TickCount + ".com")));
            done.WaitOne(TimeSpan.FromSeconds(5));
            Assert.IsTrue((exception != null) || (responseCode != HttpStatusCode.OK));
        }

        [TestCleanup]
        public void TestCleanup()
        {
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }
        [TestMethod]
        public void TestContentThrowsAreCaughtAsync()
        {
            var client = new HttpClient();
            client.Stages.Add(new AsyncDelayStage("t"));
            var result = client.BeginSend(new HttpRequestMessage("POST", ServerHelper.EchoAddress, HttpContent.Create(ThrowOnWriteContent.WriteTo)), Callback, client);

            var gotIt = done.WaitOne(TimeSpan.FromSeconds(5 * (Debugger.IsAttached ? 60 : 1)));
            Assert.IsTrue(gotIt, "didn't get MRE");
            Assert.IsTrue(gotException, "didn't get exception");
        }

        [TestMethod, ExpectedException(typeof(HttpStageProcessingException))]
        public void TestContentThrowsAreCaughtSyncFails()
        {
            var client = new HttpClient();
            client.Send(new HttpRequestMessage("POST", ServerHelper.EchoAddress, HttpContent.Create(ThrowOnWriteContent.WriteTo)));
        }

        [TestMethod]
        public void TestForm()
        {
            var client = new HttpClient();
            var req = new HttpRequestMessage("POST", ServerHelper.EchoAddress);
            var form = new HttpMultipartMimeForm();
            form.Add("x", "filename.txt", HttpContent.Create("hello world", "text/html"));
            req.Content = form.CreateHttpContent();
            // req.Content.LoadIntoBuffer();
            using (var response = client.Send(req))
            {
                Console.WriteLine(response);
            }
        }
        [TestMethod]
        public void TestInvalidRaisedWithoutTransport()
        {
            var r = new HttpStageProcessingAsyncResult(new HttpStageProcessingAsyncState(new ReadOnlyCollection<HttpStage>(new HttpStage[] {
                    new EmptyAsyncStage("0"), new EmptySyncStage() }), new HttpRequestMessage()), null, null);
            r.AsyncWaitHandle.WaitOne();
            try
            {
                HttpStageProcessingAsyncResult.End(r, true);
                Assert.Fail();
            }
            catch (HttpProcessingException e)
            {
                if (!(e.InnerException is InvalidOperationException))
                {
                    throw;
                }
                Console.WriteLine("expected " + e);
            }
        }

        [TestMethod]
        public void TestIsFatal()
        {
            Assert.IsTrue(AsyncResult.IsFatal(new OutOfMemoryException()));
            Assert.IsTrue(AsyncResult.IsFatal(new AsyncResult.CallbackException()));
            Assert.IsTrue(AsyncResult.IsFatal(new AccessViolationException()));
            Assert.IsFalse(AsyncResult.IsFatal(new ArgumentOutOfRangeException()));
            Assert.IsTrue(AsyncResult.IsFatal(new System.Runtime.InteropServices.SEHException()));
            Assert.IsTrue(AsyncResult.IsFatal(new TargetInvocationException("x", new OutOfMemoryException())));
            Assert.IsTrue(AsyncResult.IsFatal(new TypeInitializationException("x", new OutOfMemoryException())));

            try
            {
                Thread.CurrentThread.Abort();
            }
            catch (ThreadAbortException tae)
            {
                bool isFatal = AsyncResult.IsFatal(tae);
                Thread.ResetAbort();
                Console.WriteLine(isFatal);
            }
        }

        [TestMethod]
        public void TestPositiveSendAsync()
        {
            var client = new HttpClient();
            client.SendAsync(new HttpRequestMessage("GET", "http://www.microsoft.com"));
            done.Reset();
            Exception exception = null;
            client.SendCompleted += (x, y) =>
            {
                Console.WriteLine("was cancelled: " + y.Cancelled);
                Console.WriteLine("got exception: " + y.Error);
                if (y.Error == null)
                {
                    Console.WriteLine("response: " + y.Response);
                }
                exception = y.Error;
                done.Set();
            };
            bool gotIt = done.WaitOne(TimeSpan.FromSeconds(5));
            Assert.IsTrue(gotIt);
            Assert.IsNull(exception, "got exception");
        }

        [TestMethod]
        public void TestSendAsyncCancelRequest()
        {
            var stages = new HttpStage[] {
                    new EmptySyncStage(),
                    new AsyncDelayStage("delay", TimeSpan.FromSeconds(2), TimeSpan.Zero),
                    new ThrowOnRequestStage(),
                    new FixedTransport(),
                };

            var client = MakeHttpClient(stages);
            bool wasCancelled = false;
            client.SendCompleted += (x, y) =>
            {
                Console.WriteLine("was cancelled: " + y.Cancelled);
                wasCancelled = y.Cancelled;
                Console.WriteLine("got exception: " + y.Error);
                if (y.Error == null)
                {
                    Console.WriteLine("response: " + y.Response);
                }
                done.Set();
            };
            var myState = Guid.NewGuid();
            client.SendAsync(new HttpRequestMessage("GET", "http://localhost"), myState);
            Trace.WriteLine("back from send async");
            Thread.Sleep(TimeSpan.FromSeconds(1));
            client.SendAsyncCancel(myState);
            bool gotIt = done.WaitOne(TimeSpan.FromSeconds(2));
            Assert.IsTrue(gotIt);
            Assert.IsTrue(wasCancelled);
        }

        [TestMethod]
        public void TestSync1()
        {
            var stages = new HttpStage[] {
                    new EmptySyncStage(),
                    new EmptyAsyncStage("1"),
                    new FixedTransport((u)=>new HttpResponseMessage() { Uri = u})
                };
            var client = MakeHttpClient(stages);
            using (var response = client.Send(new HttpRequestMessage("GET", "http://www.microsoft.com")))
            {
                Console.WriteLine(response);
            }
        }

        [TestMethod]
        public void TestSyncCancelOnRequest2()
        {
            var stages = new HttpStage[] {
                    new EmptySyncStage(),
                    new EmptyAsyncStage("1"),
                    new DelayStage("delay", TimeSpan.FromSeconds(1), TimeSpan.Zero),
                    new ThrowOnRequestStage(),
                };
            TestCancel(stages);
        }
        [TestMethod]
        public void TestSyncNeverCallsAsyncAPI()
        {
            var stages = new HttpStage[] {
                    new EmptySyncStage(),
                    new EmptyAsyncStage("1"),
                    new ThrowAsyncCompleteSynchronouslyStage(true, true),
                    new FixedTransport((u)=>new HttpResponseMessage() { Uri = u})
                };
            var client = MakeHttpClient(stages);
            using (var response = client.Send(new HttpRequestMessage("GET", "http://localhost")))
            {
                Console.WriteLine(response);
            }
        }

        [TestMethod]
        public void TestThrowBeginRequest()
        {
            TestThrow(B.Begin, T.Request);
        }
        [TestMethod]
        public void TestThrowBeginResponse()
        {
            TestThrow(B.Begin, T.Response);
        }
        [TestMethod]
        public void TestThrowEndRequest()
        {
            TestThrow(B.End, T.Request);
        }
        [TestMethod]
        public void TestThrowEndResponse()
        {
            TestThrow(B.End, T.Response);
        }

        [TestMethod]
        public void TestThrowsNone()
        {
            TestAsync(ExpectExceptionAt.None, new FixedTransport((u) => new HttpResponseMessage()));
        }

        static HttpClient MakeHttpClient(params HttpStage[] stages)
        {
            var c = new HttpClient();
            foreach (var s in stages)
            {
                c.Stages.Add(s);
            }
            return c;
        }

        void Callback(IAsyncResult result)
        {
            Console.WriteLine("in callback");
            var client = (HttpClient)result.AsyncState;
            try
            {
                var response = client.EndSend(result);
                done.Set();
                response.Dispose();
            }
            catch (HttpStageProcessingException e)
            {
                if (e.InnerException is NotReachableException)
                {
                    Console.WriteLine("right exception, wrong place");
                    gotException = false;
                }
                else
                {
                    gotException = true;
                }
                Console.WriteLine("Stage: " + e);
                done.Set();
            }
            catch (Exception e)
            {
                gotException = false;
                Console.WriteLine("unexpected exception: " + e);
                done.Set();
            }
            finally
            {
                done.Set();
            }
        }

        void ExpectCancelCallback(IAsyncResult a)
        {
            Console.WriteLine(a.AsyncState + " " + a.CompletedSynchronously + " " + a.IsCompleted);
            try
            {
                var client = (HttpClient)a.AsyncState;
                var response = client.EndSend(a);
                Assert.Fail();
            }
            catch (OperationCanceledException cancelled)
            {
                gotException = true;
                Console.WriteLine(cancelled);
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
        }
        void TestAsync(ExpectExceptionAt where, params HttpStage[] stages)
        {
            Console.WriteLine("should throw: " + where);
            var client2 = new HttpClient();
            foreach (var s in stages)
            {
                client2.Stages.Add(s);
            }
            var request = new HttpRequestMessage("GET", "http://localhost?" + this.TestContext.TestName);
            if (where == ExpectExceptionAt.None)
            {
                client2.BeginSend(request, Callback, client2);
                bool gotIt = done.WaitOne(TimeSpan.FromSeconds(10));
                Assert.IsTrue(gotIt, "cb wasn't reached");
                Assert.IsFalse(gotException, "got exception");
                return;
            }

            if (where == ExpectExceptionAt.Begin)
            {
                bool fail = true;
                try
                {
                    client2.BeginSend(request, Callback, client2);
                }
                catch (HttpStageProcessingException e)
                {
                    // okay
                    Console.WriteLine("Begin: " + e);
                    Console.WriteLine("Begin: " + e.Request);
                    Console.WriteLine("Begin: " + e.Response);
                    Console.WriteLine("Begin: " + e.InnerException);
                    fail = false;
                }

                if (fail)
                {
                    Assert.Fail("didn't get an exception");
                }

                bool gotIt = done.WaitOne(TimeSpan.FromSeconds(0.01));
                Assert.IsFalse(gotIt); // shouldn't have been called
                Assert.IsFalse(gotException); // shouldn't have been reached
                return;
            }

            if (where == ExpectExceptionAt.Callback)
            {
                client2.BeginSend(request, Callback, client2); // throwing here will propogate == fail
                bool gotIt = done.WaitOne(TimeSpan.FromSeconds(2));
                Assert.IsTrue(gotIt, "didn't get");
                Assert.IsTrue(gotException, "got exception");
                return;
            }
        }

        void TestCancel(HttpStage[] stages)
        {
            var client = MakeHttpClient(stages);
            SendCompletedEventArgs args = null;
            client.SendCompleted += (x, y) =>
            {
                Trace.WriteLine("send completed " + y);
                args = y;
                done.Set();
            };

            var req = new HttpRequestMessage("GET", "http://localhost");
            client.SendAsync(req, client);
            Trace.WriteLine("back from BeginSend");
            Thread.Sleep(TimeSpan.FromSeconds(1));
            client.SendAsyncCancel(client);
            Trace.WriteLine("sent cancel");
            done.WaitOne(TimeSpan.FromSeconds(2));
            Assert.IsNotNull(args);
            Assert.IsTrue(args.Cancelled);
            var hspe = (HttpStageProcessingException)args.Error;
            Assert.AreSame(hspe.Request, req);
            Console.WriteLine(hspe.Stage);
        }
        void TestThrow(B beginOrEnd, T requestOrResponse)
        {
            var client = MakeHttpClient(
                new EmptyAsyncStage("0"),
                new ThrowAsyncCompleteSynchronouslyStage(beginOrEnd == B.Begin, requestOrResponse == T.Request),
                new FixedTransport()
                );

            var result = client.BeginSend(new HttpRequestMessage("POST", ServerHelper.EchoAddress, HttpContent.Create("hello")), Callback, client);

            var gotIt = done.WaitOne(TimeSpan.FromSeconds(5 * (Debugger.IsAttached ? 60 : 1)));
            Assert.IsTrue(gotIt, "didn't get MRE");
            Assert.IsTrue(gotException, "didn't get exception");
        }
    }

    [TestClass, Ignore]
    public class WpfAsyncTests
    {

        static HttpClient client = new HttpClient();
        static bool GotException;
        static TextBox text;
        [TestMethod]
        public void TestMethod1()
        {
            text = new TextBox();
            var b = new Button()
                {
                    Content = "sendasync",
                };

            client.SendCompleted += client_SendCompleted;
            b.Click += (x, y) =>
            {
                client.SendAsync(new HttpRequestMessage("GET", "http://www.microsoft.com"));
            };

            var b2 = new Button()
                {
                    Content = "beginsend",
                };

            b2.Click += (x, y) =>
            {
                client.BeginSend(new HttpRequestMessage("GET", "http://www.google.com"), EndSendCallback, client);
            };

            var w = new Window();
            w.Content = new DockPanel()
                {
                    LastChildFill = true,
                    Children = { new StackPanel() { Children = { b, b2 } }, text }
                };

            new Application()
                {
                }.Run(w);

            Assert.IsFalse(GotException);
        }
        static void EndSendCallback(IAsyncResult result)
        {
            try
            {
                var c = result.AsyncState as HttpClient;
                var response = c.EndSend(result);
                text.Text = result.ToString();
            }
            catch (Exception ex)
            {
                GotException = true;
                Console.WriteLine(ex);
            }
        }

        void client_SendCompleted(object sender, SendCompletedEventArgs e)
        {
            try
            {
                text.Text = e.Response.ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                GotException = true;
            }
        }
    }

    [TestClass]
    public class SyncContextTests
    {

        static readonly List<string> extraIncrements = new List<string>();

        readonly ManualResetEvent done = new ManualResetEvent(false);

        SynchronizationContext before;
        CustomSyncContext custom;
        bool fail;

        public TestContext TestContext
        {
            get;
            set;
        }

        [ClassCleanup]
        public static void CounterCleanup()
        {
            if (extraIncrements.Any())
            {
                extraIncrements.ForEach(Console.WriteLine);
                Assert.Fail("extra increments");
            }
        }

        [TestMethod]
        public void TestAsyncUserStateDuplicatedException()
        {
            var client = new HttpClient();
            client.SendCompleted += new EventHandler<SendCompletedEventArgs>(client_SendCompleted);
            var key = Guid.NewGuid();
            client.SendAsync(new HttpRequestMessage("GET", ServerHelper.EchoAddress + "?request1"), key);
            try
            {
                client.SendAsync(new HttpRequestMessage("GET", ServerHelper.EchoAddress + "?request2"), key);
                Assert.Fail("should not have been reached");
            }
            catch (ArgumentException argument)
            {
                Console.WriteLine(argument);
                if (!argument.Message.Contains("request1"))
                {
                    throw;
                }
            }
            finally
            {
                done.WaitOne();
            }
        }

        [TestMethod]
        public void TestBeginSendIsNotOnSyncContext()
        {
            var client = new HttpClient(ServerHelper.EchoAddress);

            var result = client.BeginSend(new HttpRequestMessage(), (state) => Console.WriteLine("callback " + state), Guid.NewGuid());
            result.AsyncWaitHandle.WaitOne();
            var response = client.EndSend(result);

            Assert.AreEqual(0, custom.Counters.TotalOperations);

        }

        [TestCleanup]
        public void TestCleanup()
        {
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " " + Thread.CurrentThread.Name + " ");
            SynchronizationContext.SetSynchronizationContext(before);
            if (fail)
            {
                Assert.Fail("fail");
            }
            Console.WriteLine(custom.Counters.PendingOperations + " pending");
            Assert.AreEqual(0, custom.Counters.PendingOperations, custom.Counters.PendingOperations + " PendingOperations did not complete");
        }

        [TestMethod]
        public void TestDisposeRequest()
        {
            for (int i = 0; i < 10; ++i)
            {
                var client = new HttpClient();
                done.Reset();
                var request = new HttpRequestMessage("POST", ServerHelper.EchoAddress, HttpContent.Create(new MemoryStream(new byte[256])));
                Exception ex = null;
                client.SendCompleted += (x, y) =>
                {
                    try
                    {
                        Console.WriteLine(y.Response);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        ex = e;
                    }
                };
                client.SendCompleted += new EventHandler<SendCompletedEventArgs>(client_SendCompleted);
                client.SendAsync(request);
                request.Dispose();
                done.WaitOne();
                Assert.IsNotNull(ex);
                Assert.IsInstanceOfType(ex.InnerException, typeof(ObjectDisposedException));
            }
        }
        [TestInitialize]
        public void TestInit()
        {
            // ensure echo address is started
            Console.WriteLine(ServerHelper.EchoAddress);
            this.fail = false;
            this.done.Reset();
            this.before = SynchronizationContext.Current;
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " " + Thread.CurrentThread.Name + " ");
            Console.WriteLine(before == null ? "null" : before.GetType().ToString());
            this.custom = new CustomSyncContext(this.TestContext.TestName);
            SynchronizationContext.SetSynchronizationContext(this.custom);
        }

        [TestMethod]
        public void TestMultipleNoStateAsync()
        {
            // In general, do not raise an exception if the MethodNameAsync method _without_ the userSuppliedState parameter is invoked multiple times 
            // so that there are multiple outstanding operations. You can raise an exception when your class explicitly cannot handle that situation,
            // but assume that developers can handle these multiple indistinguishable callbacks.
            // http://msdn.microsoft.com/en-us/library/ms228974(VS.80).aspx
            var client = new HttpClient(ServerHelper.EchoAddress);
            client.SendCompleted += (x, y) =>
            {
                y.Response.Dispose();
            };
            using (var c = new SendAsyncCounter(client, 3))
            {
                client.SendAsync(new HttpRequestMessage());
                client.SendAsync(new HttpRequestMessage());
                client.SendAsync(new HttpRequestMessage());
            }
            client.Dispose();
        }


        [TestMethod]
        public void TestMultipleStateAsync()
        {
            // You must be careful to provide a unique value for userState in your calls to multiple-invocation overloads.
            // Non-unique task IDs will cause the asynchronous class throw an ArgumentException.
            // http://msdn.microsoft.com/en-us/library/wewwczdw(VS.80).aspx

            ServerHelper.ResetEchoRequests();
            var client = new HttpClient(ServerHelper.EchoAddress);
            var mre = new ManualResetEvent(false);
            client.SendCompleted += (x, y) =>
            {
                mre.Set();
            };
            using (var c = new SendAsyncCounter(client, 1))
            {
                client.SendAsync(new HttpRequestMessage(), "a");
                try
                {
                    client.SendAsync(new HttpRequestMessage(), "a");

                    Assert.Fail();
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e);
                }
                mre.WaitOne();
            }
            using (new SendAsyncCounter(client, 1))
            {
                mre.Reset();
                client.SendAsync(new HttpRequestMessage(), "a");
                mre.WaitOne();
            }
            Assert.AreEqual(2, ServerHelper.EchoRequests);
        }

        [TestMethod]
        public void TestMultipleStateNullAsync()
        {
            // In general, do not raise an exception if the MethodNameAsync method _without_ the userSuppliedState parameter is invoked multiple times 
            // so that there are multiple outstanding operations. You can raise an exception when your class explicitly cannot handle that situation,
            // but assume that developers can handle these multiple indistinguishable callbacks.
            // http://msdn.microsoft.com/en-us/library/ms228974(VS.80).aspx
            var client = new HttpClient(ServerHelper.EchoAddress);
            using (var counter = new SendAsyncCounter(client, 3))
            {
                client.SendAsync(new HttpRequestMessage(), null);
                client.SendAsync(new HttpRequestMessage());
                client.SendAsync(new HttpRequestMessage(), null);
                counter.Complete();
            }
            client.Dispose();
        }

        [TestMethod]
        public void TestSendAsync()
        {
            Assert.IsInstanceOfType(SynchronizationContext.Current, typeof(CustomSyncContext));
            Console.WriteLine(WhereAmI());
            var client = new HttpClient(ServerHelper.EchoAddress);
            client.SendCompleted += new EventHandler<SendCompletedEventArgs>(client_SendCompleted);
            var userState = new Guid();
            client.SendAsync(new HttpRequestMessage(), userState);
            bool gotIt = done.WaitOne(TimeSpan.FromSeconds(5));
            client.SendAsyncCancel(userState); // should be a noop
            client.Dispose();
            Assert.IsTrue(gotIt);
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestSendAsyncCancelNullFails()
        {
            var client = new HttpClient();
            client.SendAsyncCancel(null);
        }


        [TestMethod]
        public void TestSendAsyncDoesNotThrowHttpStageExceptions()
        {
            var client = new HttpClient();
            client.Stages.Add(new ThrowOnRequestStage());
            client.SendAsync(new HttpRequestMessage("GET", ServerHelper.EchoAddress));
        }

        [TestMethod]
        public void TestWebClient()
        {
            var wc = new System.Net.WebClient();
            wc.DownloadDataCompleted += (x, y) =>
            {
                Console.WriteLine(x + " " + y);
                done.Set();
            };
            wc.DownloadDataAsync(ServerHelper.EchoAddress);
            done.WaitOne();
            Assert.AreEqual(1, custom.Counters.TotalOperations);
        }

        static string WhereAmI()
        {
            return (Thread.CurrentThread.ManagedThreadId + " " + Thread.CurrentThread.Name + " " + SynchronizationContext.Current).Trim();
        }
        void client_SendCompleted(object sender, SendCompletedEventArgs e)
        {
            // Console.WriteLine(Environment.StackTrace);
            Console.WriteLine();
            Console.WriteLine(WhereAmI() + ": send completed");
            Console.WriteLine(WhereAmI() + ": " + e);

            int before = custom.Counters.Posts;
            if (SynchronizationContext.Current != null)
            {
                SynchronizationContext.Current.Post((x) =>
                {
                    Console.WriteLine(x);
                }
                    , 12345);
                fail = custom.Counters.Posts == before;
            }

            done.Set();
        }
        class CustomSyncContext : SynchronizationContext
        {
            readonly string name;
            public CustomSyncContext(string name)
            {
                this.name = name;
                this.Counters = new Counts();
            }

            public Counts Counters
            {
                get;
                private set;
            }
            public override SynchronizationContext CreateCopy()
            {
                return new CustomSyncContext(this.name + " copy")
                    {
                        Counters = this.Counters
                    };
            }
            public override void OperationCompleted()
            {
                int op = --this.Counters.PendingOperations;

                Display("OperationCompleted pending = " + op);
                base.OperationCompleted();
            }
            public override void OperationStarted()
            {
                ++this.Counters.TotalOperations;
                int op = ++this.Counters.PendingOperations;
                Display("OperationStarted pending = " + op);
                base.OperationStarted();
            }
            public override void Post(SendOrPostCallback d, object state)
            {
                ++this.Counters.Posts;
                Display("Post " + d.Method + " " + state);
                ThreadPool.QueueUserWorkItem((x) =>
                {
                    try
                    {
                        d(state);
                    }
                    catch (Exception e)
                    {
                        Debug.WriteLine("post: " + e);
                        throw;
                    }
                }
                    );
            }

            public override void Send(SendOrPostCallback d, object state)
            {
                ++this.Counters.Sends;
                Display("Send " + d.Method + " " + state);
                d(state);
            }
            public override string ToString()
            {
                return this.GetType() + "(" + this.name + ")";
            }

            void Display(string message)
            {
                Console.WriteLine(name + ": " + message);
            }
            public class Counts
            {
                public int PendingOperations
                {
                    get;
                    set;
                }
                public int Posts
                {
                    get;
                    set;
                }
                public int Sends
                {
                    get;
                    set;
                }
                public int TotalOperations
                {
                    get;
                    set;
                }
            }
        }

        class SendAsyncCounter : IDisposable
        {
            readonly HttpClient client;
            readonly int expect;
            readonly EventHandler<SendCompletedEventArgs> handler;
            readonly AutoResetEvent incremented;
            int c;
            bool completed;
            public SendAsyncCounter(HttpClient client, int expect)
            {
                this.client = client;
                this.handler = (x, y) =>
                {
                    this.Increment();
                };
                this.client.SendCompleted += handler;
                this.expect = expect;
                this.PerRequest = TimeSpan.FromSeconds(0.2);
                this.incremented = new AutoResetEvent(false);
            }
            public TimeSpan PerRequest
            {
                get;
                set;
            }
            public void Complete()
            {
                Assert.IsFalse(completed);
                var started = DateTime.UtcNow;
                var expires = started + TimeSpan.FromSeconds(this.PerRequest.TotalSeconds * this.expect);
                try
                {
                    while (c < expect && DateTime.UtcNow < expires)
                    {
                        Console.WriteLine("waiting");
                        bool gotIt = incremented.WaitOne(this.PerRequest);
                        if (!gotIt)
                        {
                            Console.WriteLine("didn't get it");
                        }
                    }
                    Assert.AreEqual(expect, c, "counter");
                }
                finally
                {
                    completed = true;
                    Console.WriteLine(DateTime.UtcNow - started);
                    this.incremented.Close();
                    this.client.SendCompleted -= handler;
                }
                Assert.AreEqual(expect, c, "counter");
            }

            public void Dispose()
            {
                if (completed)
                {
                    return;
                }
                Complete();
            }
            void Increment()
            {
                var after = Interlocked.Increment(ref c);
                Console.WriteLine("incremented " + after);

                if (after > expect)
                {
                    Console.WriteLine("too many!");
                    extraIncrements.Add(string.Format("after {0}, expect {1}", after, expect) + Environment.StackTrace + Environment.NewLine + Environment.NewLine);
                }
                if (completed)
                {
                    Console.WriteLine("incremented after complete!");
                }
                else
                {
                    incremented.Set();
                }
            }
        }
    }

    [TestClass]
    public class TestCancellation
    {

        [TestMethod]
        public void TestCancelLargeDownload()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage("GET", new Uri(ServerHelper.CharGenAddress, "12345678"));

            var done = new ManualResetEvent(false);
            SendCompletedEventArgs completed = null;
            client.SendCompleted += (x, args) =>
            {
                completed = args;
                Console.WriteLine(args);
                if (args.Cancelled)
                {
                    Console.WriteLine(args.Error);
                }
                done.Set();
            };
            var bufferer = new AutomaticallyBufferResponseStage();
            client.Stages.Add(bufferer);

            client.SendAsync(request, request);
            bufferer.OnStartBuffering.WaitOne();
            Thread.Sleep(10);
            client.SendAsyncCancel(request);

            bool gotIt = done.WaitOne(TimeSpan.FromSeconds(5));
            Assert.IsNotNull(completed);
            Assert.IsTrue(completed.Cancelled);
        }

        [TestMethod]
        public void TestCancelSlowWrite()
        {
            var client = new HttpClient();
            var delay = TimeSpan.FromMilliseconds(200);
            var total = 10;
            var slow = new SlowWriter(total, 65536 * 2);
            slow.SleepAfterEachWrite = delay;
            slow.SleepOnEnter = TimeSpan.FromMilliseconds(500);
            slow.SleepOnEnterCompleted = new ManualResetEvent(false);
            var request = new HttpRequestMessage("PUT", ServerHelper.DrainAddress, HttpContent.Create(slow));
            var done = new ManualResetEvent(false);
            SendCompletedEventArgs completed = null;
            client.SendCompleted += (x, args) =>
            {
                completed = args;
                Console.WriteLine(args);
                done.Set();
            };

            client.SendAsync(request, request);
            slow.SleepOnEnterCompleted.WaitOne();
            Thread.Sleep(slow.SleepAfterEachWrite);
            client.SendAsyncCancel(request);

            bool gotIt = done.WaitOne(TimeSpan.FromSeconds(5));
            Assert.IsNotNull(completed);
            Assert.IsTrue(completed.Cancelled);
            Console.WriteLine(slow.CompletedWrites + " writes completed");
            Assert.AreNotEqual(0, slow.CompletedWrites);
            Assert.AreNotEqual(total, slow.CompletedWrites);
        }
        [TestMethod]
        public void TestSlowWrite()
        {
            var client = new HttpClient();
            var slow = new SlowWriter(2, 256);
            slow.SleepAfterEachWrite = TimeSpan.FromMilliseconds(200);
            var request = new HttpRequestMessage("PUT", ServerHelper.DrainAddress, HttpContent.Create(slow));
            var response = client.Send(request);
            var message = response.Content.ReadAsString();
            Console.WriteLine(message);
            response.Dispose();
            Assert.AreEqual("drained " + (slow.WriteCalls * slow.BytesPerWrite), message);
            Console.WriteLine(request.Properties.Count);
        }

        class AutomaticallyBufferResponseStage : HttpProcessingStage
        {
            public readonly AutoResetEvent OnStartBuffering = new AutoResetEvent(false);
            public override void ProcessRequest(HttpRequestMessage request)
            {
            }
            public override void ProcessResponse(HttpResponseMessage response)
            {
                OnStartBuffering.Set();
                response.Content.LoadIntoBuffer();
            }
        }


        class SlowWriter : ICreateHttpContent
        {
            public SlowWriter(int writeCalls, int bytesPerWrite)
            {
                this.WriteCalls = writeCalls;
                this.BytesPerWrite = bytesPerWrite;
            }
            public int BytesPerWrite
            {
                get;
                set;
            }

            public int CompletedWrites
            {
                get;
                private set;
            }
            public TimeSpan SleepAfterEachWrite
            {
                get;
                set;
            }

            public TimeSpan? SleepOnEnter
            {
                get;
                set;
            }

            public EventWaitHandle SleepOnEnterCompleted
            {
                get;
                set;
            }
            public int WriteCalls
            {
                get;
                set;
            }

            public HttpContent CreateHttpContent()
            {
                return HttpContent.Create(this.WriteTo, null, this.WriteCalls * this.BytesPerWrite);
            }
            public void WriteTo(Stream s)
            {
                var buffer = new byte[this.BytesPerWrite];
                new Random().NextBytes(buffer);
                if (SleepOnEnter != null)
                {
                    Thread.Sleep(SleepOnEnter.Value);
                }
                if (SleepOnEnterCompleted != null)
                {
                    SleepOnEnterCompleted.Set();
                }
                for (int i = 0; i < this.WriteCalls; ++i)
                {
                    s.Write(buffer, 0, buffer.Length);
                    ++this.CompletedWrites;
                    Thread.Sleep(this.SleepAfterEachWrite);
                }
            }
        }
    }
}
