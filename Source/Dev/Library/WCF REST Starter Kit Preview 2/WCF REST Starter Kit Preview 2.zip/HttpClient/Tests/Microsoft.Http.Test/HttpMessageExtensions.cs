//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.IO;
    using System.Text;
    using Microsoft.Http;


    public static class HttpMessageExtensions
    {
        public static string ToHttpRequestString(this HttpRequestMessage request)
        {
            using (var buffer = new MemoryStream())
            {
                var writer = new StreamWriter(buffer);
                writer.AutoFlush = true;
                writer.WriteLine(request.Method + " " + request.Uri);
                var headers = request.Headers.ToString().Trim();
                if (headers.Length != 0)
                {
                    writer.WriteLine(headers);
                }
                writer.WriteLine();
                writer.Flush();
                if (!HttpContent.IsNullOrEmpty(request.Content))
                {
                    request.Content.LoadIntoBuffer();
                    request.Content.WriteTo(buffer);
                }
                buffer.Flush();

                var bytes = buffer.ToArray();
                return Encoding.Default.GetString(bytes).Trim();
            }
        }

        public static string ToHttpResponseString(this HttpResponseMessage response)
        {
            using (var buffer = new MemoryStream())
            {
                var writer = new StreamWriter(buffer);
                writer.AutoFlush = true;
                writer.WriteLine(response.Method + " " + response.Uri + " " + (int) response.StatusCode + " " + response.StatusCode);
                writer.WriteLine(response.Headers.ToString());
                writer.WriteLine();
                writer.Flush();
                try
                {
                    if (!HttpContent.IsNullOrEmpty(response.Content))
                    {
                        response.Content.LoadIntoBuffer();
                        response.Content.WriteTo(buffer);
                    }
                }
                catch (Exception e)
                {
                    writer.WriteLine(e);
                    throw;
                }
                buffer.Flush();

                var bytes = buffer.ToArray();
                return Encoding.Default.GetString(bytes).Trim();
            }
        }
    }
}
