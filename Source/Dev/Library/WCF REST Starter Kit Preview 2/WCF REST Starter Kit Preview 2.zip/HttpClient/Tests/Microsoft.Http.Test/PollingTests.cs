//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Net;
    using System.Runtime.Serialization;
    using System.Security.Principal;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Threading;
    using Microsoft.Http;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class PollingTests
    {
        static readonly Uri CounterUri = new Uri(ServerHelper.ServerBaseAddress, "Counter/");
        bool expectSyncContext;
        ManualResetEvent sync = new ManualResetEvent(false);

        public TestContext TestContext
        {
            get;
            set;
        }

        [TestCleanup]
        public void TestCleanup()
        {
            GC.WaitForPendingFinalizers();
        }

        [TestMethod]
        public void TestConditionalGetAndLastModifiedPolling()
        {
            TestPolling(true, true, null);
        }

        [TestMethod]
        public void TestConditionalGetPolling()
        {
            TestPolling(false, true, null);
        }

        [TestMethod]
        public void TestLastModifiedPolling()
        {
            TestPolling(true, false, null);
        }

        [TestMethod]
        public void TestOpenCloseToEnsureCanListen()
        {
            Console.WriteLine(CounterUri);
            var host = new WebServiceHost(new CounterService()
                {
                    SendLastModified = false,
                    SendEtag = false
                }, CounterUri);
            host.Faulted += (x, y) =>
            {
                Console.WriteLine(x + " " + y);
            };
            var timeout = TimeSpan.FromSeconds(2);
            host.Open(timeout);
            host.Close(timeout);
        }

        [TestMethod]
        public void TestSynchContextPolling()
        {
            TestPolling(true, false, new CustomSynchronizationContext());
        }

        void agent_ResourceChanged(object sender, ConditionalGetEventArgs e)
        {
            if (e.SendError != null)
            {
                throw new Exception("Unexpected send error", e.SendError);
            }
            if (this.expectSyncContext && Thread.CurrentPrincipal != CustomSynchronizationContext.Principal)
            {
                throw new Exception("Expected sync context not set");
            }
            Counter counter = e.Response.Content.ReadAsDataContract<Counter>();
            Console.WriteLine("Resource was changed. New resource value={0}", counter.Value);
            if (counter.Value % 3 != 0)
            {
                throw new Exception("Counter value not valid");
            }
            if (counter.Value == 6)
            {
                e.StopPolling = true;
                sync.Set();
            }
        }

        void TestPolling(bool sendLastModified, bool sendEtag, SynchronizationContext syncContext)
        {
            sync.Reset();
            this.expectSyncContext = (syncContext != null);
            using (WebServiceHost host = new WebServiceHost(new CounterService()
                {
                    SendLastModified = sendLastModified,
                    SendEtag = sendEtag
                }, CounterUri))
            {
                host.Open();
                SynchronizationContext.SetSynchronizationContext(syncContext);
                HttpClient client = new HttpClient(CounterUri);
                var timeout = TimeSpan.FromSeconds(1);
                using (PollingAgent agent = new PollingAgent()
                    {
                        HttpClient = client,
                        PollingInterval = timeout,
                    })
                {
                    agent.ResourceChanged += new EventHandler<ConditionalGetEventArgs>(agent_ResourceChanged);
                    agent.StartPolling();
                    bool gotIt = sync.WaitOne(TimeSpan.FromSeconds(timeout.TotalSeconds * 10));
                    Assert.IsTrue(gotIt);
                }
                host.Close();
            }
        }

        [DataContract]
        class Counter
        {
            [DataMember]
            public int Value
            {
                get;
                set;
            }
        }

        [ServiceContract]
        [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
        class CounterService
        {
            Counter counter = new Counter();
            DateTime lastModified;
            int numCalls;

            public bool SendEtag
            {
                get;
                set;
            }

            public bool SendLastModified
            {
                get;
                set;
            }

            [WebGet(UriTemplate = "")]
            [OperationContract]
            public Counter Get()
            {
                if (this.numCalls % 3 == 0)
                {
                    this.counter.Value = this.numCalls;
                    this.lastModified = DateTime.UtcNow;
                    ++this.numCalls;
                    if (this.SendLastModified)
                    {
                        WebOperationContext.Current.OutgoingResponse.LastModified = this.lastModified;
                    }
                    if (this.SendEtag)
                    {
                        WebOperationContext.Current.OutgoingResponse.ETag = "\"" + this.counter.Value.ToString() + "\"";
                    }
                    return this.counter;
                }
                else
                {
                    ++this.numCalls;
                    // if the client sent an IfModifiedSince request, check if the modification time matches
                    string ifModifiedSinceVal = WebOperationContext.Current.IncomingRequest.Headers[HttpRequestHeader.IfModifiedSince];
                    if (!string.IsNullOrEmpty(ifModifiedSinceVal))
                    {
                        DateTime ifModifiedSince = DateTime.Parse(ifModifiedSinceVal).ToUniversalTime();
                        if (ifModifiedSince.Year == this.lastModified.Year && ifModifiedSince.Day == this.lastModified.Day &&
                            ifModifiedSince.Hour == this.lastModified.Hour && ifModifiedSince.Minute == this.lastModified.Minute &&
                            ifModifiedSince.Second == this.lastModified.Second)
                        {
                            WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.NotModified;
                            return null;
                        }
                    }
                    // if the client sent a conditional get, check the etag
                    string etag = WebOperationContext.Current.IncomingRequest.Headers[HttpRequestHeader.IfNoneMatch];
                    if (!string.IsNullOrEmpty(etag))
                    {
                        if (("\"" + this.counter.Value.ToString() + "\"") == etag)
                        {
                            WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.NotModified;
                            return null;
                        }
                    }
                    if (this.SendLastModified)
                    {
                        WebOperationContext.Current.OutgoingResponse.LastModified = this.lastModified;
                    }
                    if (this.SendEtag)
                    {
                        WebOperationContext.Current.OutgoingResponse.ETag = "\"" + this.counter.Value.ToString() + "\"";
                    }
                    return this.counter;
                }
            }
        }

        class CustomSynchronizationContext : SynchronizationContext
        {
            static readonly IPrincipal principal = new GenericPrincipal(new GenericIdentity("test"), new string[] { });

            public static IPrincipal Principal
            {
                get
                {
                    return principal;
                }
            }

            public override void Post(SendOrPostCallback d, object state)
            {
                Send(d, state);
            }

            public override void Send(SendOrPostCallback d, object state)
            {
                Thread.CurrentPrincipal = principal;
                try
                {
                    d(state);
                }
                finally
                {
                    Thread.CurrentPrincipal = null;
                }
            }
        }

    }
}
