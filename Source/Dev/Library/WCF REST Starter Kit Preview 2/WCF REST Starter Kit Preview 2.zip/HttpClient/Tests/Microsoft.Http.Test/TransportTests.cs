//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Net;
    using System.Net.Mime;
    using System.Reflection;
    using Microsoft.Http;
    using Microsoft.Http.Test.Content;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TransportTests
    {
        public TransportTests()
        {
        }


        [TestMethod]
        public void TestAsync()
        {
            var client = new HttpClient();
            var result = client.BeginSend(new HttpRequestMessage("POST", ServerHelper.EchoAddress, HttpContent.Create("hello")), null, null);
            result.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(5));
            var response = client.EndSend(result);
            Console.WriteLine(response.ToHttpResponseString());
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestCheckNullInMethodsFails()
        {
            HttpMethodExtensions.Get(null, null, null);
        }

        [TestMethod]
        public void TestFixedTransport()
        {
            var client = new HttpClient(ServerHelper.CharGenAddress);
            client.Stages.Add(new FixedTransport((key) => new HttpResponseMessage()
                {
                    Uri = key,
                    Method = "GET",
                    StatusCode = HttpStatusCode.OK,
                    Content = HttpContent.Create(key.ToString())
                }));
            client.Stages.Add(new ThrowOnRequestStage());
            using (var response = client.Get(ServerHelper.CharGenAddress + "1024"))
            {
                response.Content.WriteTo(Console.OpenStandardOutput());
            }
        }

        [TestMethod]
        public void TestHttpMethodsAgainstEchoServerViaReflection()
        {
            var client = new HttpClient(ServerHelper.EchoAddress);

            Dictionary<Type, Func<object>> lookup = new Dictionary<Type, Func<object>>()
                {
                    {typeof(HttpClient), ()=>client},
                    { typeof(Uri), ()=> ServerHelper.EchoAddress },
                    { typeof(string), ()=>ServerHelper.EchoAddress.ToString() },
                    { typeof(ContentType), ()=>new ContentType("text/html")},
                    { typeof(HttpQueryString), () => new HttpQueryString() { {"x", "123"}, {"y", "456"}}},
                    { typeof(IEnumerable<KeyValuePair<string, string>>), () => new Dictionary<string, string>() { {"x", "123"}, {"y", "456"}}},
                    { typeof(HttpContent), ()=> ContentTests.Buffer(HttpContent.Create("hello world", "text/html"))},
                    { typeof(object), ()=>new { arg = 123 }},
                };

            foreach (var method in typeof(HttpMethodExtensions).GetMethods().Where((x) => x.IsStatic).OrderBy((x) => x.ToString()))
            {
                Console.WriteLine(method);
                IList<object> args = new List<object>();
                List<Func<object>> funcs = new List<Func<object>>();
                foreach (var parameter in method.GetParameters())
                {
                    if (!lookup.ContainsKey(parameter.ParameterType))
                    {
                        throw new KeyNotFoundException(parameter.ParameterType.ToString());
                    }
                    var f = lookup[parameter.ParameterType];
                    funcs.Add(f);
                    args.Add(f());
                }

                var response = (HttpResponseMessage) method.Invoke(null, args.ToArray());
                Console.WriteLine("\t" + response.ToString());
                response.Dispose();
                for (int toNullOut = 0; toNullOut < args.Count; ++toNullOut)
                {
                    var temp = funcs.Select((f) => f()).ToArray();
                    temp[toNullOut] = null;
                    try
                    {
                        response = (HttpResponseMessage) method.Invoke(null, temp);
                        Console.WriteLine("\t" + response.ToString());
                        response.Dispose();
                        Assert.Fail("? " + method + " " + toNullOut);
                    }
                    catch (TargetInvocationException tie)
                    {
                        if (tie.InnerException is ArgumentNullException)
                        {
                            continue;
                        }
                        throw;
                    }
                }
            }
        }

        [TestMethod]
        public void TestMethod1()
        {
            var headers = Enum.GetValues(typeof(HttpRequestHeader)).Cast<HttpRequestHeader>().OrderBy((x) => x.ToString()).ToList();

            Console.WriteLine(headers.Count + " headers total");
            int success = 0;
            DateTime started = DateTime.UtcNow;
            foreach (HttpRequestHeader h in headers)
            {
                string v = h.ToString();
                if (h == HttpRequestHeader.IfModifiedSince)
                {
                    v = HeaderTests.ToHttpDateTime(DateTime.UtcNow);
                }
                else if (h == HttpRequestHeader.TransferEncoding)
                {
                    v = "chunked";
                }
                else if (h == HttpRequestHeader.Range)
                {
                    v = "bytes=500-600,601-999,-30";
                }
                else if (h == HttpRequestHeader.ContentLength)
                {
                    v = "123";
                }
                else if (h == HttpRequestHeader.ContentLocation)
                {
                    // investigate: IIS or HttpWebRequest issue?
                    // v = "ContentLocation";
                    // continue;
                }
                Console.WriteLine(headers.IndexOf(h) + " " + h);
                if (TrySend(h, v))
                {
                    ++success;
                }
            }
            Console.WriteLine("{0} successes in {1}", success, DateTime.UtcNow - started);
            Assert.AreEqual(38, success);
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestMethodNullArgumentsFails()
        {
            var client = new HttpClient();
            client.Get((Uri) null);
        }

        [TestMethod]
        public void TestRangeLast500()
        {
            TrySend(HttpRequestHeader.Range, "bytes=-500");
        }

        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestRangeMissingBytesFails()
        {
            TrySend(HttpRequestHeader.Range, "-500");
        }

        [TestMethod]
        public void TestTransportSettings()
        {
            var settings = new HttpWebRequestTransportSettings();
            Assert.IsFalse(settings.HasClientCertificates);
            settings.ClientCertificates.Add(new System.Security.Cryptography.X509Certificates.X509Certificate());
            Assert.IsTrue(settings.HasClientCertificates);
        }
        [TestMethod, ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestTransportSettingsNegativeRedirectionFails()
        {
            new HttpWebRequestTransportSettings().MaximumAutomaticRedirections = -1;
        }


        static bool TrySend(HttpRequestHeader h, string v)
        {
            using (HttpClient client = new HttpClient())
            {
                client.Stages.Add(new SampleTraceStage((x) => System.Diagnostics.Trace.WriteLine(x)));
                client.TransportSettings.ConnectionTimeout = TimeSpan.FromSeconds(1);
                try
                {
                    HttpRequestMessage request = new HttpRequestMessage("GET", "http://localhost/");

                    var name = new WebHeaderCollection();
                    name[h] = "xyz";
                    request.Headers[name.AllKeys.Single()] = v;
                    Trace.WriteLine("req:  " + h + " " + v + " = " + request);
                    var response = client.Send(request);
                    Trace.WriteLine("resp: " + h + " " + v + " = " + response);
                    response.Content.ReadAsStream().Close();
                    response.Dispose();
                    client.Dispose();
                    return true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(h + ": " + e.GetType() + ": " + e.Message);
                    Trace.WriteLine(e);
                    if (e is ArgumentOutOfRangeException)
                    {
                        throw;
                    }
                    if (e is HttpStageProcessingException && e.InnerException is ArgumentOutOfRangeException)
                    {
                        throw e.InnerException;
                    }

                    if (e is HttpStageProcessingException && e.InnerException is WebException)
                    {
                        if (((WebException) e.InnerException).Status == WebExceptionStatus.Timeout)
                        {
                            throw;
                        }
                    }
                    return false;
                }
            }
        }
    }

}
