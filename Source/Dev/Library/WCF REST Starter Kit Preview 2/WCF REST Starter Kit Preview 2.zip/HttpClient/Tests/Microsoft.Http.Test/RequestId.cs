//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Threading;
    using System.Xml;
    using System.Xml.Linq;
    using System.Xml.Serialization;
    using Microsoft.Http;

    public class RequestId
    {
        public RequestId()
        {
        }
        public RequestId(string id)
        {
            this.Id = id;
        }
        public string Id
        {
            get;
            set;
        }
    }

}
