//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.WcfProxy
{
    using System;
    using System.ServiceModel;
    using System.ServiceModel.Activation;
    using Microsoft.Http.Headers;

    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior]
    public class WcfHttpProxyService : IWcfHttpProxy
    {
        public ProxiedHttpResponseMessage Send(ProxiedHttpMessage proxy)
        {
            var httpRequest = new HttpRequestMessage()
                {
                    Method = proxy.Method,
                    Uri = new Uri(proxy.Address),
                    Headers = RequestHeaders.Parse(proxy.HeaderBlock),
                };

            if (proxy.Body != null)
            {
                httpRequest.Content = HttpContent.Create(proxy.Body);
            }

            // investigate: is this needed?
            httpRequest.Headers["Connection"] = "close";

            var client = new HttpClient();
            using (var response = client.Send(httpRequest))
            {

                // Add your operation implementation here
                var proxied = new ProxiedHttpResponseMessage()
                    {
                        Address = response.Uri.ToString(),
                        Method = response.Method,
                        HeaderBlock = response.Headers.ToString(),
                        StatusCode = (int) response.StatusCode,
                        Body = response.Content.ReadAsByteArray(),
                        OriginalHeaders = response.Request.Headers.ToString()
                    };
                return proxied;
            }
        }
    }

}
