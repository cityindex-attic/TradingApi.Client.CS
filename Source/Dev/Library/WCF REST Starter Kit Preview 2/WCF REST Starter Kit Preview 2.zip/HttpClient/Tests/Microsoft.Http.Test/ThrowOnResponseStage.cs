//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Http;
    using System.Threading;

    public class ThrowOnResponseStage : HttpProcessingStage
    {
        public override void ProcessRequest(HttpRequestMessage request)
        {
        }
        public override void ProcessResponse(HttpResponseMessage response)
        {
            throw new ApplicationException(this.ToString());
        }
    }
}
