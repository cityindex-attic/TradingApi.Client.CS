//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

namespace Microsoft.Http.Test
{
    using System;

    using Microsoft.Http;

    public abstract class HttpCacheStage<TKey> : HttpStage
    {
        static readonly object NoKeyExtracted = new object();
        public abstract void RememberResponse(TKey key, HttpResponseMessage response);

        public abstract bool TryExtractKeyFromRequest(HttpRequestMessage request, out TKey key);
        public abstract bool TryGetResponse(TKey key, out HttpResponseMessage response);

        protected override internal void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            TKey key;
            if (TryExtractKeyFromRequest(request, out key))
            {
                state = key;
                if (TryGetResponse(key, out response))
                {
                    if (response == null)
                    {
                        throw new InvalidOperationException();
                    }
                    response.Request = request;
                    return;
                }
            }
            else
            {
                state = NoKeyExtracted;
                response = null;
            }
        }

        protected override internal void ProcessResponse(HttpResponseMessage response, object state)
        {
            if (state != NoKeyExtracted)
            {
                TKey key = (TKey) state;
                RememberResponse(key, response);
            }
        }
    }
}
