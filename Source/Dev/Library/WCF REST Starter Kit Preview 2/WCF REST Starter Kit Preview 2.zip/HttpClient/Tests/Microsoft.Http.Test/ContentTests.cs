//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.Content
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.IO.Compression;
    using System.Linq;
    using System.Net;
    using System.Runtime.Serialization;
    using System.Runtime.Serialization.Json;
    using System.ServiceModel.Syndication;
    using System.Text;
    using System.Xml;
    using System.Xml.Linq;
    using System.Xml.Serialization;
    using Microsoft.Http;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public class Customer
    {
        public Address Address
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
    }

    public class Address
    {
        public string City
        {
            get;
            set;
        }
        public string State
        {
            get;
            set;
        }
        public string StreetAddress
        {
            get;
            set;
        }
    }

    public class ExtendedCustomer : Customer
    {
        public int TotalSpend
        {
            get;
            set;
        }
    }

    [TestClass]
    public class ContentTests
    {

        public static HttpContent Buffer(HttpContent content)
        {
            content.LoadIntoBuffer();
            return content;
        }

        [TestMethod]
        public void TestBufferingAction()
        {
            HttpContent content = HttpContent.Create((stream) =>
            {
                var w = new StreamWriter(stream);
                w.WriteLine("hello");
                w.Flush();
            }
                , "text/plain");
            content.LoadIntoBuffer();
            var s = Console.OpenStandardOutput();
            content.WriteTo(s);
            s.Flush();

            var stream2 = content.ReadAsStream();
            Console.WriteLine(new StreamReader(stream2).ReadToEnd());
        }

        [TestMethod]
        public void TestBufferingFunc()
        {
            var content = HttpContent.Create(new Func<Stream>(() => new MemoryStream(Encoding.Default.GetBytes("hello world!"))), "text/plain");
            var stream2 = new MemoryStream();
            content.WriteTo(stream2);
            stream2.Position = 0;
            Console.WriteLine(new StreamReader(stream2).ReadToEnd());
        }

        [TestMethod]
        public void TestBufferWithoutRead()
        {
            // if I buffer but never read, what happens?
        }

        [TestMethod]
        public void TestDataContractContentType()
        {
            Customer customer = new ExtendedCustomer()
                {
                    Name = "First Last",
                    TotalSpend = 123456,
                    Address = new Address()
                    {
                        StreetAddress = "1 Microsoft Way",
                        City = "Redmond",
                        State = "WA"
                    }
                };

            Console.WriteLine((HttpContentExtensions.CreateDataContract(customer, typeof(ExtendedCustomer))).ReadAsString());
            var content = HttpContentExtensions.CreateDataContract(customer, typeof(ExtendedCustomer));
            var client = new HttpClient();
            Customer extended;
            using (var response = client.Post(ServerHelper.EchoAddress, content))
            {
                response.EnsureStatusIs(HttpStatusCode.OK);
                response.Content.LoadIntoBuffer();
                extended = response.Content.ReadAsDataContract<Customer>(typeof(ExtendedCustomer));
                XElement.Load(XmlReader.Create(response.Content.ReadAsStream()));
                Console.WriteLine(XElementContentExtensions.ReadAsXElement(response.Content));
            }
            Assert.IsInstanceOfType(extended, typeof(ExtendedCustomer));
            Assert.AreEqual(123456, ((ExtendedCustomer) extended).TotalSpend);
        }
        [TestMethod]
        public void TestDataContractJsonContentType()
        {
            for (int i = 0; i < 2; ++i)
            {
                var customer = new ExtendedCustomer()
                    {
                        Name = "First Last",
                        TotalSpend = 123456,
                        Address = new Address()
                        {
                            StreetAddress = "1 Microsoft Way",
                            City = "Redmond",
                            State = "WA"
                        }
                    };
                var content = HttpContentExtensions.CreateJsonDataContract<Customer>(customer, typeof(ExtendedCustomer));
                Console.WriteLine(content.ReadAsString());

                content = HttpContentExtensions.CreateJsonDataContract<Customer>(customer, typeof(ExtendedCustomer));
                var client = new HttpClient();
                var response = client.Post(ServerHelper.EchoAddress, content);

                Assert.AreEqual("application/json", response.Content.ContentType);
                Assert.AreEqual("application/json", response.Headers.ContentType);
                Console.WriteLine(response.ToHttpResponseString());
                response.Content.LoadIntoBuffer();
                var ser = new DataContractJsonSerializer(typeof(Customer), new Type[] { typeof(ExtendedCustomer) });
                var extended = response.Content.ReadAsJsonDataContract<Customer>(ser);
                Assert.IsInstanceOfType(extended, typeof(ExtendedCustomer));
                Assert.AreEqual(123456, ((ExtendedCustomer) extended).TotalSpend);
                response.Dispose();
            }
        }
        [TestMethod]
        public void TestDeleteWithEmptyContent()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage("DELETE", ServerHelper.EchoAddress);
            request.Content = HttpContent.CreateEmpty();
            using (var response = client.Send(request))
            {
                Console.WriteLine(response.ToHttpResponseString());
            }
        }

        [TestMethod]
        public void TestFile()
        {
            var name = typeof(ContentTests).Assembly.Location;
            var info = new FileInfo(name);
            var content = HttpContent.Create(info, "application/octet-stream");
            Assert.AreEqual(new FileInfo(name).Length, content.GetLength());
            var read = content.ReadAsByteArray();
            Assert.AreEqual(content.GetLength(), read.Length);
        }

        [TestMethod]
        public void TestFormContent()
        {
            using (var req = new HttpRequestMessage())
            {
                req.Content = HttpContent.Create(new HttpMultipartMimeForm() { { "field", "value" }, { "file", "name.txt", HttpContent.Create("<html>this is my file</html>", "text/html") } });
                var body = new StreamReader(req.Content.ReadAsStream()).ReadToEnd().Trim();
                Console.WriteLine(body);
                Assert.IsTrue(body.Contains("this is my file"));
            }
        }

        [TestMethod]
        public void TestFormContent2()
        {
            var form = new HttpMultipartMimeForm() { { "x", "1234" }, { "abc", "this is a sample <> string" } };
            form.Add("name", "filename.html", HttpContent.Create("<html><body>test</body></html>", "text/html"));

            var nested = new HttpMultipartMimeForm() { { "nested", "nested value" }, { "nestedfile", "filename.txt", HttpContent.Create("this is a nested file", "text/plain") } };
            form.Add("nestedForm", "myForm", nested.CreateHttpContent());

            HttpContent content = form.CreateHttpContent();
            Console.WriteLine(content.ContentType);
            Console.WriteLine(content.ReadAsString());
        }

        [TestMethod]
        public void TestFormContentWithQueryString()
        {
            var form = new Dictionary<string, string>() { { "x", "1234" }, { "abc", "this is a sample" } };
            var u = HttpQueryString.MakeQueryString(new Uri("http://xyz/?y=2"), form);
            Console.WriteLine(u);
            Assert.AreEqual(new Uri("http://xyz/?y=2&x=1234&abc=this is a sample"), u);
            // Console.WriteLine(new StreamReader(form.Read()).ReadToEnd());
        }
        [TestMethod]
        public void TestFormContentWithQueryStringRelative()
        {
            var form = new HttpQueryString() { { "x", "1234" }, { "abc", "this is a sample" } };
            var u = HttpQueryString.MakeQueryString(new Uri("/?y=2", UriKind.RelativeOrAbsolute), form);
            Assert.AreEqual(new Uri("/?y=2&x=1234&abc=this is a sample".Replace(" ", "%20"), UriKind.Relative), u);
            u = HttpQueryString.MakeQueryString(new Uri("/", UriKind.RelativeOrAbsolute), form);
            Assert.AreEqual(new Uri("/?x=1234&abc=this is a sample".Replace(" ", "%20"), UriKind.Relative), u);
            u = HttpQueryString.MakeQueryString(new Uri("/?", UriKind.RelativeOrAbsolute), form);
            Assert.AreEqual(new Uri("/?x=1234&abc=this is a sample".Replace(" ", "%20"), UriKind.Relative), u);
        }
        [TestMethod, ExpectedException(typeof(NotImplementedException))]
        public void TestFormMultipleFilesFails()
        {
            var form = new HttpMultipartMimeForm() {
                    { "file", "name.txt", HttpContent.Create("<html>this is my file</html>", "text/html") },
                    { "file", "name2.txt", HttpContent.Create("<html>this is my other file</html>", "text/html") }
                };
            using (HttpRequestMessage req = new HttpRequestMessage())
            {
                req.Content = form.CreateHttpContent();
                req.Content.WriteTo(new MemoryStream());
            }
        }

        [TestMethod]
        public void TestGetWithEmptyContent()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage("GET", ServerHelper.EchoAddress);
            request.Content = HttpContent.CreateEmpty();
            using (var response = client.Send(request))
            {
                Console.WriteLine(response.ToHttpResponseString());
            }
        }

        [TestMethod]
        public void TestMessageContentType()
        {
            HttpRequestMessage r;
            Assert.AreEqual(null, HttpMessageCore.CalculateEffectiveContentType(r = Make(null, null)));
            r.Dispose();
            Assert.AreEqual("A/B", HttpMessageCore.CalculateEffectiveContentType(r = Make("A/B", null)));
            r.Dispose();
            Assert.AreEqual("A/B", HttpMessageCore.CalculateEffectiveContentType(r = Make(null, "A/B")));
            r.Dispose();
            Assert.AreEqual("A/B", HttpMessageCore.CalculateEffectiveContentType(r = Make("A/B", "A/B")));
            r.Dispose();
        }

        [TestMethod]
        public void TestMessageContentTypeMismatch()
        {
            var r = Make("text/HeaderWins", "text/Body");
            Assert.AreEqual("text/HeaderWins", HttpMessageCore.CalculateEffectiveContentType(r));
            r.Dispose();
        }

        [TestMethod]
        public void TestNullResponseContent()
        {
            using (var response = new HttpResponseMessage()
                {
                    Uri = new Uri("http://www.microsoft.com"),
                    Method = "GET",
                    StatusCode = HttpStatusCode.OK
                })
            {
                Console.WriteLine(response.ToHttpResponseString());
            }
        }
        [TestMethod]
        public void TestRss()
        {
            var client = new HttpClient();
            using (var resp = client.Get("http://weblogs.asp.net/scottgu/atom.aspx"))
            {
                var feed = resp.Content.ReadAsSyndicationFeed();
                Console.WriteLine(feed.Title.Text);
            }
            using (var resp2 = client.Get("http://weblogs.asp.net/scottgu/atom.aspx"))
            {
                var feed2 = resp2.Content.ReadAsXElement();
                Console.WriteLine(feed2.Descendants().First().Name);
            }
        }


        [TestMethod]
        public void TestSyndicationFeed()
        {
            var items = new SyndicationItem[] { new SyndicationItem("item title", "this is my content", new Uri("http://localhost")) };
            var feed = new SyndicationFeed(items)
                {
                    Title = new TextSyndicationContent("title")
                };

            Console.WriteLine(HttpContentExtensions.CreateAtom10SyndicationFeed(feed).ReadAsString());

            var client = new HttpClient();
            using (var atomResponse = client.Post(ServerHelper.EchoAddress, HttpContentExtensions.CreateAtom10SyndicationFeed(feed)))
            {
                atomResponse.Content.LoadIntoBuffer();
                Console.WriteLine(atomResponse.Content.ReadAsString());
                Console.WriteLine(atomResponse.Content.ReadAsSyndicationFeed());
                Console.WriteLine(atomResponse.Content.ReadAsSyndicationFeed<SyndicationFeed>());
            }
            using (var rssResponse = client.Post(ServerHelper.EchoAddress, HttpContentExtensions.CreateRss20SyndicationFeed(feed)))
            {
                var x = rssResponse.Content.ReadAsSyndicationFeed();
                Console.WriteLine(x.Title.Text + " " + x.Title.Type);
                Assert.AreEqual(feed.Title.Text, x.Title.Text);
            }
        }

        [TestMethod]
        public void TestXE()
        {
            var client = new HttpClient();
            using (var resp = client.Get("http://blogs.msdn.com/MainFeed.aspx"))
            {
                var xe = resp.Content.ReadAsXElement();

                Console.WriteLine(xe.ToString().Length);
            }
        }

        [TestMethod]
        public void TestXHTML()
        {
            var s = @"
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en' dir='ltr'>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
		<meta http-equiv='Content-Style-Type' content='text/css' />
  </head>
</html>".Trim();
            var xhtml = XDocument.Load(HttpContent.Create(s).ReadAsXmlReader(new XmlReaderSettings()
                {
                    ProhibitDtd = false,
                    XmlResolver = null,
                }));
            Console.WriteLine(xhtml);
        }

        [TestMethod]
        public void TestXmlSerializerContentType()
        {
            var customer = new ExtendedCustomer()
                {
                    Name = "First Last",
                    TotalSpend = 123456,
                    Address = new Address()
                    {
                        StreetAddress = "1 Microsoft Way",
                        City = "Redmond",
                        State = "WA"
                    }
                };
            var serializer = new XmlSerializer(typeof(ExtendedCustomer));

            var client = new HttpClient();
            var body = HttpContentExtensions.CreateXmlSerializable(customer, typeof(ExtendedCustomer));
            using (var response = client.Post(ServerHelper.EchoAddress, body))
            {
                var extended = (object) serializer.Deserialize(response.Content.ReadAsStream());
                Assert.IsInstanceOfType(extended, typeof(ExtendedCustomer));
                Assert.AreEqual(123456, ((ExtendedCustomer) extended).TotalSpend);
            }
        }

        static HttpRequestMessage Make(string headerContentType, string bodyContentType)
        {
            var req = new HttpRequestMessage("GET", "http://localhost");
            req.Headers.ContentType = headerContentType;
            req.Content = HttpContent.Create("hello!", bodyContentType);
            return req;
        }
    }

    public class ContentAcceptanceTests
    {
        [TestMethod]
        public void TestCreateBufferReadRead()
        {
            var content = Create();

            content.LoadIntoBuffer();
            content.WriteTo(new MemoryStream());
            content.WriteTo(new MemoryStream());
        }
        [TestMethod]
        public void TestCreateBufferReadWrite()
        {
            var content = Create();

            content.LoadIntoBuffer();
            content.LoadIntoBuffer();
            content.ReadAsStream().ConsumeAllBytesAndClose();
            content.WriteTo(new MemoryStream());
            content.Dispose();
            content.Dispose();
        }
        [TestMethod]
        public void TestCreateBufferWriteRead()
        {
            var content = Create();

            content.LoadIntoBuffer();
            content.WriteTo(new MemoryStream());
            content.ReadAsStream().ConsumeAllBytesAndClose();
        }

        [TestMethod]
        public void TestCreateBufferWriteWrite()
        {
            var content = Create();

            content.LoadIntoBuffer();
            content.WriteTo(new MemoryStream());
            content.WriteTo(new MemoryStream());
        }
        [TestMethod]
        public void TestCreateDispose()
        {
            var content = Create();
            content.Dispose();
        }
        [TestMethod, ExpectedException(typeof(ObjectDisposedException))]
        public void TestCreateDisposeBufferFails()
        {
            var content = Create();
            content.Dispose();
            content.LoadIntoBuffer();
        }
        [TestMethod, ExpectedException(typeof(ObjectDisposedException))]
        public void TestCreateDisposeReadFails()
        {
            var content = Create();
            content.Dispose();
            content.ReadAsStream();
        }
        [TestMethod, ExpectedException(typeof(ObjectDisposedException))]
        public void TestCreateDisposeWriteFails()
        {
            var content = Create();
            content.Dispose();
            content.WriteTo(new MemoryStream());
        }
        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestCreateReadBufferFails()
        {
            var content = Create();
            content.ReadAsStream().ConsumeAllBytesAndClose();
            content.LoadIntoBuffer();
        }

        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestCreateReadReadFails()
        {
            var content = Create();
            content.ReadAsStream().ConsumeAllBytesAndClose();
            content.ReadAsStream().ConsumeAllBytesAndClose();
        }
        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestCreateWriteBufferFails()
        {
            var content = Create();

            content.WriteTo(new MemoryStream());
            content.LoadIntoBuffer();
        }
        [TestMethod, ExpectedException(typeof(InvalidOperationException))]
        public void TestCreateWriteWriteFails()
        {
            var content = Create();

            content.WriteTo(new MemoryStream());
            content.WriteTo(new MemoryStream());
        }

        [TestMethod]
        public void TestProperties()
        {
            var content = Create();
            Console.WriteLine(content.ContentType);
            if (!content.HasLength())
            {
                content.LoadIntoBuffer();
                var length = content.GetLength();
                Assert.IsTrue(length >= 0);
            }
            else
            {
                content.GetLength();
            }
            content.Dispose();
        }

        protected virtual HttpContent Create()
        {
            throw new NotImplementedException(this.ToString());
        }
    }

    [TestClass]
    public class StringContentAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            return HttpContent.Create("hello world!");
        }
    }
    [TestClass]
    public class StringContentEncodingAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            return HttpContent.Create("hello world!", Encoding.Default, "text/plain");
        }
    }
    [TestClass]
    public class BytesContentAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            return HttpContent.Create(new byte[] { 1, 2, 3, 4, 5 });
        }
    }
    [TestClass]
    public class BytesContentWithTypeAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            return HttpContent.Create(new byte[] { 1, 2, 3 }, "application/octet");
        }
    }

    [TestClass]
    public class ActionStreamAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            Action<Stream> writer = (stream) =>
            {
                stream.WriteByte(byte.MaxValue);
                stream.WriteByte(byte.MinValue);
                stream.Flush();
            };
            return HttpContent.Create(writer, "application/octet-stream");
        }
    }
    [TestClass]
    public class FuncStreamAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            Func<Stream> func = () => new MemoryStream(new byte[] { byte.MinValue, byte.MaxValue });
            return HttpContent.Create(func, "application/octet-stream", 2);
        }
    }

    [TestClass]
    public class FileAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            var c = HttpContent.Create(new FileInfo(typeof(FileAcceptanceTests).Assembly.Location), "application/octet-stream");
            Assert.IsTrue(c.HasLength());
            Assert.IsTrue(c.GetLength() > 0);
            return c;
        }
    }
    [TestClass]
    public class EmptyAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            return HttpContent.CreateEmpty();
        }
    }
    [TestClass]
    public class GZipDecompressAcceptanceTests : ContentAcceptanceTests
    {
        protected override HttpContent Create()
        {
            var original = HttpContent.Create("x");
            var compressed = HttpContent.Create(() =>
            {
                var buffer = new MemoryStream();
                var zipper = new GZipStream(buffer, CompressionMode.Compress);
                original.WriteTo(zipper);
                zipper.Flush();
                return buffer;
            }
                , original.ContentType);
            var decompressed = HttpContent.Create(() => new GZipStream(compressed.ReadAsStream(), CompressionMode.Decompress), compressed.ContentType);

            return decompressed;
        }
    }
    [TestClass]
    public class UrlEncodedAcceptanceTests : ContentAcceptanceTests
    {

        [TestMethod]
        public void TestCreate()
        {
            new HttpUrlEncodedForm()
                {
                    { "a", "1" },
                    { "b", "2" }
                }.CreateHttpContent().ReadAsString();
        }
        protected override HttpContent Create()
        {
            return HttpContent.Create(new HttpUrlEncodedForm() { { "a", "1" }, { "b", "2" } });
        }
    }
}
