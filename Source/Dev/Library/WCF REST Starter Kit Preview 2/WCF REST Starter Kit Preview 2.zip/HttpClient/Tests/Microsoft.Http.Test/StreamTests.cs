//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.IO;
    using System.Net;
    using Microsoft.Http;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class StreamTests
    {

        [TestMethod]
        public void Test()
        {
            ExerciseStream(new DrainOnCloseStream(new MemoryStream()));
        }

        [TestMethod, ExpectedException(typeof(ArgumentNullException))]
        public void TestDrainNullFails()
        {
            new DrainOnCloseStream(null);
        }

        static void ExerciseStream(Stream s)
        {
            bool any = s.CanRead || s.CanSeek || s.CanTimeout || s.CanWrite;
            Assert.IsTrue(any);
            var buffer = new byte[2];
            if (s.CanRead)
            {
                s.ReadByte();
                s.Read(buffer, 0, buffer.Length);
                s.EndRead(s.BeginRead(buffer, 0, buffer.Length, (r) =>
                {
                }
                    , null));
            }
            if (s.CanWrite)
            {
                s.WriteByte(0);
                s.Write(buffer, 0, buffer.Length);
                s.EndWrite(s.BeginWrite(buffer, 0, buffer.Length, (r) =>
                {
                }
                    , null));
            }
            else
            {
                try
                {
                    s.Write(buffer, 0, buffer.Length);
                }
                catch
                {
                }
            }
            s.Flush();
            if (s.CanSeek)
            {
                s.Seek(0, SeekOrigin.Begin);
                s.Seek(0, SeekOrigin.Current);
                s.Seek(0, SeekOrigin.End);
                --s.Position;
                s.SetLength(10);
                Console.WriteLine(s.Length);
            }

            if (s.CanTimeout)
            {
                s.ReadTimeout = 100;
                s.WriteTimeout = 100;
                Console.WriteLine(" " + s.ReadTimeout + " " + s.WriteTimeout);

            }
            s.Close();
        }
    }
}
