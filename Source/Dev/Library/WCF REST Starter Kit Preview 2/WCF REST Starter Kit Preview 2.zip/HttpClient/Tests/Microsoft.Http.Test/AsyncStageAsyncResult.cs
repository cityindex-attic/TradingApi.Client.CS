//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using System.Security.Cryptography;


    abstract class AsyncStageAsyncResult : AsyncResult
    {
        object state;
        public AsyncStageAsyncResult(HttpRequestMessage request, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.request = request;
        }

        public AsyncStageAsyncResult(HttpResponseMessage response, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.response = response;
        }

        protected HttpRequestMessage request
        {
            get;
            private set;
        }
        protected HttpResponseMessage response
        {
            get;
            private set;
        }

        public static void End(IAsyncResult result, out HttpResponseMessage response, out object state)
        {
            AsyncStageAsyncResult stage = AsyncResult.End<AsyncStageAsyncResult>(result);
            response = stage.response;
            state = stage.state;
        }
        public static void End(IAsyncResult result)
        {
            AsyncStageAsyncResult stage = AsyncResult.End<AsyncStageAsyncResult>(result);
        }
        public void Complete(bool completedSynchronously, HttpResponseMessage response, object state)
        {
            Debug.Assert(this.response == null);
            this.response = response;
            this.state = state;
            base.Complete(completedSynchronously);
        }
    }
}
