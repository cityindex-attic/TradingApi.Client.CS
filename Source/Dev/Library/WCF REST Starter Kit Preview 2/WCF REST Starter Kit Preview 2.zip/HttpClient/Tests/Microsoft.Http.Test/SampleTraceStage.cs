//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Threading;
    using System.Xml;
    using System.Xml.Linq;
    using System.Xml.Serialization;
    using Microsoft.Http;

    public class SampleTraceStage : HttpProcessingStage<int>
    {

        static readonly XmlSerializerFactory factory = new XmlSerializerFactory();

        static readonly char[] requiresCData = "\r\n&<>'%".ToCharArray();
        readonly Action<string> tracer;
        static HashSet<Type> failed = new HashSet<Type>() { typeof(HttpClient) };
        static HashSet<Type> failedDataContract = new HashSet<Type>() { typeof(HttpClient) };
        static HashSet<Type> failedWpf = new HashSet<Type>() { typeof(HttpClient) };


        int requests;
        public SampleTraceStage(Action<string> trace)
        {
            if (trace == null)
            {
                throw new ArgumentNullException("trace");
            }
            this.tracer = trace;
        }
        public override int ProcessRequest(HttpRequestMessage request)
        {
            object id;
            id = Interlocked.Increment(ref requests);
            request.Properties.Add(new RequestId(id.ToString()));
            XElement root = new XElement("Request",
                new XAttribute("Id", id),
                new XAttribute("Timestamp", DateTime.UtcNow),
                MakeUri("Uri", request.Uri));

            ProcessBase(request, root);
            Trace(root);
            return (int)id;
        }
        public override void ProcessResponse(HttpResponseMessage response, int state)
        {
            // ProcessRequest(response.OriginalRequest);
            XElement root = new XElement("Response",
                new XAttribute("RequestId", state),
                new XAttribute("Method", response.Method),
                new XAttribute("StatusCode", response.StatusCode),
                new XAttribute("StatusCodeInt", (int)response.StatusCode),
                new XAttribute("ContentLength", response.Headers.ContentLength ?? -1),
                new XAttribute("Timestamp", DateTime.UtcNow),
                MakeUri("ResponseUri", response.Uri)
                );

            ProcessBase(response, root);
            Trace(root);
        }

        static XmlWriter CreateXmlWriter(StreamWriter writer)
        {
            return XmlWriter.Create(writer, new XmlWriterSettings()
                {
                    OmitXmlDeclaration = true,
                    Indent = true
                });
        }
        static object MakeUri(string description, Uri u)
        {
            object content = MaybeCData(u);
            if (content is IFormattable)
            {
                return new XAttribute(description, content);
            }
            else
            {
                return new XElement(description, content);
            }
        }
        static object MaybeCData(object u)
        {
            if (u == null)
            {
                return "(null)";
            }
            if (!((u is IFormattable) || (u is IConvertible)))
            {
                var wpfXaml = TryWpfXaml(u);
                if (wpfXaml != null)
                {
                    return wpfXaml;
                }

                var dc = TryDataContract(u);
                if (dc != null)
                {
                    return dc;
                }

                var xs = TryXmlSerializer(u);
                if (xs != null)
                {
                    return xs;
                }
            }

            string s = u.ToString();
            if (s.IndexOfAny(requiresCData) != -1)
            {
                return new XCData(Environment.NewLine + s + Environment.NewLine);
            }
            else
            {
                return u;
            }
        }

        static XElement TryDataContract(object u)
        {
            if (!failedDataContract.Contains(u.GetType()))
            {
                try
                {
                    MemoryStream ms = new MemoryStream();
                    using (StreamWriter writer = new StreamWriter(ms))
                    {
                        using (var w = CreateXmlWriter(writer))
                        {
                            var serializer = new System.Runtime.Serialization.DataContractSerializer(u.GetType());
                            serializer.WriteObject(w, u);
                        }
                        writer.Flush();
                        ms.Position = 0;
                        using (var reader = new StreamReader(ms))
                        {
                            return XElement.Load(reader);
                        }
                    }
                }
                catch (Exception e)
                {
                    bool firstTime = failedDataContract.Add(u.GetType());
                    if (firstTime)
                    {
                        System.Diagnostics.Trace.WriteLine(e.ToString());
                    }
                }
            }
            return null;
        }

        static XElement TryWpfXaml(object u)
        {
            if (!failedWpf.Contains(u.GetType()))
            {
                try
                {
                    return XElement.Parse(System.Windows.Markup.XamlWriter.Save(u));
                }
                catch (Exception e)
                {
                    bool firstTime = failedWpf.Add(u.GetType());
                    if (firstTime)
                    {
                        System.Diagnostics.Trace.WriteLine(e.ToString());
                    }
                }
            }

            return null;
        }
        static XElement TryXmlSerializer(object u)
        {
            if (!failed.Contains(u.GetType()))
            {
                try
                {
                    var serializer = factory.CreateSerializer(u.GetType());

                    MemoryStream ms = new MemoryStream();
                    using (StreamWriter writer = new StreamWriter(ms))
                    {
                        using (var w = CreateXmlWriter(writer))
                        {
                            serializer.Serialize(w, u);
                        }
                        writer.Flush();
                        ms.Position = 0;
                        using (var reader = new StreamReader(ms))
                        {
                            return XElement.Load(reader);
                        }
                    }
                }
                catch (Exception e)
                {
                    bool firstTime = failedDataContract.Add(u.GetType());
                    if (firstTime)
                    {
                        System.Diagnostics.Trace.WriteLine(e.ToString());
                    }
                }
            }
            return null;
        }
        void ProcessBase(HttpResponseMessage message, XElement root)
        {
            var h = new XElement("Headers");
            foreach (string name in message.Headers.Keys)
            {
                h.Add(new XElement(name, MaybeCData(message.Headers[name])));
            }

            if (h.HasElements)
            {
                root.Add(h);
            }

            var p = new XElement("Properties");
            foreach (var prop in message.Properties)
            {
                string name = prop.GetType().Name;
                var cd = MaybeCData(prop);
                if (cd is XElement)
                {
                    p.Add(cd);
                }
                else
                {
                    p.Add(new XElement(name, cd));
                }
            }

            if (p.HasElements)
            {
                root.Add(p);
            }
        }

        void ProcessBase(HttpRequestMessage message, XElement root)
        {
            var h = new XElement("Headers");
            foreach (string name in message.Headers.Keys)
            {
                h.Add(new XElement(name, MaybeCData(message.Headers[name])));
            }

            if (h.HasElements)
            {
                root.Add(h);
            }

            var p = new XElement("Properties");
            foreach (var prop in message.Properties)
            {
                string name = prop.GetType().Name;
                var cd = MaybeCData(prop);
                if (cd is XElement)
                {
                    p.Add(cd);
                }
                else
                {
                    p.Add(new XElement(name, cd));
                }
            }

            if (p.HasElements)
            {
                root.Add(p);
            }
        }

        void Trace(XElement e)
        {
            lock (tracer)
            {
                tracer(e.ToString() + Environment.NewLine + Environment.NewLine);
            }
        }
    }
}
