//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------
namespace Microsoft.Http.Test.WcfProxy
{
    using System;
    using System.ServiceModel;
    using System.ServiceModel.Channels;
    using System.Collections.Generic;
    using Microsoft.Http.Headers;
    using System.Net;

    public class WcfProxyTransportStage : HttpAsyncStage
    {
        readonly WcfHttpProxyClient client;
        public WcfProxyTransportStage(string address)
        {
            this.client = new WcfHttpProxyClient(new BasicHttpBinding(BasicHttpSecurityMode.None), new EndpointAddress(address));
            client.InnerChannel.Open();
        }

        protected override internal IAsyncResult BeginProcessRequestAndTryGetResponse(HttpRequestMessage request, AsyncCallback callback, object state)
        {
            var body = HttpContent.IsNullOrEmpty(request.Content) ? null : request.Content.ReadAsByteArray();
            var message = new ProxiedHttpMessage()
                {
                    Method = request.Method,
                    Address = request.Uri.ToString(),
                    HeaderBlock = request.Headers.ToString(),
                    Body = body
                };

            return new ProxySendAsyncResult(this.client, request, message, callback, state);
        }

        protected override internal IAsyncResult BeginProcessResponse(HttpResponseMessage response, object state, AsyncCallback callback, object callbackState)
        {
            return new CompletedAsyncResult(callback, state);
        }

        protected override internal void EndProcessRequestAndTryGetResponse(IAsyncResult result, out HttpResponseMessage response, out object state)
        {
            state = null;
            var pair = ProxySendAsyncResult.End(result);
            var original = pair.Key;
            var proxied = pair.Value;
            original.Headers = RequestHeaders.Parse(proxied.OriginalHeaders);
            var http = new HttpResponseMessage()
                {
                    Headers = ResponseHeaders.Parse(proxied.HeaderBlock),
                    Uri = new Uri(proxied.Address),
                    Request = original,
                    Method = proxied.Method,
                    StatusCode = (HttpStatusCode) proxied.StatusCode,
                    Content = HttpContent.Create(proxied.Body)
                };
            original.Dispose();
            response = http;
        }

        protected override internal void EndProcessResponse(IAsyncResult result)
        {
            CompletedAsyncResult.End(result);
        }

        protected override internal void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
        {
            EndProcessRequestAndTryGetResponse(BeginProcessRequestAndTryGetResponse(request, null, null), out response, out state);
        }

        protected override internal void ProcessResponse(HttpResponseMessage response, object state)
        {
        }


        class ProxySendAsyncResult : AsyncResult<KeyValuePair<HttpRequestMessage, ProxiedHttpResponseMessage>>
        {
            static readonly AsyncCallback EndSendCallback = EndSend;
            readonly WcfHttpProxyClient client;
            readonly HttpRequestMessage request;
            public ProxySendAsyncResult(WcfHttpProxyClient client, HttpRequestMessage request, ProxiedHttpMessage message, AsyncCallback callback, object state)
                : base(callback, state)
            {
                this.client = client;
                this.request = request;
                var result = client.BeginSend(message, EndSendCallback, this);
                if (result.CompletedSynchronously)
                {
                    var response = client.EndSend(result);
                    this.Complete(true, new KeyValuePair<HttpRequestMessage, ProxiedHttpResponseMessage>(request, response));
                }
            }

            static void EndSend(IAsyncResult result)
            {
                if (result.CompletedSynchronously)
                {
                    return;
                }
                var self = result.AsyncState as ProxySendAsyncResult;
                var response = self.client.EndSend(result);
                self.Complete(false, new KeyValuePair<HttpRequestMessage, ProxiedHttpResponseMessage>(self.request, response));
            }
        }
    }

    [System.ServiceModel.ServiceContractAttribute(Namespace = "http://www.microsoft.com/")]
    interface IWcfAsyncHttpProxy
    {
        [OperationContractAttribute(AsyncPattern = true, Action = "http://www.microsoft.com/IWcfHttpProxy/Send", ReplyAction = "http://www.microsoft.com/IWcfHttpProxy/SendResponse")]
        System.IAsyncResult BeginSend(ProxiedHttpMessage message, System.AsyncCallback callback, object asyncState);

        ProxiedHttpResponseMessage EndSend(System.IAsyncResult result);
    }

    class WcfHttpProxyClient : ClientBase<IWcfAsyncHttpProxy>, IWcfAsyncHttpProxy
    {
        public WcfHttpProxyClient()
        {
        }

        public WcfHttpProxyClient(Binding binding, EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        public System.IAsyncResult BeginSend(ProxiedHttpMessage message, System.AsyncCallback callback, object asyncState)
        {
            return base.Channel.BeginSend(message, callback, asyncState);
        }

        [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
        public ProxiedHttpResponseMessage EndSend(System.IAsyncResult result)
        {
            return base.Channel.EndSend(result);
        }

        System.IAsyncResult OnBeginSend(object[] inValues, System.AsyncCallback callback, object asyncState)
        {
            ProxiedHttpMessage message = ((ProxiedHttpMessage)(inValues[0]));
            return ((IWcfAsyncHttpProxy)(this)).BeginSend(message, callback, asyncState);
        }

        object[] OnEndSend(System.IAsyncResult result)
        {
            ProxiedHttpResponseMessage retVal = ((IWcfAsyncHttpProxy)(this)).EndSend(result);
            return new object[] {
                    retVal};
        }
    }
}

