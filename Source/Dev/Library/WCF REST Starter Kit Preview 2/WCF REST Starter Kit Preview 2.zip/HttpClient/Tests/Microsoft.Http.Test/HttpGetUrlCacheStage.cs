//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

namespace Microsoft.Http.Test
{
    using System;

    using Microsoft.Http;

    public abstract class HttpGetUrlCacheStage : HttpCacheStage<Uri>
    {
        public sealed override bool TryExtractKeyFromRequest(HttpRequestMessage request, out Uri key)
        {
            if (request.Method == "GET")
            {
                key = request.Uri;
                return true;
            }
            else
            {
                key = default(Uri);
                return false;
            }
        }
    }
}
