﻿namespace WpfSample
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.Http;
    using System.Diagnostics;

    class TraceWriteLineStage : HttpProcessingStage<DateTime>
    {
        public override DateTime ProcessRequest(HttpRequestMessage request)
        {
            DateTime now = DateTime.UtcNow;
            Trace.WriteLine(now.TimeOfDay + " : begin   " + request);
            return DateTime.UtcNow;
        }

        public override void ProcessResponse(HttpResponseMessage response, DateTime state)
        {
            DateTime now = DateTime.UtcNow;
            TimeSpan elapsed = DateTime.UtcNow - state;
            Trace.WriteLine(now.TimeOfDay + " : end     " + response.Request + " " + elapsed);
        }
    }

}
