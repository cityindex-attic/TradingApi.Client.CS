﻿namespace WpfSample
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Xml.Linq;
    using Microsoft.Http;
    using Microsoft.Http.Headers;
    using System.Diagnostics;

    public partial class Window1 : Window
    {
        HttpClient client;
        public Window1()
        {
            InitializeComponent();
            this.client = new HttpClient();
            this.client.Stages.Add(new TraceWriteLineStage());
            this.client.SendCompleted += client_SendCompleted;
        }

        void client_SendCompleted(object sender, SendCompletedEventArgs e)
        {
            this.sendButton.IsEnabled = true;
            this.cancelButton.IsEnabled = false;
            this.responsePanel.IsEnabled = true;
            this.responsePanel.SelectedIndex = 0;
            this.responseBodyTab.Header = "body";
            try
            {
                if (e.Cancelled)
                {
                    if (e.Error == null)
                    {
                        this.responseStatusOrExceptionMessage.Text = "Cancelled";
                    }
                    else
                    {
                        this.responseStatusOrExceptionMessage.Text = "Cancelled: " + FindMessage(e.Error);
                        this.responseHeadersOrException.Text = e.Error.ToString();
                    }
                    return;
                }

                if (e.Error != null)
                {
                    this.responseStatusOrExceptionMessage.Text = "Error: " + FindMessage(e.Error);
                    this.responseHeadersOrException.Text = e.Error.ToString();
                    this.responseRequestHeaders.Text = e.Request.Headers.ToString();
                    return;
                }

                this.responseStatusOrExceptionMessage.Text = "Response: " + ((int)e.Response.StatusCode) + " " + e.Response.StatusCode;
                this.responseMethodAndUri.Text = e.Response.Method + " " + e.Response.Uri;
                this.responseHeadersOrException.Text = e.Response.Headers.ToString();

                this.responseRequestHeaders.Text = e.Response.Request.Headers.ToString();

                if (HttpContent.IsNullOrEmpty(e.Response.Content))
                {
                    this.responseBody.Text = "(empty)";
                    return;
                }

                string contentType = e.Response.Headers.ContentType ?? "";

                if (!string.IsNullOrEmpty(contentType))
                {
                    responseBodyTab.Header = "body (" + contentType + ")";
                }

                bool isXml = contentType.IndexOf("xml", StringComparison.OrdinalIgnoreCase) != -1;
                bool isText = contentType.IndexOf("text", StringComparison.OrdinalIgnoreCase) != -1 || contentType.Equals("message/http", StringComparison.OrdinalIgnoreCase);


                string s;
                if (isXml)
                {
                    // because we might read more than once, we need to buffer the contents
                    e.Response.Content.LoadIntoBuffer();

                    try
                    {
                        XElement element = e.Response.Content.ReadAsXElement();
                        s = element.ToString();
                    }
                    catch (Exception xml)
                    {
                        s = FindMessage(xml) + Environment.NewLine + e.Response.Content.ReadAsString();
                    }
                }
                else if (isText)
                {
                    s = e.Response.Content.ReadAsString().Trim();
                }
                else
                {
                    s = e.Response.Content.ToString();
                }

                this.responseBody.Text = s;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        static string FindMessage(Exception exception)
        {
            if (!string.IsNullOrEmpty(exception.Message) || exception.InnerException == null)
            {
                return exception.Message;
            }
            return FindMessage(exception.InnerException);
        }

        void addBasicCredential(object sender, RoutedEventArgs e)
        {
            var b = new Button()
            {
                Content = "add"
            };
            var u = new TextBox()
            {
                Text = "username"
            };
            var p = new TextBox()
            {
                Text = "password"
            };

            var g = new StackPanel()
            {
                Children = { u, p, b },
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch
            };
            var w = new Window()
            {
                Content = new Viewbox()
                {
                    Child = g
                },
                Height = this.Height / 4,
                Width = this.Width / 4
            };
            b.Click += (x, y) =>
            {
                var h = new RequestHeaders();
                h.Authorization = Credential.CreateBasic(u.Text, p.Text);
                this.requestHeaders.Text = this.requestHeaders.Text.Trim() + Environment.NewLine + h.ToString();
                w.Close();
            };
            w.ShowDialog();
            w.Close();
        }

        void clearRequestHeaders(object sender, RoutedEventArgs e)
        {
            requestHeaders.Text = "";
        }

        void clearRequestBody(object sender, RoutedEventArgs e)
        {
            requestBody.Text = "";
        }

        int currentRequest = 0;
        void sendButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var u = requestUri.Text;
                if (!requestUri.Items.Contains(u))
                {
                    requestUri.Items.Add(u);
                }
                var request = new HttpRequestMessage(requestMethod.Text, u);

                if (checkRequestHeaders.IsChecked ?? false)
                {
                    request.Headers = RequestHeaders.Parse(requestHeaders.Text);
                }
                if (checkRequestBody.IsChecked ?? false)
                {
                    request.Content = HttpContent.Create(requestBody.Text);
                }

                currentRequest += 1;
                object userState = currentRequest;

                cancelButton.IsEnabled = true;
                sendButton.IsEnabled = false;
                responsePanel.IsEnabled = false;
                this.responseBody.Text = "";
                this.responseHeadersOrException.Text = "";
                this.responseMethodAndUri.Text = "";
                this.responseStatusOrExceptionMessage.Text = "";
                this.responseRequestHeaders.Text = "";
                this.responseTab.Header = "response #" + userState;
                client.SendAsync(request, userState);
            }
            catch (Exception ex)
            {
                responsePanel.IsEnabled = true;
                responseStatusOrExceptionMessage.Text = "Error on send: " + FindMessage(ex);
                responseHeadersOrException.Text = ex.ToString();
            }
        }

        void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            client.SendAsyncCancel(currentRequest);
        }

        void sendOnEnter(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                sendButton_Click(sender, e);
            }
        }

        void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string[] args = Environment.GetCommandLineArgs();
            if (args.Length == 2)
            {
                this.requestUri.Text = args[1];
            }
            else if (args.Length == 3)
            {
                this.requestMethod.Text = args[1];
                this.requestUri.Text = args[2];
            }
        }
    }
}
